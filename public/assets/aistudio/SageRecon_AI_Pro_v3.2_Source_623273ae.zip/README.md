# SageRecon AI Pro 3.2 — Private Bank Reconciliation (Windows 11)

Reconciles a **Sage cashbook export** against a **bank statement**, entirely offline. It does not connect to Sage,
upload data, or alter accounting records. Files are read in memory; exports are written only when you ask.
The only thing saved between sessions is a small local preferences file (`~/.sagerecon_ai_pro.json`: last folder,
tolerance, currency, report header text). No account database, no network calls.

## Run from source
```
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe app\main.py
```
Click **Try it with demo data** on the welcome screen to see every feature on fictional data.

## Build the Windows executable / installer
Double-click `build_windows.bat` (runs the tests first, then PyInstaller) → `dist\SageReconAIPro\SageReconAIPro.exe`.
Compile `installer.iss` with Inno Setup 6 for `installer_output\SageRecon_AI_Pro_Setup.exe`. Building must happen on Windows.



## New in 3.2 — Simple view (the default)
Anyone can use the app without knowing accounting terms. It has just two screens:

1. **Choose your two files** – two big cards (or "choose both at once"). The app detects which file is which (and offers to
   swap if you pick them the wrong way round), finds the bank columns itself and works out the dates to check. One button: *Check my reconciliation*.
2. **What needs your attention** – a plain verdict ("All done – your bank and your books agree" / "Almost there – 10 things to look at"),
   three simple numbers, then a short to-do list in everyday language. Each card says what happened and what to do, with one-click buttons
   (**Done**, **Add a note**, **Yes, same transaction / No**). Bank fees and interest are bundled into one card. Normal timing differences are
   tucked away under "nothing to do". Progress is tracked; scrolling position is kept while you work. At the end: **Download Excel report** and **journal entries**.

Safety nets: if a closing balance can't be found it asks you to type it in (never assumes zero); unreadable rows are explained in plain words
with a shortcut to fix them in the Detailed view. The **Detailed view** (header button) still has everything an accountant wants:
column mapping, tolerance, look-back, manual matching, journals, Ask AI, guided review, sessions.

## New in 3.1 — smarter and friendlier
| Feature | What it does |
|---|---|
| **Next-step coach** | A banner always tells you what to do next (load files → run → review → export) with a one-click button. |
| **Choose both files at once** | Select the Sage export and the bank statement together; the app works out which is which (and asks if unsure). |
| **Guided review** (Ctrl+G) | Walks through every open item one by one with the evidence, the consequence of each choice and a recommended action: accept / dismiss near-matches, mark reviewed, add notes, match manually. |
| **It learns** | Accepting a suggestion or matching manually teaches the app that naming pattern (e.g. Sage "Customer E" ↔ bank "NIP TRF QUEEN A.") and it uses it, with a visible reason, on later runs. Stored only in `~/.sagerecon_ai_pro_memory.json`; *Tools → Forget* clears it. |
| **Ask AI** (Ctrl+K) | Plain-English questions answered offline: "payments over 500k not on the bank", "bank charges", "top 5 largest", "items after 20/10", "unusual items", "why is there a difference". |
| **Risk flags** | Unmatched items are flagged for round amounts, unusually large size, weekend dates and missing narration. |
| **Proposed journals** | Balanced adjusting entries for bank charges (grouped per day), interest, unrecorded items (parked in Suspense for you to allocate) and amount corrections. Export as CSV; nothing is ever posted. Account names are configurable. |
| **Review sessions** | *File → Save review session* stores your decisions, notes and balance overrides; re-apply them later on a fresh run of the same files. |
| **Right-click menus, tooltips, ✓ Reviewed ticks, progress on the dashboard** | Faster everyday use. |

## Workflow
1. **Sage cashbook** – choose `.xlsx/.xls/.csv`. Opening/closing balances and the report date range are detected.
2. **Bank statement** – choose the file. The header row and columns are auto-detected; the panel collapses itself when the
   running balance ties out perfectly, and stays open (with warnings) when something looks wrong. Supports separate
   Withdrawal/Deposit columns **or** one signed Amount column, any header row, `dd/mm` vs `mm/dd` auto-inference,
   `(1,000.00)`, `1,000.00-`, `Dr/Cr`, `₦/NGN`, European decimals, newest-first statements, and balances printed outside the table.
3. **Reconcile** – confirm the period (auto-suggested), set the date tolerance, run (Ctrl+R).

## What the engine does (explainable, rules + scoring — not a generative model)
| Stage | Behaviour |
|---|---|
| Exact matching | Same direction + exact amount within tolerance. Ranked by date proximity, reference/ID overlap (cheque/session numbers) and description similarity. Every match has a **confidence score and a plain-English reason**. Strictly one-to-one. |
| Batch / split | One item equal to the sum of 2–4 items on the other side (e.g. a cash deposit of several receipts). Never rated "High"; verify before relying on it. |
| Near-miss suggestions | Same reference but different amount, **transposed digits**, single-digit keying errors, small fee/rounding differences, same amount with dates outside tolerance. Never auto-accepted; accept with one click. |
| Classification | Bank charges/VAT/stamp duty/EMTL, interest, reversals, outstanding payments, deposits in transit, stale (>6 month) payments, duplicate entries — each with a suggested action and priority. |
| Proof | Full **bank reconciliation statement** (adjusted bank vs adjusted book) with automatic explanation hints for any residual difference. |
| Data quality | Rows ignored because of unreadable dates, bank running-balance breaks, items outside the period, duplicates, reversal pairs. |

Manual tools: match any bank/Sage items yourself (many-to-many, amount differences become a reconciling line), unmatch,
add reviewer notes, type a closing balance when it cannot be found. Export a formatted **Excel report** (statement with live
formulas, exceptions, matches, suggestions, data quality) or CSV.

## Accounting safeguards
- Bank deposits ↔ Sage debits; bank withdrawals ↔ Sage credits. Amounts are `Decimal` — no floating-point drift.
- A closing balance that cannot be verified shows **NOT VERIFIED**, never 0. Sources are labelled (statement, last running
  balance, derived from Sage opening + movements, or entered manually).
- Unmatched ≠ error. They are investigation candidates (timing, charges, errors, fraud indicators).
- The proof is only as good as the opening position: if the prior period had unreconciled items, use **Look-back** or expect a residual.
- Reconcile one bank account and one currency at a time.

## Tests
```
py -3.12 -m pip install -r requirements-dev.txt
py -3.12 -m pytest tests -q          # or: py -3.12 -m unittest discover -s tests
```
The suite covers parsing edge cases, every matching pass, the statement proof, learning, risk flags, the assistant, journals, sessions, file detection, exports, the plain-English layer (including a no-jargon check), a GUI smoke test (skipped without a display) and a 5,000×5,000 performance check.

## Limitations
- The Windows installer/executable has not been compiled here — validate with non-sensitive data first.
- Multi-row/merged-cell bank headers: set the **Header row** manually, or export a clean CSV.
- Scanned/PDF statements are not supported (no OCR); export CSV/Excel from internet banking.
- Sage layouts differ by version/export; the parser looks for Debit/Credit headers plus labelled Details/Reference columns.
