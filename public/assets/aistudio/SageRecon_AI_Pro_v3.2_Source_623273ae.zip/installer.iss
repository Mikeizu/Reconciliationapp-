#define MyAppName "SageRecon AI Pro"
#define MyAppVersion "3.2"
[Setup]
AppId={{F87D8AF5-1A8D-4B74-9B6B-8B7F8E04B5B1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={localappdata}\Programs\SageRecon AI Pro
DefaultGroupName={#MyAppName}
OutputDir=installer_output
OutputBaseFilename=SageRecon_AI_Pro_Setup
Compression=lzma
SolidCompression=yes
PrivilegesRequired=lowest
[Files]
Source: "dist\SageReconAIPro\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
[Icons]
Name: "{autoprograms}\SageRecon AI Pro"; Filename: "{app}\SageReconAIPro.exe"
Name: "{autodesktop}\SageRecon AI Pro"; Filename: "{app}\SageReconAIPro.exe"
[Run]
Filename: "{app}\SageReconAIPro.exe"; Description: "Launch SageRecon AI Pro"; Flags: nowait postinstall skipifsilent
