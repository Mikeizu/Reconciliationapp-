@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1 || (echo Python launcher not found. Install Python 3.12 x64. & pause & exit /b 1)
py -3.12 -c "import sys;print(sys.version)" >nul 2>&1 || (echo Python 3.12 required. Install from python.org & pause & exit /b 1)
if exist .venv rmdir /s /q .venv
py -3.12 -m venv .venv || goto fail
.venv\Scripts\python.exe -m pip install --upgrade pip || goto fail
.venv\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt || goto fail
.venv\Scripts\python.exe -m unittest discover -s tests -v || goto fail
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --windowed --onedir --name SageReconAIPro --paths app app\main.py || goto fail
echo BUILD SUCCESSFUL: dist\SageReconAIPro\SageReconAIPro.exe
echo Compile installer.iss using Inno Setup to create a desktop shortcut.
pause
exit /b 0
:fail
echo BUILD FAILED. Do not compile installer until build succeeds.
pause
exit /b 1
