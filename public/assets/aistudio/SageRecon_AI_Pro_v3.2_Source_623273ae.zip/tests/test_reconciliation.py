import csv
import datetime as dt
import sys
import tempfile
import time
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'app'))

import reconcile as R  # noqa: E402
from demo import build, write_files  # noqa: E402
from report import export_csv, export_xlsx  # noqa: E402

D = Decimal
d = lambda day, m=10: dt.date(2026, m, day)
START, END = d(1), d(31)


def tx(source, row, date, direction, amount, desc='', ref=''):
    return R._txn(source, row, date, direction, D(str(amount)), desc, ref)


def src(sage_tx, bank_tx, **kw):
    sage = dict(transactions=sage_tx, opening=kw.get('sage_open'), closing=kw.get('sage_close'),
                closing_date=kw.get('sage_close_date'), skipped=[], warnings=[])
    bank = dict(transactions=bank_tx, balance_rows=kw.get('balance_rows', []), skipped=[], warnings=[],
                integrity=kw.get('integrity', {}), stated_close=kw.get('stated_close'),
                stated_close_date=kw.get('stated_close_date'))
    return sage, bank


class Parsing(unittest.TestCase):
    def test_money_formats(self):
        cases = {'1,234.50': '1234.50', '(1,000.00)': '-1000.00', '1,000.00-': '-1000.00', '₦2,500': '2500.00',
                 'NGN 99.9': '99.90', '1.234,56': '1234.56', '12,5': '12.50', '500 CR': '500.00', '500 DR': '-500.00',
                 '1.234.567': '1234567.00', 12.345: '12.35', 7: '7.00', '−45.10': '-45.10'}
        for raw, want in cases.items():
            self.assertEqual(R.money(raw), D(want), raw)
        for bad in (None, '', '-', 'abc', True, float('nan')):
            self.assertIsNone(R.money(bad), bad)

    def test_dates(self):
        self.assertEqual(R.dateval('05/10/2026'), d(5))
        self.assertEqual(R.dateval('05/10/2026', 'mdy'), dt.date(2026, 5, 10))
        self.assertEqual(R.dateval('2026-10-05T14:30:00'), d(5))
        self.assertEqual(R.dateval('05/10/2026 14:30'), d(5))
        self.assertEqual(R.dateval('05-Oct-2026'), d(5))
        self.assertEqual(R.dateval('5 October 2026'), d(5))
        self.assertEqual(R.dateval(46300), dt.date(2026, 10, 5) + (dt.date(1899, 12, 30) + dt.timedelta(days=46300) - dt.date(2026, 10, 5)))
        self.assertIsNone(R.dateval('not a date'))
        self.assertEqual(R.infer_date_order(['13/05/2026', '02/03/2026']), 'dmy')
        self.assertEqual(R.infer_date_order(['05/13/2026', '02/03/2026']), 'mdy')

    def test_header_detection_with_currency_labels(self):
        rows = [['Statement'], ['Txn Date', 'Narration', 'Withdrawals (₦)', 'Deposits (NGN)', 'Balance (₦)']]
        c = R.header_candidates(rows)
        self.assertTrue(c)
        _, hi, m = c[0]
        self.assertEqual(hi, 1)
        self.assertEqual(m, dict(date=0, description=1, withdrawal=2, deposit=3, balance=4))

    def test_bank_single_amount_column_and_stated_balance(self):
        rows = [['Closing balance', '', '', '1,100.00'], ['Date', 'Narration', 'Amount', 'Balance'],
                ['01/10/2026', 'A', '-100.00', '900.00'], ['02/10/2026', 'B', '200.00', '1,100.00']]
        m = R.detect_mapping(rows, 1)
        b = R.bank_parse(rows, 1, m)
        self.assertEqual([(t['direction'], t['amount']) for t in b['transactions']], [('out', D('100')), ('in', D('200'))])
        self.assertEqual(b['stated_close'], D('1100.00'))
        flipped = R.bank_parse(rows, 1, m, amount_sign='positive_withdrawal')
        self.assertEqual(flipped['transactions'][0]['direction'], 'in')

    def test_bank_rows_with_bad_dates_are_reported_not_dropped_silently(self):
        rows = [['Date', 'Description', 'Withdrawal', 'Deposit'], ['01/10/2026', 'ok', '10', ''],
                ['someday', 'bad date', '55.00', ''], ['', 'Total', '65', '']]
        b = R.bank_parse(rows, 0, dict(date=0, description=1, withdrawal=2, deposit=3))
        self.assertEqual(len(b['transactions']), 1)
        self.assertEqual([s['row'] for s in b['skipped']], [3])

    def test_descending_statement_balances(self):
        rows = [['Date', 'Description', 'Withdrawal', 'Deposit', 'Balance'],
                ['03/10/2026', 'c', '', '50', '1050'], ['02/10/2026', 'b', '', '0.01', '1000.00'],
                ['01/10/2026', 'a', '', '1000', '999.99']]
        rows[2][4] = '1000'
        rows[2][3] = '1000'     # b: +1000 (bal 1000)  -> a: 1000 deposit?? make consistent below
        rows = [['Date', 'Description', 'Withdrawal', 'Deposit', 'Balance'],
                ['03/10/2026', 'c', '', '50', '1150'], ['02/10/2026', 'b', '100', '', '1100'],
                ['01/10/2026', 'a', '', '200', '1200']]
        b = R.bank_parse(rows, 0, dict(date=0, description=1, withdrawal=2, deposit=3, balance=4))
        self.assertEqual(b['integrity']['order'], 'descending')
        self.assertEqual(b['integrity']['breaks'], [])

    def test_balance_break_detected(self):
        rows = [['Date', 'Description', 'Withdrawal', 'Deposit', 'Balance'], ['01/10/2026', 'a', '', '100', '100'],
                ['02/10/2026', 'b', '', '50', '999']]
        b = R.bank_parse(rows, 0, dict(date=0, description=1, withdrawal=2, deposit=3, balance=4))
        self.assertEqual(b['integrity']['breaks'], [3])
        self.assertTrue(any('does not reconcile' in w for w in b['warnings']))

    def test_sage_labelled_columns_and_dates(self):
        s, _ = build()
        sg = R.sage_parse(s)
        self.assertEqual(sg['opening'], D('5000000.00'))
        self.assertEqual(sg['closing_date'], d(31))
        self.assertEqual(sg['report_range'], (d(1), d(31)))
        self.assertTrue(all(t['reference'] is not None for t in sg['transactions']))
        with self.assertRaises(ValueError):
            R.sage_parse([['nothing', 'here']])


class Period(unittest.TestCase):
    def test_suggest_period(self):
        sage, bank = src([tx('Sage', 1, d(5, 9), 'in', 1)], [tx('Bank', 1, d(5), 'in', 1), tx('Bank', 2, d(9), 'in', 1)])
        self.assertEqual(R.suggest_period(sage, bank), (d(1), d(31)))
        sage['report_range'] = (d(1, 9), d(30, 9))
        self.assertEqual(R.suggest_period(sage, bank), (d(1, 9), d(30, 9)))
        self.assertIsNone(R.suggest_period(None, None))


class Matching(unittest.TestCase):
    def test_directions_and_duplicates(self):  # original regression test, new API
        sg = [tx('Sage', i, d(10), dr, a) for i, dr, a in [(10, 'in', 100), (11, 'out', 15), (12, 'out', 15)]]
        bk = [tx('Bank', i, d(10), dr, a) for i, dr, a in [(10, 'in', 100), (11, 'out', 15), (12, 'in', 40)]]
        sage, bank = src(sg, bk, sage_close=D('1085'), sage_close_date=d(31),
                         balance_rows=[(20, d(31), D('1125'), D(0), D(0))])
        r = R.compare(sage, bank, START, END)
        self.assertEqual(len(r['matches']), 2)
        s = r['summary']
        self.assertEqual(s['sage_credits_missing_bank_withdrawals'], D('15'))
        self.assertEqual(s['bank_deposits_missing_sage_debits'], D('40'))
        self.assertEqual(r['statement']['raw_difference'], D('-40'))
        # 1125 + 0 - 15 = 1110 ; 1085 + 40 - 0 = 1125  -> not reconciled (data deliberately inconsistent)
        self.assertEqual(r['statement']['difference'], D('-15'))

    def test_wrong_direction_never_matches(self):
        sage, bank = src([tx('Sage', 1, d(5), 'in', 100)], [tx('Bank', 1, d(5), 'out', 100)])
        r = R.compare(sage, bank, START, END)
        self.assertEqual(len(r['matches']), 0)
        self.assertEqual(len(r['bank_only']), 1)

    def test_date_tolerance(self):
        sage, bank = src([tx('Sage', 1, d(5), 'in', 100)], [tx('Bank', 1, d(10), 'in', 100)])
        self.assertEqual(len(R.compare(sage, bank, START, END, days=3)['matches']), 0)
        self.assertEqual(len(R.compare(sage, bank, START, END, days=5)['matches']), 1)

    def test_reference_breaks_ties_between_equal_amounts(self):
        sg = [tx('Sage', 1, d(5), 'out', 500, 'pay A', 'REF11111'), tx('Sage', 2, d(5), 'out', 500, 'pay B', 'REF22222')]
        bk = [tx('Bank', 1, d(5), 'out', 500, 'TRF REF22222'), tx('Bank', 2, d(5), 'out', 500, 'TRF REF11111')]
        r = R.compare(*src(sg, bk), START, END)
        pairs = {m['sage'][0]['row']: m['bank'][0]['row'] for m in r['matches']}
        self.assertEqual(pairs, {1: 2, 2: 1})

    def test_batch_deposit_grouping(self):
        sg = [tx('Sage', i, d(5 + i), 'in', a) for i, a in enumerate([100, 250, 300], 1)]
        bk = [tx('Bank', 1, d(9), 'in', 650)]
        r = R.compare(*src(sg, bk), START, END)
        self.assertEqual(len(r['matches']), 1)
        self.assertEqual(r['matches'][0]['kind'], 'group')
        self.assertEqual(len(r['matches'][0]['sage']), 3)
        self.assertFalse(r['sage_only'] or r['bank_only'])
        self.assertLessEqual(r['matches'][0]['confidence'], 84)   # groups are never "High"

    def test_group_does_not_steal_exact_matches(self):
        sg = [tx('Sage', 1, d(5), 'in', 100), tx('Sage', 2, d(5), 'in', 200), tx('Sage', 3, d(5), 'in', 300)]
        bk = [tx('Bank', 1, d(5), 'in', 300), tx('Bank', 2, d(5), 'in', 100), tx('Bank', 3, d(5), 'in', 200)]
        r = R.compare(*src(sg, bk), START, END)
        self.assertTrue(all(m['kind'] == 'exact' for m in r['matches']))

    def test_suggestions_transposition_keying_timing_and_close(self):
        sg = [tx('Sage', 1, d(5), 'out', '1234.56'), tx('Sage', 2, d(6), 'out', '800.00'),
              tx('Sage', 3, d(2), 'in', 900), tx('Sage', 4, d(7), 'out', '1000.00')]
        bk = [tx('Bank', 1, d(5), 'out', '1243.56'), tx('Bank', 2, d(6), 'out', '815.00'),
              tx('Bank', 3, d(20), 'in', 900), tx('Bank', 4, d(7), 'out', '1010.00')]
        r = R.compare(*src(sg, bk), START, END)
        kinds = {s['sage']['row']: s['kind'] for s in r['suggestions']}
        self.assertEqual(kinds[1], 'transposition')
        self.assertEqual(kinds[2], 'close_amount')
        self.assertEqual(kinds[3], 'timing')
        self.assertEqual(kinds[4], 'keying')
        self.assertEqual(r['matches'], [])          # suggestions are never auto-accepted

    def test_classification_of_bank_items(self):
        bk = [tx('Bank', 1, d(31), 'out', '53.75', 'VAT ON CHARGES'), tx('Bank', 2, d(31), 'in', 1000, 'CREDIT INTEREST'),
              tx('Bank', 3, d(30), 'out', 5000, 'Reversal of trf'), tx('Bank', 4, d(30), 'out', 9999, 'NIP to John')]
        r = R.compare(*src([], bk), START, END)
        cats = {x['row']: x['category'] for x in r['bank_only']}
        self.assertEqual(cats, {1: 'Bank charge', 2: 'Bank interest', 3: 'Reversal / return', 4: 'Unrecorded payment'})

    def test_period_filter_and_lookback(self):
        sg = [tx('Sage', 1, d(28, 9), 'out', 70)]
        bk = [tx('Bank', 1, d(2), 'out', 70)]
        self.assertEqual(len(R.compare(*src(sg, bk), START, END, days=3)['matches']), 0)
        r = R.compare(*src(sg, bk), START, END, days=3, lookback=10)
        self.assertEqual(len(r['matches']), 0)               # 4 days apart - still beyond tolerance
        r = R.compare(*src(sg, bk), START, END, days=5, lookback=10)
        self.assertEqual(len(r['matches']), 1)


class Statement(unittest.TestCase):
    def setUp(self):
        s, b = build()
        self.sg = R.sage_parse(s)
        _, hi, m = R.header_candidates(b)[0]
        self.bk = R.bank_parse(b, hi, m)
        self.r = R.compare(self.sg, self.bk, START, END)

    def test_demo_statement_proves_to_zero(self):
        st = self.r['statement']
        self.assertEqual(st['difference'], D('0.00'))
        self.assertTrue(st['reconciled'])
        self.assertEqual(st['bank_close_src'], 'last running balance on 31/10/2026')

    def test_demo_finds_expected_exceptions(self):
        cats = sorted(x['category'] for x in self.r['bank_only'])
        self.assertEqual(cats.count('Bank charge'), 4)
        self.assertIn('Bank interest', cats)
        self.assertEqual(self.r['summary']['n_groups'], 1)
        self.assertIn('Possible duplicate', [x['category'] for x in self.r['sage_only']])
        self.assertTrue(any(s['kind'] == 'ref_mismatch' and 'transposed' in s['detail'] for s in self.r['suggestions']))

    def test_accepting_suggestion_keeps_proof_via_amount_adjustment(self):
        sid = next(s['id'] for s in self.r['suggestions'] if s['kind'] == 'ref_mismatch')
        before = len(self.r['bank_only'])
        R.accept_suggestion(self.r, sid)
        self.assertEqual(len(self.r['bank_only']), before - 1)
        st = self.r['statement']
        self.assertEqual(st['amount_adjustments'], D('-9.00'))     # bank paid 9.00 more than Sage recorded
        self.assertEqual(st['difference'], D('0.00'))

    def test_unmatch_restores_items(self):
        mid = self.r['matches'][0]['id']
        n = len(self.r['matches'])
        R.unmatch(self.r, mid)
        self.assertEqual(len(self.r['matches']), n - 1)
        self.assertEqual(self.r['statement']['difference'], D('0.00'))

    def test_manual_match_validation(self):
        with self.assertRaises(ValueError):
            R.manual_match(self.r, [], [self.r['bank_only'][0]['id']])
        a = next(x for x in self.r['bank_only'] if x['direction'] == 'in')
        b = next(x for x in self.r['sage_only'] if x['direction'] == 'out')
        with self.assertRaises(ValueError):
            R.manual_match(self.r, [b['id']], [a['id']])

    def test_manual_balance_override_and_missing_balance_never_zero(self):
        bank = dict(self.bk, balance_rows=[], integrity={}, stated_close=None)
        sage = dict(self.sg, opening=None, closing=None)
        r = R.compare(sage, bank, START, END)
        self.assertIsNone(r['statement']['bank_close'])
        self.assertIsNone(r['statement']['difference'])
        self.assertTrue(any('cannot be completed' in i['title'] for i in r['insights']))
        R.set_manual_balance(r, 'bank_close', self.r['statement']['bank_close'])
        R.set_manual_balance(r, 'sage_close', self.r['statement']['sage_close'])
        self.assertEqual(r['statement']['difference'], D('0.00'))
        self.assertEqual(r['statement']['bank_close_src'], 'entered manually')

    def test_unexplained_difference_is_surfaced_with_explainer(self):
        R.set_manual_balance(self.r, 'bank_close', self.r['statement']['bank_close'] + D('500000.00'))
        st = self.r['statement']
        self.assertEqual(st['difference'], D('500000.00'))
        self.assertTrue(any('equals the difference' in e for e in st['explainers']))

    def test_ignored_rows_raise_flag(self):
        self.bk['skipped'] = [dict(row=99, reason='Date not recognised', amount=D('42'), text='x')]
        r = R.compare(self.sg, self.bk, START, END)
        self.assertTrue(any('ignored' in f['title'] and f['level'] == 'High' for f in r['flags']))


class Exports(unittest.TestCase):
    def test_xlsx_and_csv(self):
        from openpyxl import load_workbook
        s, b = build()
        sg = R.sage_parse(s)
        _, hi, m = R.header_candidates(b)[0]
        r = R.compare(sg, R.bank_parse(b, hi, m), START, END)
        with tempfile.TemporaryDirectory() as t:
            x, c = Path(t) / 'r.xlsx', Path(t) / 'r.csv'
            export_xlsx(r, x, company='Demo Ltd', account='Operating')
            export_csv(r, c)
            wb = load_workbook(x)
            self.assertEqual(wb.sheetnames, ['Reconciliation', 'Bank not in Sage', 'Sage not on Bank', 'Matched',
                                             'Suggestions', 'Data quality', 'Proposed journals'])
            self.assertEqual(wb['Bank not in Sage'].max_row - 1, len(r['bank_only']))
            self.assertTrue(any(str(cell.value).startswith('=IF(') for row in wb['Reconciliation'].iter_rows() for cell in row))
            self.assertGreater(len(list(csv.reader(open(c, encoding='utf-8-sig')))), 30)

    def test_demo_files_roundtrip_through_readers(self):
        with tempfile.TemporaryDirectory() as t:
            sp, bp = write_files(t)
            sg = R.sage_parse(R.read_rows(sp))
            rows = R.read_rows(bp)
            _, hi, m = R.header_candidates(rows)[0]
            bk = R.bank_parse(rows, hi, m)
            r = R.compare(sg, bk, START, END)
            self.assertEqual(r['statement']['difference'], D('0.00'))
            self.assertEqual(len(r['matches']), 31)


class Performance(unittest.TestCase):
    def test_5000_by_5000(self):
        import random
        rnd = random.Random(1)
        sg, bk = [], []
        for i in range(5000):
            amt = D(rnd.randint(1000, 900000)) / 100
            dr = rnd.choice(['in', 'out'])
            day = rnd.randint(1, 31)
            sg.append(tx('Sage', i + 2, d(day), dr, amt, f'pay {i}', str(10000 + i)))
            if i % 10:
                bk.append(tx('Bank', i + 2, d(min(31, day + rnd.randint(0, 2))), dr, amt, f'TRF {10000 + i}'))
        t0 = time.time()
        r = R.compare(*src(sg, bk), START, END)
        self.assertLess(time.time() - t0, 25)
        self.assertGreater(len(r['matches']), 4400)


if __name__ == '__main__':
    unittest.main()
