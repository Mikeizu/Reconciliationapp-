import datetime as dt
import sys
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'app'))

import plain  # noqa: E402
import reconcile as R  # noqa: E402
from demo import build  # noqa: E402

fmt = lambda v: f'₦{v:,.2f}'


def run():
    s, b = build()
    _, hi, m = R.header_candidates(b)[0]
    return R.compare(R.sage_parse(s), R.bank_parse(b, hi, m), dt.date(2026, 10, 1), dt.date(2026, 10, 31))


class PlainPlan(unittest.TestCase):
    def test_groups_and_counts(self):
        r = run()
        plan = plain.build_plan(r, fmt)
        keys = [g['key'] for g in plan['groups']]
        self.assertEqual(keys, ['pairs', 'bank_in', 'bulk', 'sage', 'timing'])
        self.assertEqual(plan['left'], 10)            # 2 pairs + 1 receipt + 5 bulk lines + 2 sage entries
        self.assertEqual(plan['done'], 0)
        self.assertTrue(next(g for g in plan['groups'] if g['key'] == 'timing')['collapsed'])
        bulk = next(g for g in plan['groups'] if g['key'] == 'bulk')
        self.assertEqual(len(bulk['tasks']), 2)       # one card for charges, one for interest
        self.assertIn('4 bank charges', bulk['tasks'][0]['headline'])

    def test_no_jargon_in_text(self):
        plan = plain.build_plan(run(), fmt)
        # only the app's own wording (headline/advice) - the detail lines quote the bank's narration verbatim
        text = ' '.join(t['headline'] + ' ' + t['advice'] for g in plan['groups'] for t in g['tasks']).lower()
        text += ' '.join(g['title'] + ' ' + g['intro'] for g in plan['groups']).lower()
        for word in ('debit', 'credit', 'withdrawal', 'reconciling item', 'suspense', 'category', 'ledger'):
            self.assertNotIn(word, text)

    def test_progress_and_timing_never_counted(self):
        r = run()
        for x in r['bank_only']:
            if x['category'] == 'Bank charge':
                R.set_reviewed(r, [x['id']])
        plan = plain.build_plan(r, fmt)
        self.assertEqual((plan['done'], plan['left']), (4, 6))
        bulk = next(g for g in plan['groups'] if g['key'] == 'bulk')['tasks'][0]
        self.assertTrue(bulk['done'])

    def test_status_messages(self):
        r = run()
        plan = plain.build_plan(r, fmt)
        self.assertEqual(plain.status(r, plan, fmt)['tone'], 'info')
        for g in plan['groups']:
            for t in g['tasks']:
                if t['kind'] == 'pair':
                    R.reject_suggestion(r, t['ids'][0])
        for x in r['bank_only'] + r['sage_only']:
            R.set_reviewed(r, [x['id']])
        plan = plain.build_plan(r, fmt)
        self.assertEqual(plain.status(r, plan, fmt)['tone'], 'good')
        R.set_manual_balance(r, 'bank_close', r['statement']['bank_close'] + Decimal('500'))
        self.assertEqual(plain.status(r, plain.build_plan(r, fmt), fmt)['tone'], 'bad')
        r2 = run()
        r2['statement']['difference'] = None
        self.assertEqual(plain.status(r2, plain.build_plan(r2, fmt), fmt)['tone'], 'warn')

    def test_rejected_pair_items_reappear_as_normal_cards(self):
        r = run()
        sid = r['suggestions'][0]['id']
        R.reject_suggestion(r, sid)
        plan = plain.build_plan(r, fmt)
        self.assertEqual(sum(t['kind'] == 'pair' for g in plan['groups'] for t in g['tasks']), len(r['suggestions']))
        self.assertGreater(plan['left'], 10 - 1)


if __name__ == '__main__':
    unittest.main()
