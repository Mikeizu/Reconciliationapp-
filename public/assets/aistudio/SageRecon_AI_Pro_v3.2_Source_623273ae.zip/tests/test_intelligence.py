import datetime as dt
import json
import sys
import tempfile
from decimal import Decimal
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'app'))

import assistant as A  # noqa: E402
import journals as J  # noqa: E402
import reconcile as R  # noqa: E402
from demo import build  # noqa: E402
from memory import Memory  # noqa: E402

D = Decimal
d = lambda day, m=10: dt.date(2026, m, day)
START, END = d(1), d(31)


def demo(memory=None):
    s, b = build()
    sg = R.sage_parse(s)
    _, hi, m = R.header_candidates(b)[0]
    return sg, R.bank_parse(b, hi, m), s, b


def tx(src, row, date, direction, amount, desc='', ref=''):
    return R._txn(src, row, date, direction, D(str(amount)), desc, ref)


def plain(sage_tx, bank_tx):
    return (dict(transactions=sage_tx, opening=None, closing=None, closing_date=None, skipped=[], warnings=[]),
            dict(transactions=bank_tx, balance_rows=[], skipped=[], warnings=[], integrity={}, stated_close=None, stated_close_date=None))


class Learning(unittest.TestCase):
    def test_learned_link_breaks_a_tie_without_references(self):
        # two identical-amount payments the same day; narrations give no overlap, so without learning it is a coin-flip
        sg = [tx('Sage', 1, d(5), 'out', 1000, 'Acme Widgets'), tx('Sage', 2, d(5), 'out', 1000, 'Zenith Parts')]
        bk = [tx('Bank', 1, d(5), 'out', 1000, 'TRF OBINNA ENTERPRISES'), tx('Bank', 2, d(5), 'out', 1000, 'TRF KALU TRADERS')]
        mem = Memory()
        mem.learn([tx('Sage', 9, d(1), 'out', 5, 'Zenith Parts')], [tx('Bank', 9, d(1), 'out', 5, 'TRF OBINNA ENTERPRISES')])
        r = R.compare(*plain(sg, bk), START, END, memory=mem)
        pairs = {m['sage'][0]['row']: m['bank'][0]['row'] for m in r['matches']}
        self.assertEqual(pairs[2], 1)
        self.assertIn('learned', [m for m in r['matches'] if m['sage'][0]['row'] == 2][0]['reason'])

    def test_manual_match_teaches_memory_and_persists(self):
        sg = [tx('Sage', 1, d(5), 'out', 500, 'Customer Q')]
        bk = [tx('Bank', 1, d(20), 'out', 500, 'NIP TRF QUEEN ALOZIE')]
        mem = Memory()
        r = R.compare(*plain(sg, bk), START, END, memory=mem)
        R.manual_match(r, [r['sage_only'][0]['id']], [r['bank_only'][0]['id']], 'late payer')
        self.assertEqual(len(mem), 1)
        with tempfile.TemporaryDirectory() as t:
            mem.path = Path(t) / 'm.json'
            mem.save()
            self.assertEqual(len(Memory.load(mem.path)), 1)
        mem.forget()
        self.assertEqual(len(mem), 0)


class Risk(unittest.TestCase):
    def test_flags(self):
        sg, bk, *_ = demo()
        r = R.compare(sg, bk, START, END)
        flags = {x['row']: x['risks'] for x in r['bank_only']}
        self.assertEqual(flags[28], ['Round amount'])
        self.assertEqual(flags[40], [])         # month-end bank charges on a Saturday are not "weekend risk"


class Assistant(unittest.TestCase):
    def setUp(self):
        sg, bk, *_ = demo()
        self.r = R.compare(sg, bk, START, END)

    def test_queries(self):
        a = A.ask(self.r, 'bank charges')
        self.assertEqual((len(a['items']), a['total']), (4, D('5361.25')))
        self.assertEqual(len(A.ask(self.r, 'receipts not in Sage')['items']), 3)
        self.assertEqual(len(A.ask(self.r, 'top 2 largest')['items']), 2)
        self.assertEqual(A.ask(self.r, 'between 100k and 600k')['items'][0]['amount'], D('500000.00'))
        self.assertTrue(all(x['date'] > d(20) for x in A.ask(self.r, 'items after 20/10')['items']))
        self.assertEqual(A.ask(self.r, 'petty cash')['items'][0]['row'], 22)
        self.assertEqual(A.ask(self.r, 'duplicates')['items'][0]['category'], 'Possible duplicate')
        self.assertIn('no difference', A.ask(self.r, 'why is there a difference')['answer'])
        self.assertEqual(A.ask(self.r, 'zzzz qqqq')['items'], [])

    def test_difference_explained(self):
        R.set_manual_balance(self.r, 'bank_close', self.r['statement']['bank_close'] + D('500000'))
        self.assertIn('Unexplained difference', A.ask(self.r, 'why is the balance different')['answer'])


class Journals(unittest.TestCase):
    def test_entries_balance_and_group(self):
        sg, bk, *_ = demo()
        r = R.compare(sg, bk, START, END)
        ents = J.propose(r, dict(charges='6100 Bank charges'))
        self.assertTrue(all(J.balanced(e) for e in ents))
        chg = next(e for e in ents if e['kind'] == 'Bank charge')
        self.assertEqual(len(chg['lines']), 5)               # 4 charge lines + 1 bank credit
        self.assertEqual(chg['lines'][0]['account'], '6100 Bank charges')
        self.assertFalse(chg['needs_review'])
        self.assertTrue(all(e['needs_review'] for e in ents if e['kind'] not in ('Bank charge', 'Bank interest')))

    def test_amount_correction_entry(self):
        sg, bk, *_ = demo()
        r = R.compare(sg, bk, START, END)
        R.accept_suggestion(r, next(s['id'] for s in r['suggestions'] if s['kind'] == 'ref_mismatch'))
        adj = [e for e in J.propose(r) if e['kind'] == 'Amount correction']
        self.assertEqual(len(adj), 1)
        self.assertTrue(J.balanced(adj[0]))
        self.assertEqual(adj[0]['lines'][0]['debit'], D('9.00'))       # bank paid 9.00 more than Sage recorded


class Sessions(unittest.TestCase):
    def test_roundtrip_restores_review_work(self):
        sg, bk, *_ = demo()
        r1 = R.compare(sg, bk, START, END)
        R.accept_suggestion(r1, next(s['id'] for s in r1['suggestions'] if s['kind'] == 'ref_mismatch'))
        R.unmatch(r1, r1['matches'][0]['id'])
        R.set_note(r1, r1['bank_only'][0]['id'], 'chase')
        R.set_reviewed(r1, [r1['bank_only'][1]['id']])
        R.reject_suggestion(r1, r1['suggestions'][0]['id'])
        R.set_manual_balance(r1, 'bank_close', D('9715597.05'))
        state = json.loads(json.dumps(R.export_state(r1)))
        r2 = R.compare(sg, bk, START, END)
        out = R.apply_state(r2, state)
        self.assertEqual(out['skipped'], 0)
        self.assertEqual(len(r2['matches']), len(r1['matches']))
        self.assertEqual(r2['notes'], r1['notes'])
        self.assertEqual(r2['reviewed'], r1['reviewed'])
        self.assertEqual(r2['statement']['difference'], r1['statement']['difference'])
        self.assertEqual(len(r2['suggestions']), len(r1['suggestions']))

    def test_missing_ids_are_skipped_safely(self):
        sg, bk, *_ = demo()
        r = R.compare(sg, bk, START, END)
        out = R.apply_state(r, dict(matches=[dict(sage=['S999+'], bank=['B999+'], note='')], notes={'B999+': 'x'}, reviewed=['B999+']))
        self.assertEqual((out['applied'], out['skipped']), (0, 1))
        self.assertEqual(r['notes'], {})


class FileDetection(unittest.TestCase):
    def test_classify(self):
        _, _, s, b = demo()
        self.assertEqual(R.classify_file(s)[0], 'sage')
        self.assertEqual(R.classify_file(b)[0], 'bank')
        self.assertEqual(R.classify_file([['hello', 'world'], [1, 2]])[0], 'unknown')
        self.assertEqual(R.classify_file([['Txn Date', 'Narration', 'Paid out', 'Paid in', 'Balance']])[0], 'bank')


if __name__ == '__main__':
    unittest.main()
