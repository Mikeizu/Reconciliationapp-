"""Headless-friendly GUI smoke test: skipped automatically when no display / Tk is available."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'app'))

try:
    import tkinter as tk
    _root = tk.Tk()
    _root.destroy()
    HAVE_TK = True
except Exception:  # noqa: BLE001
    HAVE_TK = False


@unittest.skipUnless(HAVE_TK, 'no display available')
class GuiSmoke(unittest.TestCase):
    def test_full_flow(self):
        from tkinter import messagebox
        import main
        messagebox.askyesno = lambda *a, **k: True
        messagebox.showinfo = messagebox.showwarning = messagebox.showerror = lambda *a, **k: None
        tmp = Path(tempfile.mkdtemp())
        main.MEMORY_PATH, main.SETTINGS = tmp / 'm.json', tmp / 's.json'
        root = tk.Tk()
        try:
            app = main.App(root)
            self.assertIn('Welcome', app.coach_text['text'])
            app.load_demo()
            for _ in range(80):
                root.update()
                if app.result:
                    break
                import time
                time.sleep(0.05)
            self.assertTrue(app.result)
            self.assertTrue(app.result['statement']['reconciled'])
            self.assertEqual(app.g_bank.count, 8)
            app.ask_preset('bank charges')
            self.assertEqual(app.g_ask.count, 4)
            self.assertEqual(len(app._entries), 5)
            self.assertIn('guided review', app.coach_btn['text'].lower())
        finally:
            root.destroy()


if __name__ == '__main__':
    unittest.main()
