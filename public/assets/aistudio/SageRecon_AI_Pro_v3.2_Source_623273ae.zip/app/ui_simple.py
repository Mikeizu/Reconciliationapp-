"""Simple view: two screens (choose files -> what needs attention), plain English, one obvious action at a time."""
from __future__ import annotations

import datetime as dt
import tkinter as tk
from decimal import Decimal
from tkinter import messagebox, simpledialog, ttk

import plain
import reconcile as R
from ui_widgets import (AMBER, AMBER_BG, BG, BLUE, BLUE_BG, BORDER, CARD, F, GREEN, GREEN_BG, MUTED, NAVY, RED, RED_BG,
                        TEAL, TEAL_D, TEAL_L, TEXT, ScrollFrame, WrapLabel, button)

TONES = {'good': (GREEN, GREEN_BG), 'info': (TEAL_D, TEAL_L), 'warn': (AMBER, AMBER_BG), 'bad': (RED, RED_BG), 'ok': (GREEN, GREEN_BG)}
CARD_COLOR = {'bad': RED, 'warn': AMBER, 'info': BLUE, 'ok': GREEN}
PAGE = 25          # cards shown per group before "show all"


def link(parent, text, cmd, bg=BG, fg=TEAL_D, size=10):
    lab = tk.Label(parent, text=text, bg=bg, fg=fg, font=(F(size)[0], size, 'underline'), cursor='hand2')
    lab.bind('<Button-1>', lambda e: cmd())
    return lab


class SimpleView(tk.Frame):
    MAXW = 920

    def __init__(self, parent, app):
        super().__init__(parent, bg=BG)
        self.app = app
        self.screen = 'start'
        self._last = None
        self.expanded, self.opened = set(), set()
        self.sf = ScrollFrame(self, bg=BG)
        self.sf.pack(fill='both', expand=True)
        self.col = tk.Frame(self.sf.inner, bg=BG)
        self.col.pack(fill='x', padx=40, pady=(26, 50))
        self.sf.canvas.bind('<Configure>', self._resize, add='+')

    def _resize(self, e):
        self.col.pack_configure(padx=max(24, (e.width - self.MAXW) // 2))

    # ------------------------------------------------------------------ refresh
    def refresh(self):
        a = self.app
        if self.screen == 'results' and not a.result:
            self.screen = 'start'
        y = self.sf.canvas.yview()[0] if self._last == self.screen else 0
        for w in self.col.winfo_children():
            w.destroy()
        (self._start if self.screen == 'start' else self._results)()
        self._last = self.screen
        self.update_idletasks()
        self.sf.canvas.yview_moveto(y)

    # ------------------------------------------------------------------ screen 1
    def _start(self):
        a, c = self.app, self.col
        tk.Label(c, text='Check your bank against your books', bg=BG, fg=NAVY, font=F(26, 'bold')).pack(anchor='w')
        WrapLabel(c, text='Choose your two files. We find what matches, what is missing and what needs fixing - '
                          'and explain it in plain English. Your files never leave this computer.', bg=BG, fg=MUTED, font=F(12)).pack(fill='x', pady=(6, 20))
        row = tk.Frame(c, bg=BG)
        row.pack(fill='x')
        row.grid_columnconfigure((0, 1), weight=1, uniform='f')
        sage_sum = bank_sum = ''
        if a.sage:
            cl = a.sage.get('closing')
            sage_sum = f'{len(a.sage["transactions"])} entries' + (f'  •  closing balance {a.fmt(cl)}' if cl is not None else '')
        if a.bank:
            bank_sum = f'{len(a.bank["transactions"])} transactions'
        self._file_card(row, 0, '1', 'Your Sage file', 'The bank account report you export from Sage (Excel or CSV).',
                        a.sage_name if a.sage else '', sage_sum, a.pick_sage)
        self._file_card(row, 1, '2', 'Your bank statement', 'The statement you download from your bank (Excel or CSV).',
                        a.bank_name if a.bank else '', bank_sum, a.pick_bank)
        alt = tk.Frame(c, bg=BG)
        alt.pack(fill='x', pady=(10, 6))
        link(alt, 'Choose both files at once', a.pick_both).pack(side='left')
        tk.Label(alt, text='   •   ', bg=BG, fg=MUTED).pack(side='left')
        link(alt, 'Try it with sample data', a.load_demo).pack(side='left')

        probs = list(getattr(a, 'bank_problems', [])) + list(getattr(a, 'sage_problems', []))
        if probs:
            box = tk.Frame(c, bg=AMBER_BG, highlightbackground='#ecd9a6', highlightthickness=1)
            box.pack(fill='x', pady=(10, 4))
            tk.Label(box, text="We had trouble reading part of your files", bg=AMBER_BG, fg=AMBER, font=F(11, 'bold')).pack(anchor='w', padx=14, pady=(10, 2))
            for p in probs[:4]:
                WrapLabel(box, pad=40, text='•  ' + p, bg=AMBER_BG, fg=TEXT, font=F(10)).pack(fill='x', padx=14)
            tk.Frame(box, bg=AMBER_BG, height=4).pack()
            button(box, 'Open advanced settings to fix this', lambda: a.set_view('detailed'), 'ghost', pady=5, font=F(9, 'bold')).pack(anchor='w', padx=14, pady=(2, 12))

        ready = bool(a.sage and a.bank)
        if ready and a.start.get() and a.end.get():
            pr = tk.Frame(c, bg=BG)
            pr.pack(fill='x', pady=(14, 0))
            try:
                s, e = dt.datetime.strptime(a.start.get(), '%d/%m/%Y'), dt.datetime.strptime(a.end.get(), '%d/%m/%Y')
                txt = f'We will check  {plain.day(s)}  to  {plain.day(e)}'
            except ValueError:
                txt = 'Check the dates'
            tk.Label(pr, text=txt, bg=BG, fg=TEXT, font=F(11, 'bold')).pack(side='left')
            tk.Label(pr, text='  (found automatically)  ', bg=BG, fg=MUTED, font=F(10)).pack(side='left')
            link(pr, 'Change dates', self.change_dates).pack(side='left')
        go = button(c, 'Check my reconciliation  →' if ready else 'Choose both files to continue', a.run if ready else (lambda: None),
                    'primary' if ready else 'ghost', pady=15, font=F(14, 'bold'))
        if not ready:
            go.config(state='disabled', fg='#9aa8b8')
        go.pack(fill='x', pady=(18, 10))
        foot = tk.Frame(c, bg=BG)
        foot.pack(fill='x', pady=(8, 0))
        link(foot, 'How does this work?', self.help).pack(side='left')
        tk.Label(foot, text='   •   Nothing is ever changed in Sage.', bg=BG, fg=MUTED, font=F(10)).pack(side='left')

    def _file_card(self, parent, col, num, title, hint, name, summary, cmd):
        f = tk.Frame(parent, bg=CARD, highlightbackground=GREEN if name else BORDER, highlightthickness=2 if name else 1)
        f.grid(row=0, column=col, sticky='nsew', padx=(0 if col == 0 else 10, 0))
        head = tk.Frame(f, bg=CARD)
        head.pack(fill='x', padx=18, pady=(16, 4))
        tk.Label(head, text=num, bg=GREEN if name else TEAL, fg='white', font=F(12, 'bold'), width=2).pack(side='left', padx=(0, 10))
        tk.Label(head, text=title, bg=CARD, fg=NAVY, font=F(14, 'bold')).pack(side='left')
        WrapLabel(f, pad=40, text=hint, bg=CARD, fg=MUTED, font=F(10)).pack(fill='x', padx=18, pady=(0, 10))
        if name:
            tk.Label(f, text='✓  ' + name, bg=CARD, fg=GREEN, font=F(11, 'bold'), anchor='w').pack(fill='x', padx=18)
            tk.Label(f, text=summary, bg=CARD, fg=MUTED, font=F(10), anchor='w').pack(fill='x', padx=18, pady=(2, 8))
            link(f, 'Choose a different file', cmd, bg=CARD).pack(anchor='w', padx=18, pady=(0, 16))
        else:
            button(f, '＋   Choose file…', cmd, 'primary', pady=14, font=F(12, 'bold')).pack(fill='x', padx=18, pady=(4, 18))

    def change_dates(self):
        a = self.app
        d = tk.Toplevel(a.root)
        d.title('Dates to check')
        d.configure(bg=BG)
        d.transient(a.root)
        d.grab_set()
        d.geometry('+%d+%d' % (a.root.winfo_rootx() + 300, a.root.winfo_rooty() + 200))
        tk.Label(d, text='Which dates should we check?', bg=BG, fg=NAVY, font=F(13, 'bold')).grid(row=0, column=0, columnspan=2, padx=22, pady=(18, 4), sticky='w')
        tk.Label(d, text='Type them as day/month/year, for example 01/10/2026.', bg=BG, fg=MUTED, font=F(10)).grid(row=1, column=0, columnspan=2, padx=22, sticky='w')
        s, e = tk.StringVar(value=a.start.get()), tk.StringVar(value=a.end.get())
        for i, (lab, var) in enumerate((('From', s), ('To', e))):
            tk.Label(d, text=lab, bg=BG, font=F(11)).grid(row=2 + i, column=0, padx=(22, 8), pady=8, sticky='w')
            ttk.Entry(d, textvariable=var, width=16, font=F(11)).grid(row=2 + i, column=1, padx=(0, 22), sticky='w')

        def ok():
            try:
                x, y = dt.datetime.strptime(s.get().strip(), '%d/%m/%Y'), dt.datetime.strptime(e.get().strip(), '%d/%m/%Y')
            except ValueError:
                messagebox.showwarning('Check the dates', 'Please type both dates like 01/10/2026.', parent=d)
                return
            if x > y:
                messagebox.showwarning('Check the dates', 'The first date must come before the second.', parent=d)
                return
            a.start.set(s.get().strip())
            a.end.set(e.get().strip())
            a.period_touched = True
            d.destroy()
            self.refresh()
        row = tk.Frame(d, bg=BG)
        row.grid(row=4, column=0, columnspan=2, pady=(6, 18), padx=22, sticky='e')
        button(row, 'Cancel', d.destroy, 'ghost').pack(side='left', padx=(0, 8))
        button(row, 'OK', ok).pack(side='left')

    # ------------------------------------------------------------------ screen 2
    def _results(self):
        a, r, c = self.app, self.app.result, self.col
        plan = plain.build_plan(r, a.fmt)
        top = tk.Frame(c, bg=BG)
        top.pack(fill='x')
        link(top, '←  Start over', a.reset_all).pack(side='left')
        st = plain.status(r, plan, a.fmt)
        fg, bg = TONES[st['tone']]
        ban = tk.Frame(c, bg=bg, highlightbackground=fg, highlightthickness=1)
        ban.pack(fill='x', pady=(10, 12))
        icon = {'good': '✓', 'info': '●', 'warn': '!', 'bad': '✕'}[st['tone']]
        tk.Label(ban, text=f'{icon}  {st["title"]}', bg=bg, fg=fg, font=F(20, 'bold'), anchor='w', wraplength=820, justify='left').pack(fill='x', padx=20, pady=(16, 4))
        WrapLabel(ban, pad=50, text=st['sub'], bg=bg, fg=TEXT, font=F(11)).pack(fill='x', padx=20, pady=(0, 16))
        # tiles
        S = r['summary']
        tiles = tk.Frame(c, bg=BG)
        tiles.pack(fill='x', pady=(0, 6))
        tiles.grid_columnconfigure((0, 1, 2), weight=1, uniform='t')
        matched = sum(len(m['bank']) for m in r['matches'])
        diff = r['statement']['difference']
        for i, (big, label, sub, color) in enumerate((
                (f'{matched} of {S["n_bank"]}', 'bank entries matched', 'found automatically in Sage', NAVY),
                (str(plan['left']), 'to look at' if plan['left'] != 1 else 'to look at', f'{plan["done"]} already done', GREEN if plan['left'] == 0 else AMBER),
                ('-' if diff is None else a.fmt(diff), 'unexplained difference', 'should be zero', GREEN if diff == 0 else RED if diff is not None else AMBER))):
            t = tk.Frame(tiles, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            t.grid(row=0, column=i, sticky='nsew', padx=(0 if i == 0 else 8, 0))
            tk.Label(t, text=big, bg=CARD, fg=color, font=F(20, 'bold')).pack(anchor='w', padx=16, pady=(12, 0))
            tk.Label(t, text=label, bg=CARD, fg=TEXT, font=F(10, 'bold')).pack(anchor='w', padx=16)
            tk.Label(t, text=sub, bg=CARD, fg=MUTED, font=F(9)).pack(anchor='w', padx=16, pady=(0, 12))
        # missing closing balance
        stt = r['statement']
        if stt['bank_close'] is None or stt['sage_close'] is None:
            self._balance_box(c, stt)
        # to-do list
        if plan['groups']:
            head = tk.Frame(c, bg=BG)
            head.pack(fill='x', pady=(18, 4))
            tk.Label(head, text='What needs your attention', bg=BG, fg=NAVY, font=F(17, 'bold')).pack(side='left')
            tk.Label(head, text=f'{plan["done"]} of {plan["total"]} done' if plan['total'] else '', bg=BG, fg=MUTED, font=F(11)).pack(side='right')
            if plan['total']:
                pb = ttk.Progressbar(c, maximum=plan['total'], value=plan['done'], style='Light.Horizontal.TProgressbar')
                pb.pack(fill='x', pady=(0, 6))
            for g in plan['groups']:
                self._group(g)
        else:
            tk.Label(c, text='Nothing needs your attention. 🎉', bg=BG, fg=GREEN, font=F(14, 'bold')).pack(anchor='w', pady=18)
        # downloads
        dl = tk.Frame(c, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        dl.pack(fill='x', pady=(26, 6))
        tk.Label(dl, text='Save your results', bg=CARD, fg=NAVY, font=F(14, 'bold')).pack(anchor='w', padx=20, pady=(16, 2))
        WrapLabel(dl, pad=50, text='The Excel report is a neat summary to keep with your month-end records. The journal file lists the entries '
                                   'to record in Sage (it is only a suggestion - nothing is posted for you).', bg=CARD, fg=MUTED, font=F(10)).pack(fill='x', padx=20)
        row = tk.Frame(dl, bg=CARD)
        row.pack(fill='x', padx=20, pady=(10, 18))
        button(row, '⬇   Download Excel report', a.export_excel, pady=11, font=F(11, 'bold')).pack(side='left')
        button(row, 'Download journal entries', a.export_journals, 'ghost', pady=11).pack(side='left', padx=10)
        tk.Frame(c, bg=BG, height=16).pack()
        foot = tk.Frame(c, bg=BG)
        foot.pack(fill='x')
        link(foot, 'How does this work?', self.help).pack(side='left')

    def _balance_box(self, c, stt):
        a = self.app
        box = tk.Frame(c, bg=CARD, highlightbackground=AMBER, highlightthickness=2)
        box.pack(fill='x', pady=(8, 4))
        tk.Label(box, text='Please type in the closing balance', bg=CARD, fg=AMBER, font=F(13, 'bold')).pack(anchor='w', padx=18, pady=(14, 2))
        WrapLabel(box, pad=50, text='It is usually the last number on the statement or report. Without it we cannot prove everything adds up.',
                  bg=CARD, fg=MUTED, font=F(10)).pack(fill='x', padx=18)
        vars_ = {}
        for key, label in (('bank_close', 'Closing balance on your bank statement'), ('sage_close', 'Closing balance in Sage')):
            if stt[key] is None:
                row = tk.Frame(box, bg=CARD)
                row.pack(fill='x', padx=18, pady=6)
                tk.Label(row, text=label, bg=CARD, fg=TEXT, font=F(11), width=36, anchor='w').pack(side='left')
                vars_[key] = tk.StringVar()
                ttk.Entry(row, textvariable=vars_[key], width=18, font=F(11)).pack(side='left')

        def apply():
            changed = False
            for k, v in vars_.items():
                if v.get().strip():
                    val = R.money(v.get())
                    if val is None:
                        messagebox.showwarning('Check the number', 'Please type the balance as a number, for example 1,250,000.00')
                        return
                    R.set_manual_balance(a.result, k, val)
                    changed = True
            if changed:
                a._after_change('Closing balance saved.')
        button(box, 'Save balance', apply, pady=8).pack(anchor='w', padx=18, pady=(6, 16))

    # ------------------------------------------------------------------ to-do cards
    def _group(self, g):
        c = self.col
        key, tasks = g['key'], g['tasks']
        pending = sum(1 for t in tasks if not t['done'])
        wrap = tk.Frame(c, bg=BG)
        wrap.pack(fill='x', pady=(14, 0))
        head = tk.Frame(wrap, bg=BG)
        head.pack(fill='x')
        collapsed = g['collapsed'] and key not in self.opened
        arrow = ('▸  ' if collapsed else '▾  ') if g['collapsed'] else ''
        title = tk.Label(head, text=arrow + g['title'], bg=BG, fg=NAVY, font=F(13, 'bold'), cursor='hand2' if g['collapsed'] else '')
        title.pack(side='left')
        pill = f'{len(tasks)}' if g['collapsed'] else (f'{pending} to do' if pending else 'all done ✓')
        tk.Label(head, text=f'  {pill}', bg=BG, fg=MUTED if pending or g['collapsed'] else GREEN, font=F(10, 'bold')).pack(side='left')
        if g['collapsed']:
            title.bind('<Button-1>', lambda e: (self.opened.symmetric_difference_update({key}), self.refresh()))
        if collapsed:
            return
        WrapLabel(wrap, text=g['intro'], bg=BG, fg=MUTED, font=F(10)).pack(fill='x', pady=(0, 2))
        shown = tasks if key in self.expanded else tasks[:PAGE]
        for t in shown:
            self._card(wrap, t)
        if len(tasks) > len(shown):
            button(wrap, f'Show all {len(tasks)}', lambda: (self.expanded.add(key), self.refresh()), 'ghost', pady=6).pack(anchor='w', pady=6)

    def _card(self, parent, t):
        a = self.app
        done = t['done']
        bg = '#f1f5f9' if done else CARD
        f = tk.Frame(parent, bg=bg, highlightbackground=BORDER, highlightthickness=1)
        f.pack(fill='x', pady=5)
        tk.Frame(f, bg=GREEN if done else CARD_COLOR.get(t['tone'], BLUE), width=6).pack(side='left', fill='y')
        body = tk.Frame(f, bg=bg)
        body.pack(side='left', fill='both', expand=True, padx=16, pady=12)
        tk.Label(body, text=('✓  ' if done else '') + t['headline'], bg=bg, fg=MUTED if done else NAVY, font=F(12, 'bold'),
                 anchor='w', justify='left', wraplength=760).pack(fill='x')
        if not done:
            WrapLabel(body, pad=50, text=t['detail'], bg=bg, fg=MUTED, font=F(10)).pack(fill='x', pady=(3, 0))
            WrapLabel(body, pad=50, text=('→  ' + t['advice']) if t['kind'] != 'pair' else t['advice'], bg=bg, fg=TEAL_D, font=F(10, 'bold')).pack(fill='x', pady=(6, 8))
        row = tk.Frame(body, bg=bg)
        row.pack(fill='x', pady=(2 if done else 0, 0))
        ids = t['ids']
        if t['kind'] == 'pair':
            button(row, '✔  Yes, same transaction', lambda: self._pair(ids[0], True), pady=7).pack(side='left')
            button(row, '✖  No, different', lambda: self._pair(ids[0], False), 'ghost', pady=7).pack(side='left', padx=8)
        elif done:
            link(row, 'Undo', lambda: self._mark(ids, False), bg=bg).pack(side='left')
        elif t['kind'] == 'bulk':
            button(row, '✓  Got it - I will record these', lambda: self._mark(ids, True), pady=7).pack(side='left')
        else:
            button(row, '✓  Done', lambda: self._mark(ids, True), pady=7).pack(side='left')
            button(row, '📝  Add a note', lambda: self._note(ids[0]), 'ghost', pady=7).pack(side='left', padx=8)
            link(row, 'Link to another entry…', lambda: self._link(ids[0]), bg=bg).pack(side='left', padx=6)

    # ------------------------------------------------------------------ card actions
    def _mark(self, ids, flag):
        R.set_reviewed(self.app.result, ids, flag)
        self.app._after_change('Marked as done.' if flag else 'Moved back to the list.')

    def _note(self, iid):
        txt = simpledialog.askstring('Add a note', 'Write a short note (it appears in your Excel report):', parent=self.app.root)
        if txt is None:
            return
        R.set_note(self.app.result, iid, txt)
        R.set_reviewed(self.app.result, [iid])
        self.app._after_change('Note saved.')

    def _link(self, iid):
        pre_b, pre_s = ([iid], []) if iid.startswith('B') else ([], [iid])
        self.app.open_match(pre_b, pre_s)

    def _pair(self, sid, yes):
        if yes:
            R.accept_suggestion(self.app.result, sid)
            self.app._after_change('Matched.')
        else:
            R.reject_suggestion(self.app.result, sid)
            self.app._after_change('Okay - they will show up separately.')

    # ------------------------------------------------------------------ help
    def help(self):
        d = tk.Toplevel(self.app.root)
        d.title('How does this work?')
        d.configure(bg=BG)
        d.transient(self.app.root)
        d.geometry('660x640+%d+%d' % (self.app.root.winfo_rootx() + 220, self.app.root.winfo_rooty() + 60))
        qa = [('What does this app do?', 'It compares your Sage bank account with your bank statement, line by line. Entries that appear in both are '
                                         'matched automatically. What is left over is shown to you as a short list, with advice on what to do.'),
              ('Will it change my Sage data?', 'No. It only reads your two files. Nothing is changed, posted or sent anywhere.'),
              ('What are the two files?', 'From Sage, export the bank account transactions to Excel or CSV. From your bank\'s website, download the '
                                          'statement as Excel or CSV. PDF statements are not supported.'),
              ('What does "Done" mean?', 'It just ticks the item off your list so you can see your progress. It also shows in the Excel report.'),
              ('Why is something marked "Normal timing difference"?', 'Cheques and transfers take a few days to clear. Recent items that have not reached '
                                                                       'the bank yet are expected - nothing to do.'),
              ('I need more control.', 'Use "Detailed view" (top right) for column settings, date tolerance, manual matching and more.')]
        for q, ans in qa:
            tk.Label(d, text=q, bg=BG, fg=NAVY, font=F(11, 'bold'), anchor='w').pack(fill='x', padx=24, pady=(14, 0))
            WrapLabel(d, pad=48, text=ans, bg=BG, fg=TEXT, font=F(10)).pack(fill='x', padx=24)
        d.update_idletasks()
        button(d, 'Close', d.destroy).pack(pady=18)
