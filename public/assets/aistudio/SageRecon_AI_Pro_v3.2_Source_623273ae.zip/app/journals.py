"""Proposed adjusting entries for the items a reconciliation shows are missing from Sage.

Proposals only - they are never posted anywhere. Items whose correct account is unknown go to Suspense for a human.
"""
from __future__ import annotations

import csv
from decimal import Decimal

ZERO = Decimal('0.00')
DEFAULT_ACCOUNTS = dict(bank='Bank Current Account', charges='Bank Charges', interest='Interest Received',
                        suspense='Suspense / Unallocated')


def propose(r, accounts=None):
    """Return a list of entries: dict(no, date, reference, details, kind, needs_review, lines=[dict(account, debit, credit)])."""
    a = dict(DEFAULT_ACCOUNTS, **{k: v for k, v in (accounts or {}).items() if v})
    entries = []

    def add(date, ref, details, kind, review, lines):
        entries.append(dict(no=len(entries) + 1, date=date, reference=ref, details=details, kind=kind,
                            needs_review=review, lines=lines))

    # bank charges / interest are grouped per date: one entry per day and category
    groups = {}
    for x in sorted(r['bank_only'], key=lambda i: (i['date'], i['row'])):
        cat = x.get('category')
        if cat in ('Bank charge', 'Bank interest'):
            groups.setdefault((x['date'], cat), []).append(x)
    for (date, cat), items in groups.items():
        total = sum((i['amount'] for i in items), ZERO)
        if cat == 'Bank charge':
            lines = [dict(account=a['charges'], debit=i['amount'], credit=ZERO, note=i['description']) for i in items]
            lines.append(dict(account=a['bank'], debit=ZERO, credit=total, note=''))
            add(date, f'BANKCHG-{date:%Y%m%d}', f'Bank charges per statement ({len(items)} item(s))', cat, False, lines)
        else:
            lines = [dict(account=a['bank'], debit=total, credit=ZERO, note='')]
            lines += [dict(account=a['interest'], debit=ZERO, credit=i['amount'], note=i['description']) for i in items]
            add(date, f'BANKINT-{date:%Y%m%d}', f'Bank interest per statement ({len(items)} item(s))', cat, False, lines)
    for x in sorted(r['bank_only'], key=lambda i: (i['date'], i['row'])):
        if x.get('category') in ('Bank charge', 'Bank interest'):
            continue
        out = x['direction'] == 'out'
        lines = [dict(account=a['suspense'] if out else a['bank'], debit=x['amount'], credit=ZERO, note=x['description']),
                 dict(account=a['bank'] if out else a['suspense'], debit=ZERO, credit=x['amount'], note='')]
        add(x['date'], f"BANKROW-{x['row']}", f"{x['category']}: {x['description'] or x['reference'] or 'no narration'}",
            x['category'], True, lines)
    # amount differences on accepted/manual matches -> correct the Sage amount
    for m in r['matches']:
        diff = sum((x['amount'] for x in m['bank']), ZERO) - sum((x['amount'] for x in m['sage']), ZERO)
        if not diff:
            continue
        out = m['bank'][0]['direction'] == 'out'
        bank_credit = (diff > 0) == out            # extra cash left the bank, or less cash arrived
        amt = abs(diff)
        lines = [dict(account=a['suspense'], debit=amt, credit=ZERO, note='') if bank_credit else dict(account=a['bank'], debit=amt, credit=ZERO, note=''),
                 dict(account=a['bank'], debit=ZERO, credit=amt, note='') if bank_credit else dict(account=a['suspense'], debit=ZERO, credit=amt, note='')]
        add(m['bank'][0]['date'], f"AMTADJ-{m['bank'][0]['row']}",
            f"Correct Sage amount (Sage row {m['sage'][0]['row']} vs bank row {m['bank'][0]['row']}, difference {diff:+,.2f})",
            'Amount correction', True, lines)
    return entries


def balanced(entry):
    return sum((l['debit'] for l in entry['lines']), ZERO) == sum((l['credit'] for l in entry['lines']), ZERO)


def flat_rows(entries):
    out = []
    for e in entries:
        for l in e['lines']:
            out.append([e['no'], e['date'], e['reference'], l['account'], l.get('note') or e['details'], l['debit'], l['credit'],
                        'Yes' if e['needs_review'] else 'No', e['kind']])
    return out


HEADERS = ['Entry', 'Date', 'Reference', 'Account', 'Details', 'Debit', 'Credit', 'Needs review', 'Kind']


def export_csv(entries, path):
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(HEADERS)
        for row in flat_rows(entries):
            row = list(row)
            row[1] = f'{row[1]:%d/%m/%Y}'
            row[5] = row[5] if row[5] else ''
            row[6] = row[6] if row[6] else ''
            w.writerow(row)
