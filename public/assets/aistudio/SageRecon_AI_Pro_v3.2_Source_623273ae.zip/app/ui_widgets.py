"""Reusable Tk widgets + theme for SageRecon AI Pro."""
from __future__ import annotations

import sys
import tkinter as tk
from tkinter import ttk

# ------------------------------------------------------------------ palette
NAVY, NAVY2 = '#10243d', '#183556'
TEAL, TEAL_D, TEAL_L = '#087e86', '#06666d', '#e0f2f3'
BG, CARD, BORDER = '#f3f6fa', '#ffffff', '#d9e2ec'
TEXT, MUTED = '#1f2d3d', '#526174'
GREEN, AMBER, RED, BLUE = '#1a7f4b', '#b7791f', '#b42318', '#2563a8'
GREEN_BG, AMBER_BG, RED_BG, BLUE_BG = '#e8f6ee', '#fff5dc', '#fde8e5', '#e6eefa'

FONT = 'Segoe UI' if sys.platform.startswith('win') else 'DejaVu Sans'
F = lambda size=10, weight='normal': (FONT, size, weight)
MONO = ('Consolas' if sys.platform.startswith('win') else 'DejaVu Sans Mono', 10)

LEVEL_COLORS = {'Good': (GREEN, GREEN_BG), 'Info': (BLUE, BLUE_BG), 'Review': (AMBER, AMBER_BG),
                'Action': (RED, RED_BG), 'High': (RED, RED_BG), 'Medium': (AMBER, AMBER_BG), 'Low': (GREEN, GREEN_BG)}


def setup_style(root):
    s = ttk.Style(root)
    s.theme_use('clam')
    s.configure('.', font=F(10), background=BG)
    s.configure('Treeview', rowheight=28, font=F(10), background='white', fieldbackground='white',
                bordercolor=BORDER, lightcolor='white', darkcolor='white')
    s.configure('Treeview.Heading', font=F(10, 'bold'), background='#e7edf4', foreground=NAVY,
                relief='flat', padding=(8, 7), bordercolor=BORDER)
    s.map('Treeview.Heading', background=[('active', '#d6e0ec')])
    s.map('Treeview', background=[('selected', TEAL)], foreground=[('selected', 'white')])
    s.configure('TNotebook', background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
    s.configure('TNotebook.Tab', font=F(10, 'bold'), padding=(11, 9), background='#e7edf4', foreground=MUTED,
                borderwidth=0)
    s.map('TNotebook.Tab', background=[('selected', 'white')], foreground=[('selected', TEAL_D)])
    s.configure('TCombobox', padding=5, arrowsize=14)
    s.configure('TSpinbox', padding=4)
    s.configure('TEntry', padding=5)
    s.configure('Vertical.TScrollbar', background='#c9d4e0', troughcolor=BG, bordercolor=BG, arrowcolor=MUTED)
    s.configure('Horizontal.TScrollbar', background='#c9d4e0', troughcolor=BG, bordercolor=BG, arrowcolor=MUTED)
    s.configure('Teal.Horizontal.TProgressbar', troughcolor='#2a4a6e', background='#5fd0d6', bordercolor=NAVY)
    s.configure('Light.Horizontal.TProgressbar', troughcolor='#dfe7ef', background=TEAL, bordercolor='#dfe7ef', lightcolor=TEAL, darkcolor=TEAL)
    s.configure('TPanedwindow', background=BG)
    return s


def button(parent, text, command, kind='primary', **kw):
    palette = {'primary': (TEAL, 'white', TEAL_D), 'ghost': ('white', TEAL_D, TEAL_L),
               'danger': ('white', RED, RED_BG), 'dark': (NAVY2, 'white', NAVY)}
    bg, fg, hover = palette[kind]
    b = tk.Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=hover, activeforeground=fg,
                  font=kw.pop('font', F(10, 'bold')), relief='flat', bd=0, cursor='hand2',
                  padx=kw.pop('padx', 14), pady=kw.pop('pady', 8),
                  highlightthickness=1 if kind in ('ghost', 'danger') else 0,
                  highlightbackground=BORDER, **kw)
    b.bind('<Enter>', lambda e: b['state'] == 'normal' and b.config(bg=hover))
    b.bind('<Leave>', lambda e: b.config(bg=bg))
    return b


def card(parent, title=None, number=None, pad=14):
    outer = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
    if title:
        head = tk.Frame(outer, bg=CARD)
        head.pack(fill='x', padx=pad, pady=(12, 4))
        if number:
            tk.Label(head, text=str(number), bg=TEAL, fg='white', font=F(10, 'bold'), width=2).pack(side='left', padx=(0, 8))
        tk.Label(head, text=title, bg=CARD, fg=NAVY, font=F(12, 'bold')).pack(side='left')
        head.title_label = None
        outer.head = head
    body = tk.Frame(outer, bg=CARD)
    body.pack(fill='both', expand=True, padx=pad, pady=(4, 12))
    outer.body = body
    return outer


class WrapLabel(tk.Label):
    """Label whose wraplength follows its container width."""

    def __init__(self, parent, pad=0, **kw):
        kw.setdefault('justify', 'left')
        kw.setdefault('anchor', 'w')
        super().__init__(parent, **kw)
        self._pad, self._parent = pad, parent
        self._fid = parent.bind('<Configure>', self._resize, add='+')
        self.bind('<Destroy>', self._cleanup, add='+')

    def _resize(self, e):
        if self.winfo_exists():
            self.configure(wraplength=max(120, e.width - self._pad))

    def _cleanup(self, e):
        if e.widget is self:
            try:  # drop only our own handler; Tk cannot unbind by id, so rebind the survivors
                self._parent.unbind('<Configure>', self._fid)
            except tk.TclError:
                pass


class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg=BG):
        super().__init__(parent, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.vsb = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window((0, 0), window=self.inner, anchor='nw')
        self.inner.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>', lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.canvas.pack(side='left', fill='both', expand=True)
        self.vsb.pack(side='right', fill='y')
        self.bind('<Enter>', lambda e: self._wheel_on())
        self.bind('<Leave>', lambda e: self._wheel_off())

    def _wheel_on(self):
        self.canvas.bind_all('<MouseWheel>', self._wheel)
        self.canvas.bind_all('<Button-4>', self._wheel)
        self.canvas.bind_all('<Button-5>', self._wheel)

    def _wheel_off(self):
        for ev in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.canvas.unbind_all(ev)

    def _wheel(self, e):
        if self.inner.winfo_height() <= self.canvas.winfo_height():
            return
        step = -1 if (e.num == 4 or getattr(e, 'delta', 0) > 0) else 1
        self.canvas.yview_scroll(step * 2, 'units')

    def clear(self):
        for w in self.inner.winfo_children():
            w.destroy()


class Collapsible(tk.Frame):
    def __init__(self, parent, title, bg=CARD, open_=False):
        super().__init__(parent, bg=bg)
        self._title, self._open = title, open_
        self.toggle = tk.Label(self, text='', bg=bg, fg=TEAL_D, font=F(10, 'bold'), cursor='hand2', anchor='w')
        self.toggle.pack(fill='x')
        self.toggle.bind('<Button-1>', lambda e: self.flip())
        self.body = tk.Frame(self, bg=bg)
        self._sync()

    def set_open(self, state):
        self._open = bool(state)
        self._sync()

    def flip(self):
        self._open = not self._open
        self._sync()

    def _sync(self):
        self.toggle.config(text=('▾  ' if self._open else '▸  ') + self._title)
        if self._open:
            self.body.pack(fill='x', pady=(6, 0))
        else:
            self.body.pack_forget()


class Grid(tk.Frame):
    """Sortable, filterable Treeview with scrollbars.

    columns: (key, title, width, anchor, stretch)
    rows:    dict(iid=str, values=[...], sort=[...]|None, tag=str)
    """

    def __init__(self, parent, columns, on_select=None, multi=True, tags=None):
        super().__init__(parent, bg='white')
        self.columns = columns
        self.rows, self._visible = [], []
        self.sort_col, self.sort_rev, self.filter_text = None, False, ''
        self.on_select = on_select
        keys = [c[0] for c in columns]
        self.tree = ttk.Treeview(self, columns=keys, show='headings', selectmode='extended' if multi else 'browse')
        for key, title, width, anchor, stretch in columns:
            self.tree.heading(key, text=title, command=lambda k=key: self.sort_by(k))
            self.tree.column(key, width=width, minwidth=40, anchor=anchor, stretch=stretch)
        for name, (fg, bg) in (tags or {}).items():
            self.tree.tag_configure(name, background=bg, foreground=fg)
        self.tree.tag_configure('odd', background='#f8fafc')
        vs = ttk.Scrollbar(self, orient='vertical', command=self.tree.yview)
        hs = ttk.Scrollbar(self, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        self.tree.grid(row=0, column=0, sticky='nsew')
        vs.grid(row=0, column=1, sticky='ns')
        hs.grid(row=1, column=0, sticky='ew')
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.empty = tk.Label(self, text='', bg='white', fg=MUTED, font=F(11))
        self.tree.bind('<<TreeviewSelect>>', lambda e: self.on_select and self.on_select(self))

    def load(self, rows, empty_text='Nothing to show'):
        self.rows = rows
        self.empty.config(text=empty_text)
        self._render()

    def set_filter(self, text):
        self.filter_text = text.strip().lower()
        self._render()

    def sort_by(self, key):
        if self.sort_col == key:
            self.sort_rev = not self.sort_rev
        else:
            self.sort_col, self.sort_rev = key, False
        self._render()

    def _render(self):
        keys = [c[0] for c in self.columns]
        rows = self.rows
        if self.filter_text:
            rows = [r for r in rows if self.filter_text in ' '.join(str(v) for v in r['values']).lower()]
        if self.sort_col:
            i = keys.index(self.sort_col)

            def k(r):
                v = (r.get('sort') or r['values'])[i]
                return (0, v) if isinstance(v, (int, float)) or hasattr(v, 'quantize') or hasattr(v, 'toordinal') else (1, str(v).lower())
            try:
                rows = sorted(rows, key=k, reverse=self.sort_rev)
            except TypeError:
                rows = sorted(rows, key=lambda r: str((r.get('sort') or r['values'])[i]), reverse=self.sort_rev)
        for key, title, *_ in self.columns:
            arrow = (' ▼' if self.sort_rev else ' ▲') if key == self.sort_col else ''
            self.tree.heading(key, text=title + arrow)
        sel = set(self.tree.selection())
        self.tree.delete(*self.tree.get_children())
        for n, r in enumerate(rows):
            tags = (r.get('tag'),) if r.get('tag') else (('odd',) if n % 2 else ())
            self.tree.insert('', 'end', iid=r['iid'], values=r['values'], tags=tags)
        keep = [i for i in sel if self.tree.exists(i)]
        if keep:
            self.tree.selection_set(keep)
        self._visible = rows
        if not rows:
            self.empty.place(relx=0.5, rely=0.4, anchor='center')
        else:
            self.empty.place_forget()

    def selected(self):
        return list(self.tree.selection())

    def select(self, iids):
        iids = [i for i in iids if self.tree.exists(i)]
        if iids:
            self.tree.selection_set(iids)
            self.tree.see(iids[0])

    @property
    def count(self):
        return len(self._visible)


def attach_tooltip(widget, text):
    tip = {'w': None}

    def show(e):
        if tip['w']:
            return
        w = tk.Toplevel(widget)
        w.wm_overrideredirect(True)
        w.wm_geometry(f'+{e.x_root + 12}+{e.y_root + 14}')
        tk.Label(w, text=text, bg=NAVY, fg='white', font=F(9), padx=8, pady=4, justify='left').pack()
        tip['w'] = w

    def hide(e):
        if tip['w']:
            tip['w'].destroy()
            tip['w'] = None
    widget.bind('<Enter>', show, add='+')
    widget.bind('<Leave>', hide, add='+')
