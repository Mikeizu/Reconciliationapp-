"""Offline question answering over reconciliation results. Deterministic keyword/number parsing - no model, no network."""
from __future__ import annotations

import datetime as dt
import re
from decimal import Decimal

import reconcile as R

CATS = [
    (('charge', 'charges', 'fee', 'fees', 'vat', 'stamp', 'levy', 'emtl'), {'Bank charge'}),
    (('interest',), {'Bank interest'}),
    (('reversal', 'reversals', 'refund', 'refunds', 'returned', 'bounced'), {'Reversal / return'}),
    (('duplicate', 'duplicates', 'double', 'twice'), {'Possible duplicate'}),
    (('stale',), {'Stale payment'}),
    (('outstanding', 'uncleared', 'unpresented'), {'Outstanding payment', 'Stale payment', 'Payment not on statement'}),
    (('transit',), {'Deposit in transit'}),
    (('unrecorded',), {'Unrecorded payment', 'Unrecorded receipt'}),
]
OUT_W = {'payment', 'payments', 'withdrawal', 'withdrawals', 'paid', 'outflow', 'outflows', 'spent', 'cheque', 'cheques'}
IN_W = {'receipt', 'receipts', 'deposit', 'deposits', 'received', 'inflow', 'inflows', 'income', 'collections'}
STOP = {'show', 'me', 'all', 'the', 'a', 'an', 'of', 'in', 'on', 'for', 'to', 'and', 'with', 'any', 'are', 'is', 'there',
        'what', 'which', 'items', 'item', 'transactions', 'transaction', 'list', 'find', 'give', 'how', 'many', 'much',
        'total', 'sum', 'count', 'that', 'were', 'was', 'has', 'have', 'from', 'by', 'than', 'over', 'under', 'above',
        'below', 'last', 'days', 'day', 'top', 'bank', 'sage', 'not', 'missing', 'ngn', 'amount', 'amounts', 'since',
        'after', 'before', 'between', 'less', 'more', 'greater', 'at', 'least', 'exactly', 'my', 'our', 'this'}
HELP = ['bank charges', 'payments over 500k', 'receipts not in Sage', 'unusual items', 'duplicates', 'top 5 largest',
        'uncleared cheques', 'items after 20/10', 'why is there a difference']
_DATE = re.compile(r'\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b')
_NUM = re.compile(r'(?<![\w/.-])(\d[\d,]*(?:\.\d+)?)\s*(k|m|mn|million|thousand)?(?![\w/])', re.I)


def _mult(sfx):
    return {'k': 1000, 'thousand': 1000, 'm': 1_000_000, 'mn': 1_000_000, 'million': 1_000_000}.get((sfx or '').lower(), 1)


def _parse_date(m, year):
    d, mo, y = int(m.group(1)), int(m.group(2)), m.group(3)
    y = int(y) + 2000 if y and len(y) == 2 else int(y) if y else year
    try:
        return dt.date(y, mo, d)
    except ValueError:
        return None


def ask(r, text, sym=''):
    """Return dict(title, answer, items, total). `items` are exception items (bank_only + sage_only)."""
    q = ' ' + text.lower().strip().replace('₦', '').replace('?', ' ') + ' '
    pool = r['bank_only'] + r['sage_only']
    P, st = r['params'], r['statement']
    fmt = lambda v: f'{sym}{v:,.2f}'
    if not text.strip() or re.search(r'\bhelp\b|what can you', q):
        return dict(title='Examples', answer='Try: ' + ' • '.join(HELP), items=[], total=Decimal(0))
    if re.search(r'\b(why|explain)\b.*\b(differ|balance|reconcil)|\bdifference\b', q):
        d = st['difference']
        if d is None:
            ans = 'The proof cannot be completed - a closing balance is missing. Type it in with "Set…" on the Overview tab.'
        elif d == 0:
            ans = 'There is no difference: adjusted bank balance equals adjusted book balance.'
        else:
            ans = f'Unexplained difference of {fmt(d)}. ' + (' '.join(st['explainers']) if st['explainers'] else
                                                            'No single item explains it - check opening balances, ignored rows and the period dates.')
        return dict(title='Difference', answer=ans, items=[], total=Decimal(0))
    if re.search(r'\b(summary|status|overview|how am i doing)\b', q):
        S = r['summary']
        ans = (f"{S['n_matches']} matches; {S['n_bank_only']} bank-only and {S['n_sage_only']} Sage-only items remain; "
               f"{len(r['suggestions'])} suggestions; proof: " + ('reconciled' if st['reconciled'] else 'not verified' if st['difference'] is None else f"difference {fmt(st['difference'])}") + '.')
        return dict(title='Summary', answer=ans, items=[], total=Decimal(0))

    notes = []
    items = pool
    # ---- relative / absolute dates (remove them before reading amounts)
    year = P['end'].year
    m = re.search(r'last (\d+) days?', q)
    if m:
        cut = P['end'] - dt.timedelta(days=int(m.group(1)))
        items = [x for x in items if x['date'] > cut]
        notes.append(f'in the last {m.group(1)} days of the period')
        q = q.replace(m.group(0), ' ')
    for kw, label, op in (('after', 'after', lambda a, b: a > b), ('since', 'since', lambda a, b: a >= b),
                          ('before', 'before', lambda a, b: a < b), (' on ', 'on', lambda a, b: a == b)):
        m = re.search(rf'{kw.strip()}\s+{_DATE.pattern}', q)
        if m:
            d = _parse_date(_DATE.search(m.group(0)), year)
            if d:
                items = [x for x in items if op(x['date'], d)]
                notes.append(f'{label} {d:%d/%m/%Y}')
                q = q.replace(m.group(0), ' ')
    if 'weekend' in q:
        items = [x for x in items if x['date'].weekday() >= 5]
        notes.append('dated on a weekend')
        q = q.replace('weekend', ' ')
    q = _DATE.sub(' ', q)
    # ---- top N
    top = None
    m = re.search(r'\b(?:top|largest|biggest)\s*(\d+)?', q)
    if m:
        top = int(m.group(1)) if m.group(1) else 5
        q = q.replace(m.group(0), ' ')
        notes.append(f'top {top} by amount')
    # ---- amounts
    lo = hi = eq = None
    m = re.search(r'between\s+(\d[\d,.]*)\s*(k|m|mn|million|thousand)?\s+and\s+(\d[\d,.]*)\s*(k|m|mn|million|thousand)?', q)
    if m:
        a = Decimal(m.group(1).replace(',', '')) * _mult(m.group(2))
        b = Decimal(m.group(3).replace(',', '')) * _mult(m.group(4))
        lo, hi = min(a, b), max(a, b)
        q = q.replace(m.group(0), ' ')
        items = [x for x in items if lo <= x['amount'] <= hi]
        notes.append(f'between {fmt(lo)} and {fmt(hi)}')
    else:
        for pat, kind in ((r'(?:over|above|greater than|more than|exceeding|bigger than|>)\s*', 'gt'),
                          (r'(?:at least|minimum|min)\s*', 'ge'),
                          (r'(?:under|below|less than|smaller than|<)\s*', 'lt'),
                          (r'(?:exactly|equal to|equals|=)\s*', 'eq')):
            m = re.search(pat + _NUM.pattern, q, re.I)
            if m:
                v = Decimal(m.group(1).replace(',', '')) * _mult(m.group(2))
                f = {'gt': lambda a, v=v: a > v, 'ge': lambda a, v=v: a >= v, 'lt': lambda a, v=v: a < v, 'eq': lambda a, v=v: a == v}[kind]
                items = [x for x in items if f(x['amount'])]
                notes.append({'gt': 'over', 'ge': 'at least', 'lt': 'under', 'eq': 'exactly'}[kind] + f' {fmt(v)}')
                q = q.replace(m.group(0), ' ')
                break
        else:
            m = _NUM.search(q)
            if m and (m.group(2) or len(m.group(1).replace(',', '')) >= 4):
                v = Decimal(m.group(1).replace(',', '')) * _mult(m.group(2))
                items = [x for x in items if x['amount'] == v]
                notes.append(f'equal to {fmt(v)}')
                q = q.replace(m.group(0), ' ')
    wordlist = re.findall(r"[a-z']+", q)
    words = set(wordlist)
    # ---- side (careful with "not in sage" meaning bank-only)
    if re.search(r'not (?:in|on) sage|missing (?:in|from) sage|unrecorded|not recorded', q):
        items = [x for x in items if x['source'] == 'Bank']
        notes.append('on the bank but not in Sage')
    elif re.search(r'not (?:in|on) (?:the )?bank|missing (?:in|from) (?:the )?bank|uncleared|outstanding|unpresented', q):
        items = [x for x in items if x['source'] == 'Sage']
        notes.append('in Sage but not on the bank')
    elif 'bank' in words and 'sage' not in words:
        items = [x for x in items if x['source'] == 'Bank']
        notes.append('from the bank statement')
    elif 'sage' in words and 'bank' not in words:
        items = [x for x in items if x['source'] == 'Sage']
        notes.append('from Sage')
    # ---- direction
    if words & OUT_W and not words & IN_W:
        items = [x for x in items if x['direction'] == 'out']
        notes.append('money out')
    elif words & IN_W and not words & OUT_W:
        items = [x for x in items if x['direction'] == 'in']
        notes.append('money in')
    # ---- categories
    cats = set()
    for keys, c in CATS:
        if words & set(keys):
            cats |= c
    if cats:
        items = [x for x in items if x.get('category') in cats]
        notes.append('category: ' + ', '.join(sorted(cats)).lower())
    if words & {'unusual', 'suspicious', 'risk', 'risky', 'odd', 'strange', 'round', 'anomalies', 'anomaly'}:
        items = [x for x in items if x.get('risks')]
        notes.append('with risk flags')
    if words & {'reviewed'} and 'not' not in words and 'unreviewed' not in words:
        items = [x for x in items if x['id'] in r['reviewed']]
        notes.append('already reviewed')
    if words & {'unreviewed', 'pending', 'todo', 'remaining'} or re.search(r'not reviewed', q):
        items = [x for x in items if x['id'] not in r['reviewed']]
        notes.append('not yet reviewed')
    # ---- free text on what is left
    rest = [w for w in dict.fromkeys(wordlist) if w not in STOP and len(w) > 2 and w not in OUT_W | IN_W and not any(w in k for k, _ in CATS)
            and w not in {'unusual', 'suspicious', 'risk', 'risky', 'weekend', 'unreviewed', 'reviewed', 'pending', 'uncleared',
                          'outstanding', 'unrecorded', 'recorded', 'largest', 'biggest', 'unpresented', 'round', 'odd', 'strange',
                          'remaining', 'todo', 'duplicate', 'duplicates', 'stale', 'transit', 'cheque', 'cheques'}]
    if rest:
        items = [x for x in items if all(w in f"{x['description']} {x['reference']} {x.get('category', '')}".lower() for w in rest)]
        notes.append('mentioning "' + ' '.join(rest) + '"')
    items = sorted(items, key=lambda x: -x['amount'])
    if top:
        items = items[:top]
    total = sum((x['amount'] for x in items), Decimal(0))
    desc = ', '.join(notes) if notes else 'all unmatched items'
    if items:
        ans = f"{len(items)} item(s) totalling {fmt(total)} - {desc}."
    else:
        ans = f"Nothing found for: {desc}. Try one of: " + ' • '.join(HELP[:5])
    return dict(title=text.strip(), answer=ans, items=items, total=total)
