"""SageRecon AI Pro - offline reconciliation engine.

Read-only: nothing here writes to accounting records and nothing touches the network.
All money is Decimal.  The "AI" is a transparent, explainable matching engine
(scoring + search), not a generative model - every decision carries a reason.

Direction convention
    'in'  = money into the bank   (Bank deposit    <-> Sage DEBIT)
    'out' = money out of the bank (Bank withdrawal <-> Sage CREDIT)
"""
from __future__ import annotations

import csv
import datetime as dt
import re
import unicodedata
from collections import defaultdict
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from difflib import SequenceMatcher
from pathlib import Path

CENT = Decimal('0.01')
ZERO = Decimal('0.00')

# --------------------------------------------------------------------------- #
# Header vocabulary
# --------------------------------------------------------------------------- #
HEADERS = {
    'date': ['date', 'transaction date', 'value date', 'posting date', 'tran date', 'trans date',
             'transactiondate', 'txn date', 'post date', 'booking date', 'date posted'],
    'withdrawal': ['withdrawal', 'withdrawals', 'debit amount', 'withdrawal amount', 'debits', 'debit', 'dr',
                   'paid out', 'money out', 'amount out', 'payments', 'payment out', 'outflow'],
    'deposit': ['deposit', 'deposits', 'credit amount', 'deposit amount', 'credits', 'credit', 'cr',
                'paid in', 'money in', 'amount in', 'receipts', 'payment in', 'inflow'],
    'amount': ['amount', 'transaction amount', 'txn amount', 'value', 'net amount'],
    'balance': ['balance', 'running balance', 'account balance', 'available balance', 'ledger balance',
                'book balance', 'closing balance'],
    'reference': ['reference', 'ref', 'ref no', 'reference no', 'transaction reference', 'transaction id',
                  'narration reference', 'instrument id', 'cheque no', 'cheque number', 'chq no',
                  'session id', 'trans ref'],
    'description': ['description', 'narration', 'narrative', 'remarks', 'details', 'transaction details',
                    'particulars', 'payee', 'beneficiary', 'transaction description', 'memo'],
}
FIELD_ORDER = ('date', 'withdrawal', 'deposit', 'amount', 'balance', 'reference', 'description')
_NOISE_WORDS = {'ngn', 'naira', 'usd', 'gbp', 'eur', 'n'}

SAGE_DESC_ALIASES = ['description', 'details', 'narrative', 'memo', 'payee', 'name', 'type', 'transaction type']
SAGE_REF_ALIASES = ['reference', 'ref', 'cheque no', 'cheque number', 'document no', 'doc no', 'number',
                    'transaction number', 'trans no']

STOP_WORDS = {'the', 'and', 'for', 'from', 'payment', 'transfer', 'trf', 'nip', 'ussd', 'web', 'pos', 'atm',
              'ref', 'ltd', 'limited', 'with', 'inv', 'invoice', 'bank', 'cash', 'chq', 'cheque'}

FEE_PAT = re.compile(r'\b(charges?|chg|fees?|commission|comm|vat|stamp ?duty|sms|alert|maintenance|cot|emtl|'
                     r'levy|lvy|penalty|statement|token|card ?fee|sms ?alert|service ?charge|bank ?charges?)\b', re.I)
INTEREST_PAT = re.compile(r'\b(interest|credit ?interest)\b', re.I)
REVERSAL_PAT = re.compile(r'\b(reversal|reversed|rvsl|rev|refund|returned|return|failed|unpaid|bounced?|chargeback)\b', re.I)


def norm(v) -> str:
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(v if v is not None else ''))
                  .replace('\xa0', ' ')).strip().lower()


def clean_label(v) -> str:
    s = re.sub(r'[^a-z0-9 ]+', ' ', norm(v))
    return ' '.join(w for w in s.split() if w not in _NOISE_WORDS)


# --------------------------------------------------------------------------- #
# Value parsing
# --------------------------------------------------------------------------- #
def money(v):
    """Parse a cell into Decimal(2dp) or None. Handles (1,000.00), 1,000.00-, 1.234,56, NGN/₦, Dr/Cr."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float, Decimal)):
        if isinstance(v, float) and v != v:
            return None
        return Decimal(str(v)).quantize(CENT, ROUND_HALF_UP)
    s = str(v).strip().replace('\xa0', ' ')
    if s in ('', '-', '—', '–', 'n/a', 'N/A', 'nil', 'NIL'):
        return None
    sign = 1
    m = re.search(r'\s*\b(cr|dr)\b\.?\s*$', s, re.I)
    if m:
        sign = 1 if m.group(1).lower() == 'cr' else -1
        s = s[:m.start()]
    s = re.sub(r'(?i)ngn|usd|gbp|eur|naira', '', s)
    s = re.sub(r'[₦$£€]', '', s).replace('−', '-').replace(' ', '')
    if s.startswith('(') and s.endswith(')'):
        sign, s = -sign, s[1:-1]
    if s.endswith('-'):
        sign, s = -sign, s[:-1]
    if s.startswith('-'):
        sign, s = -sign, s[1:]
    elif s.startswith('+'):
        s = s[1:]
    if not s or not re.fullmatch(r'[\d.,]+', s):
        return None
    if ',' in s and '.' in s:
        dec = ',' if s.rfind(',') > s.rfind('.') else '.'
        s = s.replace('.' if dec == ',' else ',', '').replace(dec, '.')
    elif ',' in s:
        s = s.replace(',', '') if re.fullmatch(r'\d{1,3}(,\d{3})+', s) else (
            s.replace(',', '.') if re.fullmatch(r'\d+,\d{1,2}', s) else s.replace(',', ''))
    elif s.count('.') > 1:
        if re.fullmatch(r'\d{1,3}(\.\d{3})+', s):
            s = s.replace('.', '')
        else:
            return None
    try:
        return (sign * Decimal(s)).quantize(CENT, ROUND_HALF_UP)
    except InvalidOperation:
        return None


_TIME_TAIL = re.compile(r'[T\s]+\d{1,2}:\d{2}(:\d{2})?(\.\d+)?\s*(am|pm)?\s*(Z|[+-]\d\d:?\d\d)?$', re.I)
_DMY = ('%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y', '%d/%m/%y', '%d-%m-%y', '%d.%m.%y')
_MDY = ('%m/%d/%Y', '%m-%d-%Y', '%m.%d.%Y', '%m/%d/%y', '%m-%d-%y', '%m.%d.%y')
_NAMED = ('%d-%b-%Y', '%d %b %Y', '%d-%b-%y', '%d %b %y', '%d %B %Y', '%d-%B-%Y', '%b %d, %Y',
          '%B %d, %Y', '%d/%b/%Y', '%d %b, %Y')


def dateval(v, order: str = 'dmy'):
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if isinstance(v, (int, float)):
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(v)) if 20000 < float(v) < 80000 else None
    s = _TIME_TAIL.sub('', str(v).strip()).strip()
    if not s:
        return None
    if re.fullmatch(r'\d{5}', s) and 20000 < int(s) < 80000:
        return dt.date(1899, 12, 30) + dt.timedelta(days=int(s))
    fmts = ('%Y-%m-%d', '%Y/%m/%d') + (_MDY + _DMY if order == 'mdy' else _DMY + _MDY) + _NAMED
    for fmt in fmts:
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def infer_date_order(values) -> str:
    """Look for an unambiguous day>12 / month>12 to decide dd/mm vs mm/dd for a whole column."""
    dmy = mdy = 0
    for v in values:
        if isinstance(v, str):
            m = re.match(r'\s*(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})', v)
            if m:
                a, b = int(m[1]), int(m[2])
                if a > 12 >= b:
                    dmy += 1
                elif b > 12 >= a:
                    mdy += 1
    return 'mdy' if mdy > dmy else 'dmy'


_DATE_IN_TEXT = re.compile(r'(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2} [A-Za-z]{3,9},? \d{4}|'
                           r'\d{1,2}-[A-Za-z]{3}-\d{2,4})')


def dates_in_text(s, order='dmy'):
    out = []
    for m in _DATE_IN_TEXT.findall(str(s or '')):
        d = dateval(m, order)
        if d:
            out.append(d)
    return out


# --------------------------------------------------------------------------- #
# File reading
# --------------------------------------------------------------------------- #
def read_rows(path):
    """Return the rows of the most substantial sheet (or the CSV). Row N == spreadsheet row N."""
    return read_workbook(path)[0]


def read_workbook(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext == '.csv':
        raw = p.read_bytes()
        text = ''
        for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        lines = text.splitlines()
        try:
            d = csv.Sniffer().sniff('\n'.join(lines[:30])[:8192], delimiters=',;\t|')
        except csv.Error:
            d = csv.excel
        return _trim(list(csv.reader(lines, d))), p.name
    if ext == '.xlsx':
        from openpyxl import load_workbook
        wb = load_workbook(p, read_only=True, data_only=True)
        try:
            best, best_n, best_name = [], -1, ''
            for ws in wb.worksheets:
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                rows = [list(r) for r in ws.iter_rows(values_only=True)]
                n = sum(1 for r in rows for c in r if c not in (None, ''))
                if n > best_n:
                    best, best_n, best_name = rows, n, ws.title
            return _trim(best), best_name
        finally:
            wb.close()
    if ext == '.xls':
        import xlrd
        wb = xlrd.open_workbook(str(p))
        best, best_n, best_name = [], -1, ''
        for s in wb.sheets():
            out = []
            for i in range(s.nrows):
                r = []
                for j in range(s.ncols):
                    c = s.cell(i, j)
                    v = c.value
                    if c.ctype == xlrd.XL_CELL_DATE:
                        try:
                            v = dt.datetime(*xlrd.xldate_as_tuple(v, wb.datemode)).date()
                        except Exception:
                            pass
                    r.append(v)
                out.append(r)
            n = sum(1 for r in out for c in r if c not in (None, ''))
            if n > best_n:
                best, best_n, best_name = out, n, s.name
        return _trim(best), best_name
    raise ValueError('Supported formats: .xlsx, .xls, .csv')


def _trim(rows):
    while rows and all(c in (None, '') for c in rows[-1]):
        rows.pop()
    return rows


# --------------------------------------------------------------------------- #
# Header / mapping detection
# --------------------------------------------------------------------------- #
def detect_mapping(rows, header_index):
    """Best-effort field -> column index mapping for one header row (each column used once)."""
    labels = [clean_label(x) for x in rows[header_index]] if 0 <= header_index < len(rows) else []
    mapping, used = {}, set()
    for field in FIELD_ORDER:
        aliases = HEADERS[field]
        loose = field in ('withdrawal', 'deposit', 'balance', 'date', 'reference', 'description')
        for strict in (True, False):
            hit = None
            for j, lab in enumerate(labels):
                if j in used or not lab:
                    continue
                if lab in aliases or (not strict and loose and any(len(a) > 2 and lab.startswith(a + ' ') for a in aliases)):
                    hit = j
                    break
            if hit is not None:
                mapping[field] = hit
                used.add(hit)
                break
    return mapping


def header_candidates(rows):
    cands = []
    for i in range(min(100, len(rows))):
        m = detect_mapping(rows, i)
        two_col = 'withdrawal' in m and 'deposit' in m
        score = (3 * two_col) + (3 * ('amount' in m and not two_col)) + 2 * ('date' in m) \
            + ('balance' in m) + ('description' in m)
        if score >= 3 and ('date' in m or two_col):
            cands.append((score, i, m))
    return sorted(cands, key=lambda x: (-x[0], x[1]))


def mapping_health(rows, header_index, mapping):
    """Quick plausibility check of a mapping on the first 200 data rows."""
    body = rows[header_index + 1: header_index + 201]
    col = lambda r, k: (r[mapping[k]] if mapping.get(k) is not None and mapping[k] < len(r) else None)
    order = infer_date_order([col(r, 'date') for r in body])
    d = sum(dateval(col(r, 'date'), order) is not None for r in body)
    a = sum(any(money(col(r, k)) for k in ('withdrawal', 'deposit', 'amount')) for r in body)
    nonblank = sum(any(c not in (None, '') for c in r) for r in body)
    msgs = []
    if body and d < 0.4 * max(1, nonblank):
        msgs.append('Fewer than 40% of rows have a readable Date - check the Date column or header row.')
    if body and a == 0:
        msgs.append('No amounts could be read from the mapped amount columns.')
    if mapping.get('withdrawal') is not None and mapping.get('withdrawal') == mapping.get('deposit'):
        msgs.append('Withdrawal and Deposit point at the same column.')
    return dict(dates=d, amounts=a, sample=len(body), order=order, messages=msgs)


# --------------------------------------------------------------------------- #
# Sage cashbook parser
# --------------------------------------------------------------------------- #
def _txn(source, row, date, direction, amount, description, reference):
    return dict(id=f"{source[0]}{row}{'+' if direction == 'in' else '-'}", source=source, row=row, date=date,
                direction=direction, amount=abs(amount), description=description, reference=reference)


def _label_amount(r, start=0):
    for v in r[start:]:
        m = money(v)
        if m is not None:
            return m
    return None


def sage_parse(rows):
    header = next((i for i, r in enumerate(rows)
                   if 'debit' in [clean_label(x) for x in r] and 'credit' in [clean_label(x) for x in r]), None)
    if header is None:
        raise ValueError('Sage Debit/Credit header not found. Check the selected cashbook export.')
    h = [clean_label(x) for x in rows[header]]
    idx = {'debit': h.index('debit'), 'credit': h.index('credit')}
    date_col = next((j for j, x in enumerate(h) if x in HEADERS['date']), 0)
    ref_col = next((j for j, x in enumerate(h) if x in SAGE_REF_ALIASES), None)
    desc_cols = [j for j, x in enumerate(h) if x in SAGE_DESC_ALIASES and j != ref_col]
    if not desc_cols and ref_col is None:      # unlabeled layout used by the original exports
        desc_cols, ref_col = [1, 2, 5], 3
    cell = lambda r, j: r[j] if j is not None and 0 <= j < len(r) else None
    order = infer_date_order(cell(r, date_col) for r in rows[header + 1:])

    opening = closing = closing_date = opening_date = None
    report_range = None
    txns, warnings, skipped = [], [], []
    for r in rows[:header]:
        joined_h = ' '.join(norm(c) for c in r if c not in (None, ''))
        if 'date range' in joined_h[:30] or 'period' in joined_h[:12]:
            ds = dates_in_text(joined_h, order)
            if len(ds) >= 2:
                report_range = (ds[0], ds[1])
    for ri, r in enumerate(rows[header + 1:], header + 2):
        first = norm(cell(r, date_col) if cell(r, date_col) is not None else cell(r, 0))
        joined = ' '.join(norm(c) for c in r if c not in (None, ''))
        if 'opening balance' in joined[:40]:
            v = _label_amount(r, 1)
            opening = v if v is not None else _label_amount(r)
            ds = dates_in_text(joined, order)
            opening_date = ds[0] if ds else None
            continue
        if 'closing balance' in joined[:40]:
            v = _label_amount(r, 1)
            closing = v if v is not None else _label_amount(r)
            ds = dates_in_text(joined, order)
            closing_date = ds[0] if ds else None
            continue
        if 'date range' in joined[:30]:
            ds = dates_in_text(joined, order)
            if len(ds) >= 2:
                report_range = (ds[0], ds[1])
            continue
        if any(x in first for x in ('movement for', 'grand total', 'bank account', 'total')):
            continue
        d = dateval(cell(r, date_col), order)
        dm, cm = money(cell(r, idx['debit'])) or ZERO, money(cell(r, idx['credit'])) or ZERO
        if not dm and not cm:
            continue
        if not d:
            skipped.append(dict(row=ri, reason='Date not recognised', amount=dm or cm, text=joined[:60]))
            continue
        if dm and cm:
            warnings.append(f'Sage row {ri} contains both a debit and a credit - both were used.')
        desc = ' '.join(str(cell(r, j)).strip() for j in desc_cols if cell(r, j) not in (None, '')).strip()
        ref = str(cell(r, ref_col) or '').strip() if ref_col is not None else ''
        for amount, base in ((dm, 'in'), (cm, 'out')):
            if amount:
                direction = base if amount > 0 else ('out' if base == 'in' else 'in')
                txns.append(_txn('Sage', ri, d, direction, amount, desc, ref))
    if not txns:
        warnings.append('No Sage transactions were found below the Debit/Credit header.')
    return dict(transactions=txns, opening=opening, opening_date=opening_date, closing=closing,
                closing_date=closing_date, report_range=report_range, warnings=warnings, skipped=skipped,
                header=header + 1, date_order=order)


# --------------------------------------------------------------------------- #
# Bank statement parser
# --------------------------------------------------------------------------- #
def check_balance_integrity(balance_rows):
    """balance_rows: [(row, date, balance, withdrawal, deposit)] in file order. Detects order and breaks."""
    if len(balance_rows) < 2:
        return dict(order='unknown', checked=0, breaks=[])

    def scan(seq):
        out = []
        for prev, cur in zip(seq, seq[1:]):
            if prev[2] + cur[4] - cur[3] != cur[2]:
                out.append(cur[0])
        return out

    asc, desc = scan(balance_rows), scan(balance_rows[::-1])
    if len(desc) < len(asc):
        return dict(order='descending', checked=len(balance_rows) - 1, breaks=desc)
    return dict(order='ascending', checked=len(balance_rows) - 1, breaks=asc)


def bank_parse(rows, header_index, mapping, amount_sign='negative_withdrawal'):
    """amount_sign (single signed Amount column): 'negative_withdrawal' (default) or 'positive_withdrawal'."""
    has_two = mapping.get('withdrawal') is not None and mapping.get('deposit') is not None
    has_one = mapping.get('amount') is not None
    if not (has_two or has_one):
        raise ValueError('Map either both Withdrawal and Deposit columns, or a single signed Amount column.')
    if mapping.get('date') is None:
        raise ValueError('Map the bank Date column before comparing.')
    cell = lambda r, k: r[mapping[k]] if mapping.get(k) is not None and 0 <= mapping[k] < len(r) else None
    body = rows[header_index + 1:]
    order = infer_date_order(cell(r, 'date') for r in body)
    txns, warnings, skipped, balance_rows = [], [], [], []
    for ri, r in enumerate(body, header_index + 2):
        joined = ' '.join(norm(c) for c in r if c not in (None, ''))
        if not joined:
            continue
        if has_two:
            w = money(cell(r, 'withdrawal')) or ZERO
            d = money(cell(r, 'deposit')) or ZERO
        else:
            a = money(cell(r, 'amount')) or ZERO
            if amount_sign == 'positive_withdrawal':
                a = -a
            w, d = (-a, ZERO) if a < 0 else (ZERO, a)
        date = dateval(cell(r, 'date'), order)
        bal = money(cell(r, 'balance'))
        if date and bal is not None:
            balance_rows.append((ri, date, bal, abs(w), abs(d)))
        if not w and not d:
            continue
        if not date:
            if not re.search(r'total|opening|closing|b/f|c/f|brought|carried|balance', joined):
                skipped.append(dict(row=ri, reason='Date not recognised', amount=w or d, text=joined[:60]))
            continue
        if w and d:
            warnings.append(f'Bank row {ri} contains both a withdrawal and a deposit - both were used.')
        desc, ref = str(cell(r, 'description') or '').strip(), str(cell(r, 'reference') or '').strip()
        for direction, amount in (('out', w), ('in', d)):
            if amount:
                txns.append(_txn('Bank', ri, date, direction, amount, desc, ref))
        if has_two and (w < 0 or d < 0):
            warnings.append(f'Bank row {ri} has a negative amount in a Withdrawal/Deposit column - direction flipped.')
    # balances stated outside the table ("Closing balance: 1,234.56")
    st_open = st_close = st_close_date = None
    for r in rows:
        for j, c in enumerate(r):
            t = norm(c)
            if not t or len(t) > 60:
                continue
            if re.search(r'opening balance|balance b/f|brought forward|balance brought', t) and st_open is None:
                st_open = _label_amount(r, j + 1)
            if re.search(r'closing balance|balance c/f|carried forward|balance carried', t) and st_close is None:
                st_close = _label_amount(r, j + 1)
                ds = dates_in_text(' '.join(str(x) for x in r), order)
                st_close_date = ds[-1] if ds else None
    integrity = check_balance_integrity(balance_rows)
    if integrity['breaks']:
        warnings.append(f"Running balance does not reconcile on {len(integrity['breaks'])} bank row(s) - "
                        f"check the Balance/Deposit/Withdrawal mapping.")
    return dict(transactions=txns, balance_rows=balance_rows, warnings=warnings, skipped=skipped,
                integrity=integrity, stated_open=st_open, stated_close=st_close,
                stated_close_date=st_close_date, date_order=order)


# --------------------------------------------------------------------------- #
# Similarity helpers
# --------------------------------------------------------------------------- #
_ID_RE = re.compile(r'\d{5,}|\b(?!(?:19|20)\d\d\b)\d{4}\b')


def _prep(x):
    if '_tok' not in x:
        text = f"{x.get('description', '')} {x.get('reference', '')}"
        n = norm(text)
        x['_norm'] = n
        x['_tok'] = {t for t in re.findall(r'[a-z]{3,}', n) if t not in STOP_WORDS}
        x['_ids'] = set(_ID_RE.findall(text))
        x['_ref'] = norm(x.get('reference', ''))
    return x


def ref_strength(a, b):
    _prep(a), _prep(b)
    if a['_ids'] & b['_ids']:
        return 1.0
    ra, rb = a['_ref'], b['_ref']
    if ra and rb:
        if ra == rb:
            return 1.0
        if min(len(ra), len(rb)) >= 4 and (ra in rb or rb in ra):
            return 0.7
    return 0.0


def desc_sim(a, b):
    _prep(a), _prep(b)
    if not a['_norm'].strip() or not b['_norm'].strip():
        return 0.0
    ta, tb = a['_tok'], b['_tok']
    jac = len(ta & tb) / len(ta | tb) if ta and tb else 0.0
    seq = SequenceMatcher(None, a['_norm'][:70], b['_norm'][:70]).ratio()
    return 0.6 * jac + 0.4 * seq


def level_of(conf):
    return 'High' if conf >= 85 else 'Medium' if conf >= 65 else 'Low'


def _days(a, b):
    return abs((a['date'] - b['date']).days)


def is_transposition(a: Decimal, b: Decimal) -> bool:
    sa, sb = f'{abs(a):.2f}'.replace('.', ''), f'{abs(b):.2f}'.replace('.', '')
    if len(sa) != len(sb) or sa == sb:
        return False
    d = [i for i in range(len(sa)) if sa[i] != sb[i]]
    return len(d) == 2 and d[1] == d[0] + 1 and sa[d[0]] == sb[d[1]] and sa[d[1]] == sb[d[0]]


def is_single_digit_typo(a: Decimal, b: Decimal) -> bool:
    sa, sb = f'{abs(a):.2f}'.replace('.', ''), f'{abs(b):.2f}'.replace('.', '')
    return len(sa) == len(sb) and sum(x != y for x, y in zip(sa, sb)) == 1


# --------------------------------------------------------------------------- #
# Matching passes
# --------------------------------------------------------------------------- #
def _match_record(kind, sage, bank, conf, reason, auto=True):
    mid = 'M:' + '|'.join(sorted(x['id'] for x in sage + bank))
    return dict(id=mid, kind=kind, sage=sage, bank=bank, confidence=int(conf), level=level_of(conf),
                reason=reason, auto=auto, amount=sum((x['amount'] for x in bank), ZERO))


def _pass_exact(S, B, days, memory=None):
    by_amt = defaultdict(list)
    for j, b in enumerate(B):
        by_amt[(b['direction'], b['amount'])].append(j)
    choices, cs, cb = [], defaultdict(int), defaultdict(int)
    for i, s in enumerate(S):
        for j in by_amt.get((s['direction'], s['amount']), ()):
            b = B[j]
            delta = _days(s, b)
            if delta > days:
                continue
            ref, sim = ref_strength(s, b), desc_sim(s, b)
            learn = memory.boost(s, b) if memory is not None else 0.0
            pts = 60 + 15 * (1 - delta / (days + 1)) + 20 * ref + 10 * sim + 12 * learn
            choices.append((-pts, delta, s['row'], b['row'], i, j, ref, sim, learn))
            cs[i] += 1
            cb[j] += 1
    choices.sort()
    used_s, used_b, out = set(), set(), []
    for negpts, delta, _, _, i, j, ref, sim, learn in choices:
        if i in used_s or j in used_b:
            continue
        used_s.add(i)
        used_b.add(j)
        pts = -negpts
        if cs[i] == 1 and cb[j] == 1:
            pts += 12
            tail = 'only candidate'
        elif min(cs[i], cb[j]) >= 3:
            pts -= 5
            tail = f'chosen from {max(cs[i], cb[j])} similar items'
        else:
            tail = f'best of {max(cs[i], cb[j])} candidates'
        parts = ['exact amount', 'same day' if delta == 0 else f'{delta} day(s) apart']
        if ref >= 1:
            parts.append('reference/ID match')
        elif ref > 0:
            parts.append('partial reference match')
        if sim >= 0.35:
            parts.append(f'description {int(sim * 100)}% similar')
        if learn:
            parts.append('learned from your earlier decisions')
        parts.append(tail)
        out.append(_match_record('exact', [S[i]], [B[j]], min(100, round(pts)), '; '.join(parts)))
    return out, used_s, used_b


def _subset(pool, target, max_size, node_cap=30000):
    pool = sorted(pool, key=lambda c: -c['amount'])
    best, nodes = [None], [0]

    def dfs(start, remaining, chosen):
        if best[0] or nodes[0] > node_cap:
            return
        nodes[0] += 1
        if remaining == 0 and len(chosen) >= 2:
            best[0] = list(chosen)
            return
        if len(chosen) == max_size:
            return
        for i in range(start, len(pool)):
            a = pool[i]['amount']
            if a > remaining:
                continue
            chosen.append(pool[i])
            dfs(i + 1, remaining - a, chosen)
            chosen.pop()
            if best[0]:
                return

    dfs(0, target, [])
    return best[0]


def _pass_groups(S, B, gdays, max_size=4):
    """One large item on one side equal to the sum of 2-4 items on the other (batch deposits, split payments)."""
    used, out = set(), []
    for single_side in ('bank', 'sage'):
        singles = sorted(B if single_side == 'bank' else S, key=lambda x: -x['amount'])
        others = S if single_side == 'bank' else B
        for x in singles:
            if x['id'] in used:
                continue
            pool = [o for o in others if o['id'] not in used and o['direction'] == x['direction']
                    and o['amount'] < x['amount'] and _days(o, x) <= gdays]
            if len(pool) < 2:
                continue
            pool.sort(key=lambda o: _days(o, x))
            combo = _subset(pool[:24], x['amount'], max_size)
            if not combo:
                continue
            used.add(x['id'])
            used.update(c['id'] for c in combo)
            spread = max(_days(c, x) for c in combo)
            conf = 66 + (10 if spread <= max(1, gdays // 3) else 0)
            if any(ref_strength(x, c) for c in combo):
                conf += 12
            elif any(desc_sim(x, c) > 0.3 for c in combo):
                conf += 6
            conf = min(conf, 84)
            reason = (f"1 {'bank' if single_side == 'bank' else 'Sage'} item = sum of {len(combo)} "
                      f"{'Sage' if single_side == 'bank' else 'bank'} items; dates within {spread} day(s) - verify the grouping")
            s_items = combo if single_side == 'bank' else [x]
            b_items = [x] if single_side == 'bank' else combo
            out.append(_match_record('group', s_items, b_items, conf, reason))
    return out


def _suggestions(S_left, B_left, days, rejected=frozenset()):
    """Near-miss pairs among leftovers; shown for the user to accept - never auto-matched."""
    wide = max(days * 3, 10)
    by_dir = defaultdict(list)
    for s in S_left:
        by_dir[s['direction']].append(s)
    raw = []
    for b in B_left:
        best = None
        for s in by_dir.get(b['direction'], ()):
            if f"SG:{b['id']}|{s['id']}" in rejected:
                continue
            d = _days(s, b)
            diff = b['amount'] - s['amount']
            ref = ref_strength(s, b)
            kind = conf = detail = None
            if diff == 0 and days < d <= 45:
                kind, conf = 'timing', 72 - min(25, d // 2) + (10 if ref else 0)
                detail = f'Same amount, but dates are {d} days apart (outside the {days}-day tolerance)'
            elif diff != 0 and d <= wide:
                rel = abs(diff) / max(s['amount'], Decimal('0.01'))
                if ref >= 1:
                    kind, conf = 'ref_mismatch', 80
                    detail = f'Reference/ID matches but amounts differ by {abs(diff):,.2f}'
                    if is_transposition(b['amount'], s['amount']):
                        detail += f' - digits look transposed ({s["amount"]:,.2f} vs {b["amount"]:,.2f})'
                        conf = 88
                elif is_transposition(b['amount'], s['amount']):
                    kind, conf = 'transposition', 78 - d
                    detail = f'Digits look transposed ({s["amount"]:,.2f} vs {b["amount"]:,.2f})'
                elif is_single_digit_typo(b['amount'], s['amount']):
                    kind, conf = 'keying', 62 - d
                    detail = f'One digit differs ({s["amount"]:,.2f} vs {b["amount"]:,.2f}) - possible keying error'
                elif rel <= Decimal('0.02') and d <= days + 2:
                    kind, conf = 'close_amount', 58 - d + int(10 * desc_sim(s, b))
                    detail = f'Amount differs by {abs(diff):,.2f} ({rel * 100:.1f}%) - possible fee/charge netted or rounding'
            if kind and (best is None or conf > best[0]):
                best = (conf, kind, s, detail, diff)
        if best:
            raw.append((best[0], b, best[2], best[1], best[3], best[4]))
    raw.sort(key=lambda t: -t[0])
    taken, out = set(), []
    for conf, b, s, kind, detail, diff in raw:
        if s['id'] in taken:
            continue
        taken.add(s['id'])
        out.append(dict(id='SG:' + b['id'] + '|' + s['id'], kind=kind, bank=b, sage=s, confidence=int(max(30, conf)),
                        diff=diff, detail=detail))
    return out


# --------------------------------------------------------------------------- #
# Classification / advice
# --------------------------------------------------------------------------- #
def classify_bank_only(x):
    text = f"{x['description']} {x['reference']}"
    if REVERSAL_PAT.search(text):
        return 'Reversal / return', 'Check the original item - post a matching reversal in Sage if the bank reversed it.'
    if x['direction'] == 'out' and FEE_PAT.search(text):
        return 'Bank charge', 'Post the bank charge/VAT/stamp duty in Sage (Dr Bank charges, Cr Bank).'
    if x['direction'] == 'in' and INTEREST_PAT.search(text):
        return 'Bank interest', 'Post the interest received in Sage (Dr Bank, Cr Interest income).'
    if x['direction'] == 'out':
        return 'Unrecorded payment', 'Identify the payee and record the payment in Sage, or query the bank if unauthorised.'
    return 'Unrecorded receipt', 'Identify the customer/source and record the receipt in Sage (or allocate to an invoice).'


def classify_sage_only(x, end, days):
    age = (end - x['date']).days
    if age > 180 and x['direction'] == 'out':
        return 'Stale payment', 'Older than ~6 months - cheque may be stale-dated. Confirm status; consider reversing/reissuing.'
    if age <= max(7, days + 4):
        if x['direction'] == 'out':
            return 'Outstanding payment', 'Recent - likely not yet presented/cleared. Re-check next statement.'
        return 'Deposit in transit', 'Recent - likely banked after period end. Confirm on the next statement.'
    if x['direction'] == 'out':
        return 'Payment not on statement', 'Not cleared after a long time - confirm payment was made; check for wrong bank account or date.'
    return 'Receipt not on statement', 'Not banked - confirm deposit was made; check for wrong bank account, date or a bounced/held item.'


# --------------------------------------------------------------------------- #
# Main entry points
# --------------------------------------------------------------------------- #
def compare(sage, bank, start, end, days=3, lookback=0, group_days=None, manual_balances=None, memory=None):
    """Run the full multi-pass reconciliation. Returns a result dict; call finalize() after manual edits."""
    lo = start - dt.timedelta(days=max(0, lookback))
    pool = lambda txs: [dict(x, prior=x['date'] < start) for x in txs if lo <= x['date'] <= end]
    S, B = pool(sage['transactions']), pool(bank['transactions'])
    for x in S + B:
        _prep(x)
    matches, used_s, used_b = _pass_exact(S, B, days, memory)
    S_left = [x for i, x in enumerate(S) if i not in used_s]
    B_left = [x for j, x in enumerate(B) if j not in used_b]
    gdays = group_days if group_days is not None else max(days, 7)
    groups = _pass_groups(S_left, B_left, gdays)
    result = dict(
        params=dict(start=start, end=end, days=days, lookback=lookback, group_days=gdays,
                    manual_balances=dict(manual_balances or {})),
        sage_src=sage, bank_src=bank, sage=S, bank=B, matches=matches + groups, notes={}, manual_log=[],
        memory=memory, reviewed=set(), rejected=set(), removed=[])
    finalize(result)
    return result


def finalize(r):
    """(Re)derive everything that depends on the current set of matches. Safe to call repeatedly."""
    P = r['params']
    matched = {x['id'] for m in r['matches'] for x in m['sage'] + m['bank']}
    r['sage_only'] = [x for x in r['sage'] if x['id'] not in matched]
    r['bank_only'] = [x for x in r['bank'] if x['id'] not in matched]
    for x in r['bank_only']:
        x['category'], x['action'] = classify_bank_only(x)
    for x in r['sage_only']:
        x['category'], x['action'] = classify_sage_only(x, P['end'], P['days'])
    for items, un in ((r['sage'], r['sage_only']), (r['bank'], r['bank_only'])):
        seen = defaultdict(list)
        for x in items:
            seen[(x['date'], x['direction'], x['amount'])].append(x)
        for x in un:
            if len(seen[(x['date'], x['direction'], x['amount'])]) > 1:
                x['category'] = 'Possible duplicate'
                x['action'] = ('The same date/amount appears more than once on this side - if it is a double posting, '
                               'void or delete one entry; otherwise investigate the missing counterpart.')
    r['suggestions'] = _suggestions(r['sage_only'], r['bank_only'], P['days'], r.get('rejected', frozenset()))
    sug_ids = {x['id']: s for s in r['suggestions'] for x in (s['bank'], s['sage'])}
    amounts = sorted(x['amount'] for x in r['sage_only'] + r['bank_only'])
    p90 = amounts[int(len(amounts) * 0.9)] if len(amounts) >= 5 else None
    for x in r['sage_only'] + r['bank_only']:
        s = sug_ids.get(x['id'])
        x['suggestion'] = s['detail'] if s else ''
        big = p90 is not None and x['amount'] >= p90
        x['severity'] = 'High' if (big or (x['source'] == 'Bank' and x['category'] in ('Unrecorded payment', 'Reversal / return'))
                                   or x['category'] in ('Stale payment', 'Payment not on statement', 'Receipt not on statement', 'Possible duplicate')) \
            else 'Medium' if x['category'] in ('Unrecorded receipt', 'Bank charge', 'Bank interest') else 'Low'
    _risk(r)
    r['flags'] = _build_flags(r)
    r['summary'] = _summary(r)
    r['statement'] = _statement(r)
    r['insights'] = _insights(r)
    return r


def _sum(items, d):
    return sum((x['amount'] for x in items if x['direction'] == d), ZERO)


def _summary(r):
    s_tot = sum((x['amount'] for x in r['sage']), ZERO) or Decimal(1)
    b_tot = sum((x['amount'] for x in r['bank']), ZERO) or Decimal(1)
    ms = sum((x['amount'] for m in r['matches'] for x in m['sage']), ZERO)
    mb = sum((x['amount'] for m in r['matches'] for x in m['bank']), ZERO)
    return dict(
        bank_withdrawals_missing_sage_credits=_sum(r['bank_only'], 'out'),
        bank_deposits_missing_sage_debits=_sum(r['bank_only'], 'in'),
        sage_credits_missing_bank_withdrawals=_sum(r['sage_only'], 'out'),
        sage_debits_missing_bank_deposits=_sum(r['sage_only'], 'in'),
        n_sage=len(r['sage']), n_bank=len(r['bank']), n_matches=len(r['matches']),
        n_high=sum(m['level'] == 'High' for m in r['matches']),
        n_medium=sum(m['level'] == 'Medium' for m in r['matches']),
        n_low=sum(m['level'] == 'Low' for m in r['matches']),
        n_groups=sum(m['kind'] == 'group' for m in r['matches']),
        n_bank_only=len(r['bank_only']), n_sage_only=len(r['sage_only']),
        pct_sage_value=float(ms / s_tot * 100), pct_bank_value=float(mb / b_tot * 100),
        pct_sage_count=(100 * sum(len(m['sage']) for m in r['matches']) / len(r['sage'])) if r['sage'] else 0.0,
        pct_bank_count=(100 * sum(len(m['bank']) for m in r['matches']) / len(r['bank'])) if r['bank'] else 0.0)


def _balances(r):
    P, bank, sage = r['params'], r['bank_src'], r['sage_src']
    man = P['manual_balances']
    end = P['end']
    info = {}
    # ---- bank closing / opening
    integ, rows = bank.get('integrity', {}), bank.get('balance_rows', [])
    chrono = rows[::-1] if integ.get('order') == 'descending' else rows
    cand = [(z[1], i, z) for i, z in enumerate(chrono) if z[1] <= end]
    bclose = bsrc = bdate = None
    if cand:
        z = max(cand, key=lambda t: (t[0], t[1]))[2]
        bclose, bdate = z[2], z[1]
        bsrc = f'last running balance on {z[1]:%d/%m/%Y}' + ('' if z[1] == end else ' (not the period-end date)')
    if bank.get('stated_close') is not None:
        sd = bank.get('stated_close_date')
        all_dates = [x['date'] for x in bank['transactions']]
        if (sd == end) or (sd is None and all_dates and end >= max(all_dates) and (bdate is None or bdate != end)):
            bclose, bsrc = bank['stated_close'], 'closing balance printed on the statement' + ('' if sd else ' (undated)')
    first = next((z for z in chrono if z[1] >= P['start']), None)
    bopen = (first[2] - first[4] + first[3]) if first else bank.get('stated_open')
    # ---- sage
    sclose, ssrc = None, None
    if sage.get('closing') is not None and sage.get('closing_date') == end:
        sclose, ssrc = sage['closing'], 'closing balance stated in the Sage export'
    elif sage.get('opening') is not None:
        movement = sum(((x['amount'] if x['direction'] == 'in' else -x['amount'])
                        for x in sage['transactions'] if x['date'] <= end), ZERO)
        sclose, ssrc = sage['opening'] + movement, 'derived: Sage opening balance + all movements to period end'
    # ---- manual overrides win
    if man.get('bank_close') is not None:
        bclose, bsrc = man['bank_close'], 'entered manually'
    if man.get('sage_close') is not None:
        sclose, ssrc = man['sage_close'], 'entered manually'
    info.update(bank_close=bclose, bank_close_src=bsrc, sage_close=sclose, sage_close_src=ssrc,
                bank_open=bopen, sage_open=sage.get('opening'))
    return info


def _statement(r):
    b = _balances(r)
    dit = _sum(r['sage_only'], 'in')
    osp = _sum(r['sage_only'], 'out')
    x_in = _sum(r['bank_only'], 'in')
    x_out = _sum(r['bank_only'], 'out')
    adj_bank = b['bank_close'] + dit - osp if b['bank_close'] is not None else None
    # amount differences on manually accepted matches must be corrected in Sage -> reconciling line
    adj_amt = ZERO
    for m in r['matches']:
        diff_m = sum((x['amount'] for x in m['bank']), ZERO) - sum((x['amount'] for x in m['sage']), ZERO)
        if diff_m:
            adj_amt += diff_m if m['bank'][0]['direction'] == 'in' else -diff_m
    adj_book = b['sage_close'] + x_in - x_out + adj_amt if b['sage_close'] is not None else None
    diff = adj_bank - adj_book if adj_bank is not None and adj_book is not None else None
    raw = b['sage_close'] - b['bank_close'] if b['sage_close'] is not None and b['bank_close'] is not None else None
    st = dict(b, deposits_in_transit=dit, outstanding_payments=osp, bank_deposits_not_in_sage=x_in,
              bank_withdrawals_not_in_sage=x_out, amount_adjustments=adj_amt, adjusted_bank=adj_bank, adjusted_book=adj_book,
              difference=diff, raw_difference=raw, reconciled=(diff == 0) if diff is not None else None)
    st['explainers'] = _explain_difference(r, st)
    return st


def _explain_difference(r, st):
    diff = st['difference']
    out = []
    if diff is None or diff == 0:
        return out
    ad = abs(diff)
    so, bo = st.get('sage_open'), st.get('bank_open')
    if so is not None and bo is not None and abs(so - bo) == ad:
        out.append(f'The difference equals the gap between opening balances (Sage {so:,.2f} vs bank {bo:,.2f}) - '
                   f'an item from before the period is probably unreconciled.')
    for src in r['bank_src'].get('skipped', []) + r['sage_src'].get('skipped', []):
        if abs(src['amount']) == ad:
            out.append(f"Skipped row {src['row']} ({abs(src['amount']):,.2f}, date unreadable) equals the difference - fix its date.")
    seen = 0
    for x in r['sage'] + r['bank']:
        if seen >= 4:
            break
        if x['amount'] == ad:
            out.append(f"{x['source']} row {x['row']} ({x['amount']:,.2f}, {x['date']:%d/%m/%Y}) equals the difference.")
            seen += 1
        elif x['amount'] * 2 == ad:
            out.append(f"Half the difference equals {x['source']} row {x['row']} ({x['amount']:,.2f}) - "
                       f"it may have been posted to the wrong side (debit vs credit).")
            seen += 1
    for s in r['suggestions']:
        if abs(s['diff']) == ad:
            out.append(f"Suggested pair (bank row {s['bank']['row']} / Sage row {s['sage']['row']}) differs by exactly this amount.")
    return out


def _build_flags(r):
    P = r['params']
    flags = []
    add = lambda lvl, title, detail: flags.append(dict(level=lvl, title=title, detail=detail))
    for src, name in ((r['sage_src'], 'Sage'), (r['bank_src'], 'Bank')):
        sk = src.get('skipped', [])
        if sk:
            tot = sum((abs(s['amount']) for s in sk), ZERO)
            rows = ', '.join(str(s['row']) for s in sk[:8]) + ('…' if len(sk) > 8 else '')
            add('High', f'{name}: {len(sk)} row(s) with amounts were ignored',
                f'Date could not be read on rows {rows} (total {tot:,.2f}). They are NOT in the comparison.')
        for w in src.get('warnings', [])[:5]:
            add('Medium', f'{name} data warning', w)
    integ = r['bank_src'].get('integrity', {})
    if integ.get('breaks'):
        add('High', 'Bank running balance does not tie out',
            f"{len(integ['breaks'])} of {integ['checked']} balance steps fail (rows {', '.join(map(str, integ['breaks'][:8]))}). "
            f'Check the column mapping, or the statement may be missing lines.')
    for src, name in ((r['sage_src'], 'Sage'), (r['bank_src'], 'Bank')):
        outside = [x for x in src['transactions'] if not (P['start'] - dt.timedelta(days=P['lookback']) <= x['date'] <= P['end'])]
        if outside:
            ds = [x['date'] for x in src['transactions']]
            add('Medium', f'{name}: {len(outside)} transaction(s) fall outside the selected period',
                f'File covers {min(ds):%d/%m/%Y} to {max(ds):%d/%m/%Y}. Check the period dates and date format.')
    for name, items in (('Sage', r['sage']), ('Bank', r['bank'])):
        if not items:
            add('High', f'No {name} transactions in this period', 'Verify the period, date format and (for the bank) column mapping.')
    # duplicates: unmatched item identical to another item on the same side
    for name, items, un in (('Sage', r['sage'], r['sage_only']), ('Bank', r['bank'], r['bank_only'])):
        twins = defaultdict(list)
        for x in items:
            twins[(x['date'], x['direction'], x['amount'])].append(x)
        dup = [x for x in un if any(t['id'] != x['id'] for t in twins[(x['date'], x['direction'], x['amount'])])]
        if dup:
            add('Medium', f'{name}: {len(dup)} possible duplicate entr{"y" if len(dup) == 1 else "ies"}',
                f"Same date/amount/direction already exists on the same side: rows {', '.join(str(x['row']) for x in dup[:8])}.")
    # reversal pairs inside unmatched bank / sage
    for name, un in (('Bank', r['bank_only']), ('Sage', r['sage_only'])):
        ins = [x for x in un if x['direction'] == 'in']
        outs = [x for x in un if x['direction'] == 'out']
        pairs = [(a, b) for a in ins for b in outs if a['amount'] == b['amount'] and _days(a, b) <= 3]
        if pairs:
            add('Low', f'{name}: {len(pairs)} possible reversal pair(s)',
                'An unmatched in and out of the same amount within 3 days - e.g. ' +
                f"rows {pairs[0][0]['row']} & {pairs[0][1]['row']}. They may offset each other.")
    return flags


def _insights(r):
    S, st = r['summary'], r['statement']
    out = []
    add = lambda lvl, t, d: out.append(dict(level=lvl, title=t, detail=d))
    if S['n_sage'] + S['n_bank']:
        add('Good' if S['pct_bank_count'] >= 90 and S['pct_sage_count'] >= 90 else 'Info',
            f"{S['pct_bank_count']:.0f}% of bank lines and {S['pct_sage_count']:.0f}% of Sage lines are matched",
            f"{S['n_matches']} match(es): {S['n_high']} high-confidence, {S['n_medium']} medium, {S['n_low']} low"
            + (f", including {S['n_groups']} batch/split grouping(s)." if S['n_groups'] else '.'))
    risky = [x for x in r['sage_only'] + r['bank_only'] if 'Unusually large' in x.get('risks', []) or len(x.get('risks', [])) >= 2]
    if risky:
        add('Review', f'{len(risky)} unmatched item(s) show unusual patterns',
            'Large for this account, round amounts, weekend dates or missing descriptions - look at these first (Risk flags column).')
    needs = S['n_medium'] + S['n_low']
    if needs:
        add('Review', f'{needs} auto-match(es) deserve a quick look',
            'Medium/low confidence usually means similar items competed for the same match or no reference lined up. '
            'Sort the Matched tab by confidence.')
    fees = [x for x in r['bank_only'] if x['category'] == 'Bank charge']
    if fees:
        add('Action', f"{len(fees)} unrecorded bank charge(s) totalling {sum((x['amount'] for x in fees), ZERO):,.2f}",
            'These are on the statement but not in Sage - post a journal for fees/VAT/stamp duty/EMTL.')
    ints = [x for x in r['bank_only'] if x['category'] == 'Bank interest']
    if ints:
        add('Action', f"{len(ints)} bank interest credit(s) totalling {sum((x['amount'] for x in ints), ZERO):,.2f} not in Sage",
            'Post as interest income.')
    timing = [x for x in r['sage_only'] if x['category'] in ('Outstanding payment', 'Deposit in transit')]
    if timing:
        add('Info', f'{len(timing)} item(s) look like normal timing differences',
            f"Outstanding payments {st['outstanding_payments']:,.2f}; deposits in transit {st['deposits_in_transit']:,.2f} "
            f'- recent entries that should clear next period.')
    stale = [x for x in r['sage_only'] if x['category'] == 'Stale payment']
    if stale:
        add('Action', f'{len(stale)} Sage payment(s) older than ~6 months are still uncleared',
            f"Total {sum((x['amount'] for x in stale), ZERO):,.2f}. Possible stale cheques.")
    if r['suggestions']:
        kinds = defaultdict(int)
        for s in r['suggestions']:
            kinds[s['kind']] += 1
        label = {'timing': 'timing', 'transposition': 'digit transposition', 'keying': 'keying error',
                 'ref_mismatch': 'same reference, different amount', 'close_amount': 'close amount'}
        add('Review', f"{len(r['suggestions'])} near-match suggestion(s) found",
            ', '.join(f'{n} {label[k]}' for k, n in kinds.items()) + '. Review in the Suggestions tab and accept to clear them.')
    if r['bank_src'].get('integrity', {}).get('order') == 'descending':
        add('Info', 'Bank statement is in newest-first order', 'Balances were read chronologically - no action needed.')
    if st['difference'] is None:
        miss = [n for n, v in (('bank closing', st['bank_close']), ('Sage closing', st['sage_close'])) if v is None]
        add('Review', 'Reconciliation proof cannot be completed',
            f"No {' or '.join(miss)} balance could be verified. Enter it manually in the Statement tab - never assume 0.")
    elif st['difference'] == 0:
        add('Good', 'Adjusted bank balance equals adjusted book balance',
            'The reconciliation proves, subject to the reviewed exceptions.')
    else:
        add('Action', f"Unexplained difference of {st['difference']:,.2f}",
            'The reconciling items do not fully account for the gap between the two closing balances.')
        for e in st['explainers']:
            add('Review', 'Possible explanation', e)
    return out


# --------------------------------------------------------------------------- #
# Manual actions (all re-finalize)
# --------------------------------------------------------------------------- #
def _by_id(r):
    return {x['id']: x for x in r['sage'] + r['bank']}


def manual_match(r, sage_ids, bank_ids, note=''):
    ids = _by_id(r)
    S = [ids[i] for i in sage_ids if i in ids]
    B = [ids[i] for i in bank_ids if i in ids]
    if not S or not B:
        raise ValueError('Pick at least one Sage item and one bank item.')
    if any(x['direction'] != S[0]['direction'] for x in S + B):
        raise ValueError('All selected items must have the same direction (in / out).')
    ts, tb = sum((x['amount'] for x in S), ZERO), sum((x['amount'] for x in B), ZERO)
    reason = 'Manual match' + (f': {note}' if note else '') + ('' if ts == tb else f' (amounts differ by {tb - ts:,.2f})')
    m = _match_record('manual', S, B, 100, reason, auto=False)
    m['difference'] = tb - ts
    m['note'] = note
    r['matches'].append(m)
    if r.get('memory') is not None:
        r['memory'].learn(S, B)
    r['manual_log'].append(('match', m['id']))
    finalize(r)
    return m


def accept_suggestion(r, sid):
    s = next((x for x in r['suggestions'] if x['id'] == sid), None)
    if not s:
        raise ValueError('Suggestion no longer available.')
    return manual_match(r, [s['sage']['id']], [s['bank']['id']], note=s['detail'])


def unmatch(r, match_id):
    n = len(r['matches'])
    r['matches'] = [m for m in r['matches'] if m['id'] != match_id]
    r.setdefault('removed', []).append(match_id)
    if len(r['matches']) == n:
        raise ValueError('Match not found.')
    r['manual_log'].append(('unmatch', match_id))
    finalize(r)


def set_note(r, item_id, text):
    if text.strip():
        r['notes'][item_id] = text.strip()
    else:
        r['notes'].pop(item_id, None)


def set_manual_balance(r, key, value):
    if value is None:
        r['params']['manual_balances'].pop(key, None)
    else:
        r['params']['manual_balances'][key] = value
    finalize(r)


def suggest_period(sage=None, bank=None):
    """Best guess at the reconciliation period: the Sage report range, else the busiest calendar month."""
    if sage and sage.get('report_range'):
        return sage['report_range']
    counts = defaultdict(int)
    for src in (sage, bank):
        for x in (src or {}).get('transactions', []):
            counts[(x['date'].year, x['date'].month)] += 1
    if not counts:
        return None
    y, m = max(counts, key=lambda k: (counts[k], k))
    first = dt.date(y, m, 1)
    last = (dt.date(y + (m == 12), m % 12 + 1, 1) - dt.timedelta(days=1))
    return first, last


# --------------------------------------------------------------------------- #
# Risk flags, review state, sessions, file detection
# --------------------------------------------------------------------------- #
def _risk(r):
    """Attach plain-language risk flags to unmatched items (typical-size comparison within each source)."""
    import statistics
    for pool, un in ((r['sage'], r['sage_only']), (r['bank'], r['bank_only'])):
        amts = sorted(x['amount'] for x in pool)
        med = statistics.median(amts) if amts else ZERO
        p95 = amts[int(len(amts) * 0.95)] if len(amts) >= 10 else None
        for x in un:
            a, risks = x['amount'], []
            if a >= 100000 and a % 1000 == 0:
                risks.append('Round amount')
            if x['date'].weekday() >= 5 and x.get('category') not in ('Bank charge', 'Bank interest'):
                risks.append('Weekend date')
            if p95 is not None and a >= p95 and a >= 4 * med:
                risks.append('Unusually large')
            if not x['description'].strip() and not x['reference'].strip():
                risks.append('No description')
            x['risks'] = risks


def set_reviewed(r, ids, flag=True):
    for i in ids:
        (r['reviewed'].add if flag else r['reviewed'].discard)(i)


def reject_suggestion(r, sid):
    r['rejected'].add(sid)
    finalize(r)


def export_state(r):
    """JSON-safe snapshot of the human review work (not the raw data)."""
    return dict(
        version=1, saved=dt.datetime.now().isoformat(timespec='seconds'),
        params=dict(start=r['params']['start'].isoformat(), end=r['params']['end'].isoformat(),
                    days=r['params']['days'], lookback=r['params']['lookback']),
        manual_balances={k: str(v) for k, v in r['params']['manual_balances'].items()},
        matches=[dict(sage=[x['id'] for x in m['sage']], bank=[x['id'] for x in m['bank']], note=m.get('note', ''))
                 for m in r['matches'] if not m['auto']],
        removed=list(dict.fromkeys(r.get('removed', []))), rejected=sorted(r['rejected']),
        notes=dict(r['notes']), reviewed=sorted(r['reviewed']))


def apply_state(r, state):
    """Re-apply saved review work on top of a fresh run of the same files. Returns counts."""
    applied = skipped = 0
    ids = _by_id(r)
    for mid in state.get('removed', []):
        r['matches'] = [m for m in r['matches'] if m['id'] != mid]
    r['removed'] = list(state.get('removed', []))
    r['rejected'] |= set(state.get('rejected', []))
    for rec in state.get('matches', []):
        if all(i in ids for i in rec['sage'] + rec['bank']) and rec['sage'] and rec['bank']:
            want = set(rec['sage'] + rec['bank'])
            r['matches'] = [m for m in r['matches'] if not ({x['id'] for x in m['sage'] + m['bank']} & want)]
            try:
                manual_match(r, rec['sage'], rec['bank'], rec.get('note', ''))
                applied += 1
            except ValueError:
                skipped += 1
        else:
            skipped += 1
    for k, v in state.get('manual_balances', {}).items():
        val = money(v)
        if val is not None:
            r['params']['manual_balances'][k] = val
    r['notes'].update({k: v for k, v in state.get('notes', {}).items() if k in ids})
    r['reviewed'] |= {i for i in state.get('reviewed', []) if i in ids}
    finalize(r)
    return dict(applied=applied, skipped=skipped)


def classify_file(rows):
    """Guess whether an uploaded sheet is a 'sage' cashbook export or a 'bank' statement -> (kind, score)."""
    sage = bank = 0
    heads = []
    for i, r in enumerate(rows):
        labs = [clean_label(c) for c in r]
        txt = ' '.join(norm(c) for c in r if isinstance(c, str))
        if re.search(r'(opening|closing) balance as at', txt):
            sage += 3
        if i < 12 and ('date range' in txt or 'bank account' in txt[:20]):
            sage += 1
        if 'debit' in labs and 'credit' in labs:
            heads.append(labs)
            if any(x in labs for x in ('details', 'type', 'transaction type')):
                sage += 2
        if any(x in labs for x in ('withdrawal', 'withdrawals', 'deposit', 'deposits', 'narration', 'value date',
                                   'paid out', 'paid in', 'money in', 'money out', 'particulars')):
            bank += 3
    if header_candidates(rows) and not sage:
        bank += 1
    if sage >= 3 and sage > bank:
        return 'sage', sage
    if bank >= 3 and bank >= sage:
        return 'bank', bank
    return 'unknown', max(sage, bank)
