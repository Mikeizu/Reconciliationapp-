"""Guided review: walks the user through every open item with a recommended action."""
from __future__ import annotations

import tkinter as tk
from tkinter import simpledialog, ttk

import reconcile as R
from ui_widgets import AMBER, BG, BORDER, CARD, F, GREEN, MUTED, NAVY, RED, TEAL, TEAL_D, TEXT, button

SEV_ORDER = {'High': 0, 'Medium': 1, 'Low': 2}


class ReviewDialog(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.title('Guided review')
        self.geometry('860x600')
        self.minsize(720, 520)
        self.configure(bg=BG)
        self.transient(app.root)
        self.grab_set()
        self.tasks = self._build_tasks()
        self.total = len(self.tasks)
        self.pos = -1
        self.history = []
        self._ui()
        self.bind('<Escape>', lambda e: self.destroy())
        self.bind('<Right>', lambda e: self.skip())
        self.bind('<Left>', lambda e: self.back())
        self.next(first=True)

    # ------------------------------------------------------------------ tasks
    def _build_tasks(self):
        r = self.app.result
        tasks = [('pair', s['id']) for s in sorted(r['suggestions'], key=lambda s: -s['confidence'])]
        in_pair = {x['id'] for s in r['suggestions'] for x in (s['bank'], s['sage'])}
        items = [x for x in r['bank_only'] + r['sage_only'] if x['id'] not in in_pair and x['id'] not in r['reviewed']]
        items.sort(key=lambda x: (SEV_ORDER[x['severity']], -x['amount']))
        return tasks + [('item', x['id']) for x in items]

    def _valid(self, task):
        r = self.app.result
        kind, key = task
        if kind == 'pair':
            return any(s['id'] == key for s in r['suggestions'])
        return key not in r['reviewed'] and any(x['id'] == key for x in r['bank_only'] + r['sage_only'])

    def _item(self, iid):
        return next((x for x in self.app.result['bank_only'] + self.app.result['sage_only'] if x['id'] == iid), None)

    # ------------------------------------------------------------------ ui
    def _ui(self):
        top = tk.Frame(self, bg=BG)
        top.pack(fill='x', padx=18, pady=(14, 4))
        self.heading = tk.Label(top, text='', bg=BG, fg=NAVY, font=F(15, 'bold'))
        self.heading.pack(side='left')
        self.counter = tk.Label(top, text='', bg=BG, fg=MUTED, font=F(10))
        self.counter.pack(side='right')
        self.bar = ttk.Progressbar(self, maximum=max(1, self.total), mode='determinate', style='Light.Horizontal.TProgressbar')
        self.bar.pack(fill='x', padx=18, pady=(0, 8))
        self.btns = tk.Frame(self, bg=BG)
        self.btns.pack(side='bottom', fill='x', padx=18, pady=(8, 14))
        box = tk.Frame(self, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        box.pack(fill='both', expand=True, padx=18, pady=4)
        self.text = tk.Text(box, wrap='word', height=8, bg=CARD, fg=TEXT, font=F(11), relief='flat', padx=18, pady=14, state='disabled', cursor='arrow')
        self.text.pack(fill='both', expand=True)
        for tag, kw in (('h', dict(font=F(13, 'bold'), foreground=NAVY)), ('k', dict(foreground=MUTED, font=F(10))),
                        ('b', dict(font=F(11, 'bold'))), ('warn', dict(foreground=RED, font=F(11, 'bold'))),
                        ('good', dict(foreground=GREEN, font=F(11, 'bold'))), ('amber', dict(foreground=AMBER, font=F(11, 'bold')))):
            self.text.tag_configure(tag, **kw)

    def _set_text(self, parts):
        t = self.text
        t.config(state='normal')
        t.delete('1.0', 'end')
        for txt, tag in parts:
            t.insert('end', txt, tag)
        t.config(state='disabled')

    def _set_buttons(self, specs):
        for w in self.btns.winfo_children():
            w.destroy()
        for label, cmd, kind in specs:
            button(self.btns, label, cmd, kind, pady=7).pack(side='left', padx=(0, 8))
        button(self.btns, 'Close', self.destroy, 'ghost', pady=7).pack(side='right')

    # ------------------------------------------------------------------ navigation
    def next(self, first=False):
        i = self.pos + 1
        while i < len(self.tasks) and not self._valid(self.tasks[i]):
            i += 1
        if i >= len(self.tasks):
            self._finish()
            return
        if not first and self.pos >= 0:
            self.history.append(self.pos)
        self.pos = i
        self._show()

    skip = next

    def back(self):
        while self.history:
            i = self.history.pop()
            if self._valid(self.tasks[i]):
                self.pos = i
                self._show()
                return

    def _line(self, x):
        a = self.app
        return f'{x["source"]} row {x["row"]}   {x["date"]:%d/%m/%Y}   {a.fmt(x["amount"])}   {x["reference"] or "no ref"}   {x["description"] or "no description"}\n'

    def _show(self):
        a, r = self.app, self.app.result
        done = sum(1 for t in self.tasks[:self.pos] if not self._valid(t))
        self.bar['value'] = done
        self.counter.config(text=f'{done} of {self.total} done  •  step {self.pos + 1}')
        kind, key = self.tasks[self.pos]
        if kind == 'pair':
            s = next(s for s in r['suggestions'] if s['id'] == key)
            self.heading.config(text='Are these the same transaction?')
            diff = s['diff']
            self._set_text([(f'{s["kind"].replace("_", " ").title()}   -   confidence {s["confidence"]}%\n', 'k'),
                            (s['detail'] + '\n\n', 'b'), ('Bank   ', 'k'), (self._line(s['bank']), ''), ('Sage   ', 'k'), (self._line(s['sage']), ''),
                            ('\n', ''),
                            (('Amounts are identical.', 'good') if diff == 0 else
                             (f'Amount difference: {a.fmt(diff)} (bank - Sage). If you accept, it becomes a reconciling line and a proposed correcting journal.', 'amber')),
                            ('\n\nRecommended: ', 'k'), ('accept if the narrations and reference make sense to you; otherwise reject so it stops being suggested.', '')])
            self._set_buttons([('✔  Yes - match them', lambda: self._accept(key), 'primary'),
                               ('✖  Not a match', lambda: self._reject(key), 'ghost'), ('Skip  →', self.skip, 'ghost'), ('←  Back', self.back, 'ghost')])
        else:
            x = self._item(key)
            self.heading.config(text=f'{x["category"]}')
            risk = x.get('risks', [])
            parts = [(f'Priority {x["severity"]}   •   {"on the bank statement but not in Sage" if x["source"] == "Bank" else "in Sage but not on the bank statement"}\n', 'k'),
                     (self._line(x) + '\n', 'b'), ('What to do: ', 'k'), (x['action'] + '\n', '')]
            if risk:
                parts += [('\nWorth a closer look: ', 'k'), ('; '.join(risk) + '\n', 'amber')]
            if x['suggestion']:
                parts += [('\nNear-match hint: ', 'k'), (x['suggestion'] + '\n', '')]
            note = r['notes'].get(x['id'])
            if note:
                parts += [('\nYour note: ', 'k'), (note + '\n', '')]
            if x['category'] in ('Bank charge', 'Bank interest'):
                parts += [('\nA journal for this item is already proposed on the Journals tab.\n', 'good')]
            self._set_text(parts)
            self._set_buttons([('✓  Mark reviewed', lambda: self._review(key), 'primary'),
                               ('📝  Note + reviewed', lambda: self._note(key), 'ghost'), ('🔗  Match manually…', lambda: self._manual(x), 'ghost'),
                               ('Skip  →', self.skip, 'ghost'), ('←  Back', self.back, 'ghost')])

    def _finish(self):
        a, r = self.app, self.app.result
        self.bar['value'] = self.total
        self.heading.config(text='All done 🎉' if self.total else 'Nothing left to review 🎉')
        self.counter.config(text='')
        st = r['statement']
        verdict = ('The reconciliation proves (difference 0.00).' if st['reconciled'] else
                   'A closing balance is still missing.' if st['difference'] is None else f'A difference of {a.fmt(st["difference"])} remains - ask the assistant why.')
        self._set_text([(f'{self.total} task(s) reviewed.\n\n', 'b'), (verdict + '\n\n', 'good' if st['reconciled'] else 'amber'),
                        ('Next: export the Excel report and the proposed journals, then post the journals in Sage after review.', '')])
        self._set_buttons([('⬇  Export Excel report', lambda: (self.destroy(), a.export_excel()), 'primary'),
                           ('Proposed journals', lambda: (self.destroy(), a.nb.select(5)), 'ghost')])

    # ------------------------------------------------------------------ actions
    def _accept(self, sid):
        R.accept_suggestion(self.app.result, sid)
        self.app._after_change('Match accepted.')
        self.next()

    def _reject(self, sid):
        s = next(s for s in self.app.result['suggestions'] if s['id'] == sid)
        R.reject_suggestion(self.app.result, sid)
        self.app._after_change('Suggestion dismissed.')
        self.tasks += [('item', s['bank']['id']), ('item', s['sage']['id'])]     # now review them individually
        self.total += 2
        self.bar['maximum'] = max(1, self.total)
        self.next()

    def _review(self, iid):
        R.set_reviewed(self.app.result, [iid])
        self.app._after_change('Marked reviewed.')
        self.next()

    def _note(self, iid):
        txt = simpledialog.askstring('Reviewer note', 'Note for this item (appears in the Excel report):', parent=self)
        if txt is None:
            return
        R.set_note(self.app.result, iid, txt)
        R.set_reviewed(self.app.result, [iid])
        self.app._after_change('Note saved.')
        self.next()

    def _manual(self, x):
        pre_b, pre_s = ([x['id']], []) if x['source'] == 'Bank' else ([], [x['id']])
        dlg = self.app.open_match(pre_b, pre_s)
        self.wait_window(dlg)
        self.pos -= 1                # re-evaluate the same task: it moves on by itself if the item got matched
        self.next(first=True)
