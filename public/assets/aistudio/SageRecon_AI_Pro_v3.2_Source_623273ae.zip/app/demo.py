"""Synthetic demo data (fictional) - exercises every engine feature. Never uses real account data."""
from __future__ import annotations

import datetime as dt
import random
from decimal import Decimal

D = lambda s: Decimal(s)
d = lambda day, month=10: dt.date(2026, month, day)

# (sage_date, sage_desc, sage_ref, bank_date, bank_desc, bank_ref, amount, direction)  - None side = absent there
BOTH = [
    (d(1), 'Salary - September', 'CHQ 000231', d(2), 'CHQ 000231 PAID', '000231', '1250000.00', 'out'),
    (d(2), 'Receipt Dangote Retail INV1021', 'INV1021', d(2), 'NIP TRF DANGOTE RETAIL INV1021', 'NIP7731', '2400000.00', 'in'),
    (d(5), 'Alpha Supplies payment', 'TRF 77821', d(6), 'TRF TO ALPHA SUPPLIES 77821', '77821', '385500.00', 'out'),
    (d(8), 'Payment Beta Logistics', 'TRF 90311', d(8), 'NIP TRF BETA LOGISTICS 90311', '90311', '123456.00', 'out'),   # bank has 123,465.00 (see below)
    (d(10), 'Epsilon Consulting fee', 'TRF 88120', d(10), 'TRF EPSILON CONSULTING', '88120', '56000.00', 'out'),
    (d(12), 'Receipt Omega Foods', 'INV1034', d(13), 'NIP TRF OMEGA FOODS INV1034', 'NIP8120', '918250.00', 'in'),
    (d(15), 'Transport allowance', '', d(15), 'TRANSPORT ALLOWANCE', '', '15000.00', 'out'),
    (d(16), 'Transport allowance', '', d(16), 'TRANSPORT ALLOWANCE', '', '15000.00', 'out'),
    (d(19), 'Transport allowance', '', d(20), 'TRANSPORT ALLOWANCE', '', '15000.00', 'out'),
    (d(14), 'Payment Delta Services', 'TRF 55120', d(14), 'TRF DELTA SERVICES 55120', '55120', '77000.00', 'out'),
    (d(21), 'Receipt Sigma Pharma INV1050', 'INV1050', d(21), 'NIP TRF SIGMA PHARMA INV1050', 'NIP9012', '1745000.00', 'in'),
    (d(22), 'Rent - Q4', 'CHQ 000240', d(23), 'CHQ 000240 PAID', '000240', '900000.00', 'out'),
    (d(26), 'Receipt Lambda Stores', 'INV1062', d(26), 'NIP TRF LAMBDA STORES', 'NIP9340', '362800.00', 'in'),
]
# 3 Sage receipts banked as one cash deposit (batch)
BATCH_SAGE = [(d(6), 'Receipt Customer A', 'RCP101', '150000.00'), (d(7), 'Receipt Customer B', 'RCP102', '275000.00'),
              (d(8), 'Receipt Customer C', 'RCP103', '100000.00')]
BATCH_BANK = (d(9), 'CASH DEPOSIT BRANCH LAGOS', '', '525000.00')
BANK_ONLY = [
    (d(20), 'NIP TRF FROM UNKNOWN 8873321', '8873321', '500000.00', 'in'),
    (d(31), 'SMS ALERT CHARGES OCT', '', '2150.00', 'out'),
    (d(31), 'VAT ON CHARGES', '', '161.25', 'out'),
    (d(31), 'ACCOUNT MAINTENANCE FEE', '', '3000.00', 'out'),
    (d(31), 'STAMP DUTY', '', '50.00', 'out'),
    (d(31), 'CREDIT INTEREST', '', '12480.50', 'in'),
]
SAGE_ONLY = [
    (d(29), 'Payment Gamma Ltd', 'CHQ 000245', '90000.00', 'out'),          # outstanding cheque
    (d(30), 'Receipt Customer D', 'RCP110', '640000.00', 'in'),             # deposit in transit
    (d(12), 'Petty cash top-up', '', '200000.00', 'out'),                   # old, never cleared
    (d(14), 'Payment Delta Services', 'TRF 55120', '77000.00', 'out'),      # duplicate entry
    (d(2), 'Receipt Customer E INV1005', 'INV1005', '330000.00', 'in'),     # banked 18 days later
]
LATE_BANK = (d(20), 'NIP TRF CUSTOMER E INV1005', 'NIP7002', '330000.00', 'in')
BETA_BANK_AMOUNT = '123465.00'   # transposed vs Sage 123,456.00

OPEN = D('5000000.00')


def build(seed=7):
    rnd = random.Random(seed)
    sage, bank = [], []
    for sd, sdesc, sref, bd, bdesc, bref, amt, dr in BOTH:
        sage.append((sd, sdesc, sref, D(amt), dr))
        bank.append((bd, bdesc, bref, D(BETA_BANK_AMOUNT) if bdesc.startswith('NIP TRF BETA') else D(amt), dr))
    for sd, desc, ref, amt in BATCH_SAGE:
        sage.append((sd, desc, ref, D(amt), 'in'))
    bank.append((BATCH_BANK[0], BATCH_BANK[1], BATCH_BANK[2], D(BATCH_BANK[3]), 'in'))
    for bd, desc, ref, amt, dr in BANK_ONLY:
        bank.append((bd, desc, ref, D(amt), dr))
    bank.append((LATE_BANK[0], LATE_BANK[1], LATE_BANK[2], D(LATE_BANK[3]), 'in'))
    for sd, desc, ref, amt, dr in SAGE_ONLY:
        sage.append((sd, desc, ref, D(amt), dr))
    # filler: ordinary matched items with unique amounts
    names = ['Zenith Hardware', 'Kano Agro', 'Northern Print', 'Sahel Tech', 'Abuja Couriers', 'Crest Cleaning']
    for i in range(18):
        day = rnd.randint(1, 30)
        amt = D(f'{rnd.randint(8, 480) * 1000 + rnd.randint(1, 99) * 7}.{rnd.randint(0, 99):02d}')
        nm, dr = rnd.choice(names), rnd.choice(['in', 'out'])
        ref = f'{rnd.randint(10000, 99999)}'
        sage.append((d(day), f'{nm} {"receipt" if dr == "in" else "payment"}', ref, amt, dr))
        bank.append((d(min(31, day + rnd.randint(0, 2))), f'NIP TRF {nm.upper()} {ref}', ref, amt, dr))
    sage.sort(key=lambda t: t[0])
    bank.sort(key=lambda t: t[0])

    # ---- Sage rows (labelled layout)
    srows = [['Bank Account: 1200 - Operating Account (NGN)'], ['Date Range: 01/10/2026 to 31/10/2026'], [],
             ['Date', 'Type', 'Details', 'Reference', 'Debit', 'Credit', 'Balance']]
    bal = OPEN
    srows.append(['Opening balance as at: 01/10/2026', None, None, None, None, None, float(bal)])
    for dte, desc, ref, amt, dr in sage:
        bal += amt if dr == 'in' else -amt
        srows.append([dte.strftime('%d/%m/%Y'), 'Bank Payment' if dr == 'out' else 'Bank Receipt', desc, ref,
                      float(amt) if dr == 'in' else None, float(amt) if dr == 'out' else None, float(bal)])
    srows.append(['Closing balance as at: 31/10/2026', None, None, None, None, None, float(bal)])
    # ---- Bank rows
    brows = [['OPERATING ACCOUNT STATEMENT'], ['Account: 0123456789'], ['Period: 01/10/2026 - 31/10/2026'], [],
             ['Date', 'Description', 'Reference', 'Withdrawal', 'Deposit', 'Balance']]
    bb = OPEN
    for dte, desc, ref, amt, dr in bank:
        bb += amt if dr == 'in' else -amt
        brows.append([dte.strftime('%d/%m/%Y'), desc, ref, float(amt) if dr == 'out' else None,
                      float(amt) if dr == 'in' else None, float(bb)])
    brows.append(['Closing Balance', None, None, None, None, float(bb)])
    return srows, brows


def write_files(folder):
    """Write demo Sage .xlsx and bank .csv into a folder; returns (sage_path, bank_path)."""
    import csv
    from pathlib import Path

    from openpyxl import Workbook
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    srows, brows = build()
    wb = Workbook()
    ws = wb.active
    for r in srows:
        ws.append(r)
    sp = folder / 'demo_sage_cashbook.xlsx'
    wb.save(sp)
    bp = folder / 'demo_bank_statement.csv'
    with open(bp, 'w', newline='', encoding='utf-8-sig') as f:
        csv.writer(f).writerows([['' if v is None else v for v in r] for r in brows])
    return sp, bp
