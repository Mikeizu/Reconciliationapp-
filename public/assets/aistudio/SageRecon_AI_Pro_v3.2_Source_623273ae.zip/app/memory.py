"""Local, private 'learning': remembers how you pair Sage narrations with bank narrations."""
from __future__ import annotations

import json
from pathlib import Path

import reconcile as R


class Memory:
    MAX_LINKS = 500

    def __init__(self, data=None, path=None):
        self.path = Path(path) if path else None
        self.links = list((data or {}).get('links', []))

    @classmethod
    def load(cls, path):
        try:
            return cls(json.loads(Path(path).read_text(encoding='utf-8')), path)
        except Exception:
            return cls(None, path)

    def save(self):
        if self.path:
            try:
                self.path.write_text(json.dumps({'version': 1, 'links': self.links}), encoding='utf-8')
            except OSError:
                pass

    @staticmethod
    def _tokens(items):
        toks = set()
        for x in items:
            toks |= R._prep(x)['_tok']
        return sorted(toks, key=lambda t: (-len(t), t))[:3]

    def learn(self, sage_items, bank_items):
        s, b = self._tokens(sage_items), self._tokens(bank_items)
        if not s or not b:
            return False
        for link in self.links:
            if link['s'] == s and link['b'] == b:
                link['n'] += 1
                return True
        self.links.append(dict(s=s, b=b, n=1))
        del self.links[:-self.MAX_LINKS]
        return True

    def boost(self, s, b):
        ts, tb = R._prep(s)['_tok'], R._prep(b)['_tok']
        best = 0.0
        for link in self.links:
            if set(link['s']) <= ts and set(link['b']) <= tb:
                best = max(best, min(1.0, 0.6 + 0.2 * link['n']))
        return best

    def forget(self):
        self.links.clear()
        self.save()

    def __len__(self):
        return len(self.links)
