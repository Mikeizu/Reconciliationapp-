"""Report export: formatted Excel workbook (with live formulas in the statement) and flat CSV."""
from __future__ import annotations

import csv
import datetime as dt
from decimal import Decimal

import journals as J
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

NAVY, TEAL, GREY = '10243D', '087E86', 'F1F5F9'
NUM = '#,##0.00;[Red](#,##0.00);-'
HFONT = Font(bold=True, color='FFFFFF', name='Calibri')
HFILL = PatternFill('solid', fgColor=NAVY)
THIN = Side(style='thin', color='D9E2EC')
SEV_FILL = {'High': 'FDE4E1', 'Medium': 'FFF3D6', 'Low': 'EAF4EE'}


def _f(d):
    return float(d) if isinstance(d, Decimal) else d


def _direction_label(x):
    if x['source'] == 'Bank':
        return 'Deposit' if x['direction'] == 'in' else 'Withdrawal'
    return 'Debit (receipt)' if x['direction'] == 'in' else 'Credit (payment)'


def _table(ws, start_row, headers, rows, widths=None, money_cols=(), sev_col=None):
    for j, h in enumerate(headers, 1):
        c = ws.cell(start_row, j, h)
        c.font, c.fill = HFONT, HFILL
        c.alignment = Alignment(vertical='center', wrap_text=True)
    for i, row in enumerate(rows, start_row + 1):
        for j, v in enumerate(row, 1):
            c = ws.cell(i, j, _f(v))
            c.border = Border(bottom=THIN)
            c.alignment = Alignment(vertical='top', wrap_text=(j == len(row)))
            if j in money_cols:
                c.number_format = NUM
            if isinstance(v, (dt.date, dt.datetime)):
                c.number_format = 'DD/MM/YYYY'
        if sev_col and row[sev_col - 1] in SEV_FILL:
            ws.cell(i, sev_col).fill = PatternFill('solid', fgColor=SEV_FILL[row[sev_col - 1]])
    for j, w in enumerate(widths or [], 1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = ws.cell(start_row + 1, 1)
    if rows:
        ws.auto_filter.ref = f'A{start_row}:{get_column_letter(len(headers))}{start_row + len(rows)}'


def _exception_rows(r, items):
    notes, done = r.get('notes', {}), r.get('reviewed', set())
    return [[x['row'], x['date'], _direction_label(x), x['amount'], x['reference'], x['description'],
             x.get('category', ''), x.get('severity', ''), '; '.join(x.get('risks', [])), x.get('action', ''),
             x.get('suggestion', ''), 'Yes' if x['id'] in done else '', notes.get(x['id'], '')]
            for x in sorted(items, key=lambda i: (i['date'], i['row']))]


EXC_HEAD = ['Row', 'Date', 'Type', 'Amount', 'Reference', 'Description', 'Category', 'Priority', 'Risk flags',
            'Suggested action', 'Near-match hint', 'Reviewed', 'Reviewer note']
EXC_W = [7, 12, 16, 15, 18, 44, 22, 10, 26, 56, 44, 10, 34]


def export_xlsx(r, path, company='', account='', currency='NGN', prepared_by='', accounts=None):
    P, st, S = r['params'], r['statement'], r['summary']
    wb = Workbook()

    # ------------------------------------------------------------- Statement
    ws = wb.active
    ws.title = 'Reconciliation'
    ws.sheet_view.showGridLines = False
    ws.column_dimensions['A'].width = 58
    ws.column_dimensions['B'].width = 20
    ws.column_dimensions['C'].width = 62
    ws['A1'] = 'Bank Reconciliation Statement'
    ws['A1'].font = Font(size=18, bold=True, color=NAVY)
    meta = [('Company', company or '-'), ('Bank account', account or '-'), ('Currency', currency),
            ('Period', f"{P['start']:%d/%m/%Y} to {P['end']:%d/%m/%Y}"),
            ('Date tolerance', f"{P['days']} day(s)"), ('Prepared by', prepared_by or '-'),
            ('Generated', f'{dt.datetime.now():%d/%m/%Y %H:%M}')]
    for i, (k, v) in enumerate(meta, 3):
        ws.cell(i, 1, k).font = Font(bold=True, color='526174')
        ws.cell(i, 2, v)
    row = 11

    def line(label, value=None, bold=False, formula=None, note='', fill=None):
        nonlocal row
        a = ws.cell(row, 1, label)
        b = ws.cell(row, 2, formula if formula else _f(value))
        b.number_format = NUM
        ws.cell(row, 3, note).font = Font(italic=True, color='526174', size=9)
        if bold:
            a.font = b.font = Font(bold=True)
            for c in (a, b):
                c.border = Border(top=THIN, bottom=THIN)
        if fill:
            for c in (a, b):
                c.fill = PatternFill('solid', fgColor=fill)
        row += 1
        return row - 1

    def head(t):
        nonlocal row
        c = ws.cell(row, 1, t)
        c.font, c.fill = HFONT, HFILL
        ws.cell(row, 2).fill = HFILL
        ws.cell(row, 3).fill = HFILL
        row += 1

    miss = 'NOT VERIFIED'
    head('A. Per bank statement')
    bc = line('Closing balance per bank statement', st['bank_close'] if st['bank_close'] is not None else miss,
              note=st['bank_close_src'] or 'Not available - enter it in the app')
    r1 = line('Add: deposits in transit (Sage receipts not yet on statement)', st['deposits_in_transit'])
    r2 = line('Less: outstanding payments (Sage payments not yet on statement)', st['outstanding_payments'])
    ab = line('Adjusted bank balance', bold=True, formula=f'=IF(ISNUMBER(B{bc}),B{bc}+B{r1}-B{r2},"{miss}")', fill=GREY)
    row += 1
    head('B. Per Sage cashbook')
    sc = line('Closing balance per Sage', st['sage_close'] if st['sage_close'] is not None else miss,
              note=st['sage_close_src'] or 'Not available - enter it in the app')
    r3 = line('Add: bank deposits not yet recorded in Sage', st['bank_deposits_not_in_sage'])
    r4 = line('Less: bank withdrawals not yet recorded in Sage', st['bank_withdrawals_not_in_sage'])
    r5 = line('Add/(less): amount differences on accepted matches (correct in Sage)', st['amount_adjustments'])
    abk = line('Adjusted book balance', bold=True, formula=f'=IF(ISNUMBER(B{sc}),B{sc}+B{r3}-B{r4}+B{r5},"{miss}")', fill=GREY)
    row += 1
    head('C. Proof')
    line('Difference (adjusted bank - adjusted book)', bold=True,
         formula=f'=IF(AND(ISNUMBER(B{ab}),ISNUMBER(B{abk})),B{ab}-B{abk},"{miss}")',
         note='Should be 0.00. A residual usually means opening-balance items, ignored rows or a posting error.',
         fill='FFF3D6' if st['difference'] not in (None, 0) else 'EAF4EE')
    row += 1
    head('D. Matching statistics')
    for k, v in [('Sage transactions', S['n_sage']), ('Bank transactions', S['n_bank']),
                 ('Matched groups', S['n_matches']),
                 ('  high / medium / low confidence', f"{S['n_high']} / {S['n_medium']} / {S['n_low']}"),
                 ('  batch / split groupings', S['n_groups']),
                 ('Bank lines matched', f"{S['pct_bank_count']:.1f}%"), ('Sage lines matched', f"{S['pct_sage_count']:.1f}%"),
                 ('Bank items not in Sage', S['n_bank_only']), ('Sage items not on bank', S['n_sage_only']),
                 ('Exceptions reviewed', f"{len(r.get('reviewed', set()) & {x['id'] for x in r['bank_only'] + r['sage_only']})} of {S['n_bank_only'] + S['n_sage_only']}")]:
        ws.cell(row, 1, k)
        ws.cell(row, 2, v).alignment = Alignment(horizontal='right')
        row += 1
    row += 1
    head('E. Analyst notes')
    for ins in r['insights']:
        ws.cell(row, 1, f"[{ins['level']}] {ins['title']}").font = Font(bold=True)
        c = ws.cell(row, 3, ins['detail'])
        c.alignment = Alignment(wrap_text=True, vertical='top')
        row += 1
    row += 1
    ws.cell(row, 1, 'Unmatched items are investigation candidates, not confirmed errors. Generated offline by SageRecon AI Pro; '
                    'no accounting records were changed.').font = Font(italic=True, size=9, color='526174')

    # ------------------------------------------------------------- Exceptions
    ws2 = wb.create_sheet('Bank not in Sage')
    _table(ws2, 1, EXC_HEAD, _exception_rows(r, r['bank_only']), EXC_W, money_cols=(4,), sev_col=8)
    ws3 = wb.create_sheet('Sage not on Bank')
    _table(ws3, 1, EXC_HEAD, _exception_rows(r, r['sage_only']), EXC_W, money_cols=(4,), sev_col=8)

    # ------------------------------------------------------------- Matched
    ws4 = wb.create_sheet('Matched')
    rows = []
    for m in sorted(r['matches'], key=lambda m: (m['confidence'], m['bank'][0]['date'])):
        rows.append([m['kind'].title(), m['confidence'], m['level'], ', '.join(str(x['row']) for x in m['sage']),
                     ', '.join(str(x['row']) for x in m['bank']), m['bank'][0]['date'], m['sage'][0]['date'],
                     sum((x['amount'] for x in m['bank']), Decimal(0)),
                     'in' if m['bank'][0]['direction'] == 'in' else 'out', m['reason']])
    _table(ws4, 1, ['Type', 'Confidence', 'Level', 'Sage row(s)', 'Bank row(s)', 'Bank date', 'Sage date', 'Amount',
                    'Direction', 'Why it matched'], rows, [10, 11, 9, 14, 14, 12, 12, 15, 10, 90], money_cols=(8,))

    # ------------------------------------------------------------- Suggestions
    ws5 = wb.create_sheet('Suggestions')
    rows = [[s['kind'].replace('_', ' ').title(), s['confidence'], s['bank']['row'], s['bank']['date'], s['bank']['amount'],
             s['sage']['row'], s['sage']['date'], s['sage']['amount'], s['diff'], s['detail']] for s in r['suggestions']]
    _table(ws5, 1, ['Kind', 'Confidence', 'Bank row', 'Bank date', 'Bank amount', 'Sage row', 'Sage date', 'Sage amount',
                    'Difference (bank - Sage)', 'Observation'], rows, [16, 11, 9, 12, 15, 9, 12, 15, 18, 80], money_cols=(5, 8, 9))

    # ------------------------------------------------------------- Data quality
    ws6 = wb.create_sheet('Data quality')
    rows = [[f['level'], f['title'], f['detail']] for f in r['flags']]
    for name, src in (('Sage', r['sage_src']), ('Bank', r['bank_src'])):
        for s in src.get('skipped', []):
            rows.append(['High', f"{name} row {s['row']} ignored", f"{s['reason']}; amount {abs(s['amount']):,.2f}; {s['text']}"])
    _table(ws6, 1, ['Level', 'Finding', 'Detail'], rows, [10, 52, 120], sev_col=1)
    # ------------------------------------------------------------- Proposed journals
    ws7 = wb.create_sheet('Proposed journals')
    entries = J.propose(r, accounts)
    rows = [row[:1] + [row[1]] + row[2:] for row in J.flat_rows(entries)]
    _table(ws7, 1, J.HEADERS, rows, [8, 12, 22, 30, 60, 15, 15, 14, 18], money_cols=(6, 7))
    ws7.cell(len(rows) + 3, 1, 'Proposals only - nothing has been posted. Items marked "Needs review" are parked in Suspense until you '
                               'confirm the correct account.').font = Font(italic=True, size=9, color='526174')
    from openpyxl.worksheet.properties import PageSetupProperties
    for sheet in wb.worksheets:
        sheet.page_setup.orientation = 'landscape'
        sheet.page_setup.fitToWidth, sheet.page_setup.fitToHeight = 1, 0
        sheet.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
        sheet.print_title_rows = '1:1' if sheet.title != 'Reconciliation' else None
    wb.save(path)


def export_csv(r, path):
    notes = r.get('notes', {})
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['Finding', 'Source', 'Original Row', 'Date', 'Direction', 'Amount', 'Reference', 'Description',
                    'Category', 'Priority', 'Suggested action', 'Matched with row(s)', 'Confidence', 'Note'])
        for typ, key in (('Bank transaction missing in Sage', 'bank_only'), ('Sage transaction missing in bank', 'sage_only')):
            for x in r[key]:
                w.writerow([typ, x['source'], x['row'], x['date'], x['direction'], x['amount'], x['reference'],
                            x['description'], x.get('category', ''), x.get('severity', ''), x.get('action', ''), '', '',
                            notes.get(x['id'], '')])
        for m in r['matches']:
            for x in m['sage'] + m['bank']:
                other = m['bank'] if x['source'] == 'Sage' else m['sage']
                w.writerow([f"Matched ({m['kind']})", x['source'], x['row'], x['date'], x['direction'], x['amount'],
                            x['reference'], x['description'], '', '', '', ', '.join(str(o['row']) for o in other),
                            m['confidence'], ''])
        st = r['statement']
        w.writerow([])
        for k in ('bank_close', 'deposits_in_transit', 'outstanding_payments', 'adjusted_bank', 'sage_close',
                  'bank_deposits_not_in_sage', 'bank_withdrawals_not_in_sage', 'adjusted_book', 'difference'):
            w.writerow([k.replace('_', ' ').title(), st[k] if st[k] is not None else 'NOT VERIFIED'])
