"""SageRecon AI Pro 3.0 - private, offline bank reconciliation."""
from __future__ import annotations

import datetime as dt
import json
import os
import queue
import sys
import threading
import tkinter as tk
from decimal import Decimal
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))

import assistant  # noqa: E402
import journals  # noqa: E402
import reconcile as R  # noqa: E402
from memory import Memory  # noqa: E402
from report import export_csv, export_xlsx  # noqa: E402
from ui_dialogs import ReviewDialog  # noqa: E402
from ui_simple import SimpleView  # noqa: E402
from ui_widgets import (AMBER, BG, BLUE, BORDER, CARD, F, GREEN, GREEN_BG, LEVEL_COLORS, MUTED, NAVY, NAVY2,  # noqa: E402
                        RED, RED_BG, TEAL, TEAL_D, TEAL_L, TEXT, Collapsible, Grid, ScrollFrame, WrapLabel,
                        attach_tooltip, button, card, setup_style)

APP_NAME, VERSION = 'SageRecon AI Pro', '3.2'
SETTINGS = Path.home() / '.sagerecon_ai_pro.json'
MEMORY_PATH = Path.home() / '.sagerecon_ai_pro_memory.json'
CURRENCIES = {'₦  NGN': '₦', '$  USD': '$', '£  GBP': '£', '€  EUR': '€', 'No symbol': ''}
MAP_FIELDS = [('date', 'Date *'), ('withdrawal', 'Withdrawal (out)'), ('deposit', 'Deposit (in)'),
              ('amount', 'Single amount col.'), ('balance', 'Running balance'), ('description', 'Description'),
              ('reference', 'Reference')]

MATCH_COLS = [('conf', 'Conf.', 66, 'e', False), ('level', 'Level', 70, 'w', False), ('kind', 'Type', 66, 'w', False),
              ('date', 'Date', 88, 'w', False), ('amount', 'Amount', 116, 'e', False), ('srow', 'Sage row', 90, 'w', False),
              ('brow', 'Bank row', 90, 'w', False), ('sdesc', 'Sage description', 230, 'w', True),
              ('bdesc', 'Bank description', 230, 'w', True), ('why', 'Why it matched', 420, 'w', True)]
EXC_COLS = [('rv', '✓', 34, 'center', False), ('sev', 'Priority', 86, 'w', False), ('row', 'Row', 52, 'e', False),
            ('date', 'Date', 88, 'w', False), ('type', 'Type', 104, 'w', False), ('amount', 'Amount', 116, 'e', False),
            ('cat', 'Category', 160, 'w', False), ('risk', 'Risk flags', 170, 'w', True), ('ref', 'Reference', 110, 'w', False),
            ('desc', 'Description', 270, 'w', True), ('act', 'Suggested action', 430, 'w', True),
            ('hint', 'Near-match hint', 280, 'w', True), ('note', 'Note', 160, 'w', True)]
JR_COLS = [('no', 'Entry', 64, 'e', False), ('date', 'Date', 92, 'w', False), ('ref', 'Reference', 170, 'w', False),
           ('acct', 'Account', 180, 'w', False), ('desc', 'Details', 260, 'w', True), ('dr', 'Debit', 108, 'e', False),
           ('cr', 'Credit', 108, 'e', False), ('rev', 'Review?', 80, 'w', False)]
SUG_COLS = [('conf', 'Conf.', 58, 'e', False), ('kind', 'Kind', 150, 'w', False), ('brow', 'Bank row', 70, 'e', False),
            ('bdate', 'Bank date', 88, 'w', False), ('bamt', 'Bank amount', 112, 'e', False),
            ('srow', 'Sage row', 70, 'e', False), ('sdate', 'Sage date', 88, 'w', False),
            ('samt', 'Sage amount', 112, 'e', False), ('diff', 'Bank - Sage', 104, 'e', False),
            ('obs', 'Observation', 480, 'w', True)]
DATA_COLS = [('row', 'Row', 50, 'e', False), ('date', 'Date', 88, 'w', False), ('in', 'In', 108, 'e', False),
             ('out', 'Out', 108, 'e', False), ('ref', 'Reference', 100, 'w', False), ('desc', 'Description', 220, 'w', True)]
SEV_TAGS = {'High': (TEXT, RED_BG), 'Medium': (TEXT, '#fff5dc'), 'Low': (TEXT, 'white'), 'done': (MUTED, '#eef2f6')}
LVL_TAGS = {'Medium': (TEXT, '#fff5dc'), 'Low': (TEXT, RED_BG)}
SEV_ORDER = {'High': 0, 'Medium': 1, 'Low': 2}


def parse_date(text):
    return dt.datetime.strptime(text.strip(), '%d/%m/%Y').date()


class App:
    def __init__(self, root):
        self.root = root
        root.title(f'{APP_NAME}  |  Private Bank Reconciliation')
        root.geometry('1240x860')
        root.minsize(1180, 700)
        root.configure(bg=BG)
        setup_style(root)
        self.cfg = self._load_settings()
        self.sage = self.bank = self.result = None
        self.bank_rows, self.bank_header = [], 0
        self.sage_name = self.bank_name = ''
        self.period_touched = False
        self.dirty = False
        self.sym = CURRENCIES.get(self.cfg.get('currency', '₦  NGN'), '₦')
        self.q = queue.Queue()
        self.memory = Memory.load(MEMORY_PATH)
        self.view = self.cfg.get('view', 'simple')
        self.bank_problems, self.sage_problems = [], []
        self.acc = {}
        self.map_boxes = {}
        self._build()
        self.update_coach()
        self._bind_keys()
        root.protocol('WM_DELETE_WINDOW', self.on_close)

    # ------------------------------------------------------------------ settings
    def _load_settings(self):
        try:
            return json.loads(SETTINGS.read_text(encoding='utf-8'))
        except Exception:
            return {}

    def _save_settings(self):
        try:
            self.cfg.update(view=self.view, currency=self.cur.get(), tolerance=self.days.get(), lookback=self.lookback.get(),
                            company=self.company.get(), account=self.account.get(), prepared=self.prepared.get(),
                            **{'acc_' + k: v.get() for k, v in self.acc.items()})
            SETTINGS.write_text(json.dumps(self.cfg), encoding='utf-8')
        except Exception:
            pass

    # ------------------------------------------------------------------ formatting
    def fmt(self, v, sym=True):
        if v is None:
            return 'NOT VERIFIED'
        s = f'{abs(v):,.2f}'
        pre = self.sym if sym else ''
        return f'-{pre}{s}' if v < 0 else f'{pre}{s}'

    def num(self, v):
        return f'{v:,.2f}'

    # ------------------------------------------------------------------ layout
    def _build(self):
        r = self.root
        r.grid_rowconfigure(2, weight=1)
        r.grid_columnconfigure(0, weight=1)
        self._header()
        self._coach()
        self.body = body = ttk.PanedWindow(r, orient='horizontal')
        body.grid(row=2, column=0, sticky='nsew', padx=10, pady=(10, 6))
        side = ScrollFrame(body)
        body.add(side, weight=0)
        side.canvas.configure(width=352)
        self._sidebar(side.inner)
        work = tk.Frame(body, bg=BG)
        body.add(work, weight=1)
        self._workspace(work)
        self._statusbar()
        self.simple = SimpleView(r, self)
        self.set_view(self.view)

    def _header(self):
        h = tk.Frame(self.root, bg=NAVY)
        h.grid(row=0, column=0, sticky='ew')
        tk.Label(h, text='SageRecon', bg=NAVY, fg='white', font=F(20, 'bold')).pack(side='left', padx=(20, 0), pady=12)
        tk.Label(h, text=' AI PRO', bg=NAVY, fg='#5fd0d6', font=F(20, 'bold')).pack(side='left')
        lock = tk.Label(h, text='🔒  Private - works offline', bg=NAVY2, fg='#cfe6ea', font=F(9, 'bold'),
                        padx=12, pady=6)
        lock.pack(side='right', padx=18)
        self.view_btn = button(h, 'Detailed view', lambda: self.set_view('detailed' if self.view == 'simple' else 'simple'), 'dark', pady=5, font=F(9, 'bold'))
        self.view_btn.pack(side='right', padx=(0, 6))
        attach_tooltip(self.view_btn, 'Switch between the simple step-by-step view\nand the detailed accountant view')
        self.root.option_add('*tearOff', False)
        m = tk.Menu(self.root)
        fm = tk.Menu(m)
        fm.add_command(label='Load demo data', command=self.load_demo)
        fm.add_separator()
        fm.add_command(label='Save review session…', command=self.save_session)
        fm.add_command(label='Open review session…', command=self.open_session)
        fm.add_separator()
        fm.add_command(label='Export Excel report…   Ctrl+E', command=self.export_excel)
        fm.add_command(label='Export CSV…', command=self.export_csv_file)
        fm.add_command(label='Export proposed journals (CSV)…', command=self.export_journals)
        fm.add_separator()
        fm.add_command(label='Exit', command=self.on_close)
        m.add_cascade(label='File', menu=fm)
        tm = tk.Menu(m)
        tm.add_command(label='Guided review…   Ctrl+G', command=self.start_review)
        tm.add_command(label='Ask the assistant…   Ctrl+K', command=lambda: self.ask_preset(''))
        tm.add_separator()
        tm.add_command(label='Forget what the app has learned', command=self.forget_memory)
        m.add_cascade(label='Tools', menu=tm)
        hm = tk.Menu(m)
        hm.add_command(label='How matching works   F1', command=self.about)
        m.add_cascade(label='Help', menu=hm)
        self.root.config(menu=m)

    def _sidebar(self, p):
        both = button(p, '📂  Choose both files at once…', self.pick_both, 'dark', pady=9)
        both.pack(fill='x', padx=(0, 8), pady=(0, 10))
        attach_tooltip(both, 'Select the Sage export and the bank statement together.\nThe app works out which is which.')
        # ---- 1 Sage
        c1 = card(p, 'Sage cashbook', 1)
        c1.pack(fill='x', padx=(0, 8), pady=(0, 10))
        button(c1.body, '📂  Choose Sage file…', self.pick_sage).pack(fill='x')
        self.sage_state = tk.Frame(c1.body, bg=CARD)
        self.sage_state.pack(fill='x', pady=(8, 0))
        self._set_lines(self.sage_state, [('No file selected  (.xlsx, .xls, .csv)', MUTED)])
        # ---- 2 Bank
        c2 = card(p, 'Bank statement', 2)
        c2.pack(fill='x', padx=(0, 8), pady=(0, 10))
        button(c2.body, '📂  Choose bank statement…', self.pick_bank).pack(fill='x')
        self.bank_state = tk.Frame(c2.body, bg=CARD)
        self.bank_state.pack(fill='x', pady=(8, 4))
        self._set_lines(self.bank_state, [('No file selected  (.xlsx, .xls, .csv)', MUTED)])
        self.map_box = Collapsible(c2.body, 'Column mapping (verify)', open_=True)
        self.map_box.pack(fill='x', pady=(6, 0))
        mb = self.map_box.body
        hr = tk.Frame(mb, bg=CARD)
        hr.pack(fill='x', pady=2)
        tk.Label(hr, text='Header row', bg=CARD, fg=MUTED, font=F(9), width=17, anchor='w').pack(side='left')
        self.hdr = tk.IntVar(value=1)
        ttk.Spinbox(hr, from_=1, to=500, width=6, textvariable=self.hdr, command=self.redetect).pack(side='left')
        button(hr, 'Re-detect', self.redetect, 'ghost', padx=8, pady=3, font=F(9, 'bold')).pack(side='left', padx=8)
        for key, label in MAP_FIELDS:
            row = tk.Frame(mb, bg=CARD)
            row.pack(fill='x', pady=2)
            tk.Label(row, text=label, bg=CARD, fg=TEXT, font=F(9), width=17, anchor='w').pack(side='left')
            cb = ttk.Combobox(row, state='readonly', width=26)
            cb.pack(side='left', fill='x', expand=True)
            cb.bind('<<ComboboxSelected>>', lambda e: self.refresh_bank())
            self.map_boxes[key] = cb
        sg = tk.Frame(mb, bg=CARD)
        sg.pack(fill='x', pady=2)
        tk.Label(sg, text='Signed amount', bg=CARD, fg=TEXT, font=F(9), width=17, anchor='w').pack(side='left')
        self.sign = ttk.Combobox(sg, state='readonly', width=26,
                                 values=['Negative = withdrawal', 'Positive = withdrawal'])
        self.sign.current(0)
        self.sign.pack(side='left', fill='x', expand=True)
        self.sign.bind('<<ComboboxSelected>>', lambda e: self.refresh_bank())
        WrapLabel(mb, pad=6, text='Use "Single amount col." only if the bank has one signed column instead of separate '
                                  'Withdrawal / Deposit columns.', bg=CARD, fg=MUTED, font=F(8)).pack(fill='x', pady=(4, 0))
        # ---- 3 Reconcile
        c3 = card(p, 'Reconcile', 3)
        c3.pack(fill='x', padx=(0, 8), pady=(0, 10))
        b = c3.body
        self.start, self.end = tk.StringVar(), tk.StringVar()
        grid = tk.Frame(b, bg=CARD)
        grid.pack(fill='x')
        for i, (lab, var) in enumerate((('Start (DD/MM/YYYY)', self.start), ('End date', self.end))):
            tk.Label(grid, text=lab, bg=CARD, fg=MUTED, font=F(9)).grid(row=0, column=i, sticky='w', padx=(0, 6))
            e = ttk.Entry(grid, textvariable=var, width=14)
            e.grid(row=1, column=i, sticky='ew', padx=(0, 6), pady=(2, 8))
            e.bind('<Key>', lambda ev: setattr(self, 'period_touched', True))
            grid.grid_columnconfigure(i, weight=1)
        row = tk.Frame(b, bg=CARD)
        row.pack(fill='x', pady=(0, 6))
        tk.Label(row, text='Date tolerance (days)', bg=CARD, fg=TEXT, font=F(9), width=17, anchor='w').pack(side='left')
        self.days = ttk.Combobox(row, values=['0', '1', '2', '3', '4', '5', '7', '10', '14'], state='readonly', width=6)
        self.days.set(self.cfg.get('tolerance', '3'))
        self.days.pack(side='left')
        button(row, 'Auto', self.auto_period, 'ghost', padx=8, pady=3, font=F(9, 'bold')).pack(side='right')
        adv = Collapsible(b, 'Advanced options')
        adv.pack(fill='x', pady=(2, 8))
        r1 = tk.Frame(adv.body, bg=CARD)
        r1.pack(fill='x', pady=2)
        tk.Label(r1, text='Look-back (days)', bg=CARD, fg=TEXT, font=F(9), width=20, anchor='w').pack(side='left')
        self.lookback = ttk.Combobox(r1, values=['0', '15', '30', '45', '60', '90'], state='readonly', width=6)
        self.lookback.set(self.cfg.get('lookback', '0'))
        self.lookback.pack(side='left')
        attach_tooltip(self.lookback, 'Also consider items dated before the period start, e.g. cheques from the\n'
                                      'previous month that cleared now. Unmatched ones count as reconciling items.')
        r2 = tk.Frame(adv.body, bg=CARD)
        r2.pack(fill='x', pady=2)
        tk.Label(r2, text='Currency symbol', bg=CARD, fg=TEXT, font=F(9), width=20, anchor='w').pack(side='left')
        self.cur = ttk.Combobox(r2, values=list(CURRENCIES), state='readonly', width=10)
        self.cur.set(self.cfg.get('currency', '₦  NGN'))
        self.cur.pack(side='left')
        self.cur.bind('<<ComboboxSelected>>', lambda e: self._currency_changed())
        self.run_btn = button(b, '▶   RUN SMART RECONCILIATION', self.run, pady=12, font=F(11, 'bold'))
        self.run_btn.pack(fill='x', pady=(4, 2))
        WrapLabel(b, pad=4, text='Ctrl+R  •  Nothing is written to Sage. Unmatched ≠ wrong - they are items to investigate.',
                  bg=CARD, fg=MUTED, font=F(8)).pack(fill='x', pady=(4, 0))
        # ---- report details
        c4 = card(p, None)
        c4.pack(fill='x', padx=(0, 8), pady=(0, 10))
        rd = Collapsible(c4.body, 'Report & journal details (optional)')
        rd.pack(fill='x')
        self.company, self.account, self.prepared = (tk.StringVar(value=self.cfg.get(k, '')) for k in ('company', 'account', 'prepared'))
        for lab, var in (('Company', self.company), ('Bank account', self.account), ('Prepared by', self.prepared)):
            rr = tk.Frame(rd.body, bg=CARD)
            rr.pack(fill='x', pady=2)
            tk.Label(rr, text=lab, bg=CARD, fg=TEXT, font=F(9), width=14, anchor='w').pack(side='left')
            ttk.Entry(rr, textvariable=var).pack(side='left', fill='x', expand=True)
        tk.Label(rd.body, text='Account names for proposed journals', bg=CARD, fg=MUTED, font=F(9, 'bold')).pack(anchor='w', pady=(8, 2))
        for key, lab in (('bank', 'Bank account'), ('charges', 'Bank charges'), ('interest', 'Interest income'), ('suspense', 'Suspense')):
            rr = tk.Frame(rd.body, bg=CARD)
            rr.pack(fill='x', pady=2)
            tk.Label(rr, text=lab, bg=CARD, fg=TEXT, font=F(9), width=14, anchor='w').pack(side='left')
            self.acc[key] = tk.StringVar(value=self.cfg.get('acc_' + key, journals.DEFAULT_ACCOUNTS[key]))
            ttk.Entry(rr, textvariable=self.acc[key]).pack(side='left', fill='x', expand=True)

    def _set_lines(self, frame, lines):
        for w in frame.winfo_children():
            w.destroy()
        for text, color in lines:
            WrapLabel(frame, pad=4, text=text, bg=CARD, fg=color, font=F(9)).pack(fill='x', pady=1)

    def _workspace(self, p):
        p.grid_rowconfigure(2, weight=1)
        p.grid_columnconfigure(0, weight=1)
        # KPI cards
        kp = tk.Frame(p, bg=BG)
        kp.grid(row=0, column=0, sticky='ew', pady=(0, 8))
        self.kpis = {}
        for i, (key, title) in enumerate((('match', 'MATCH RATE'), ('open', 'ITEMS TO REVIEW'),
                                          ('value', 'VALUE TO INVESTIGATE'), ('proof', 'RECONCILIATION PROOF'))):
            kc = tk.Frame(kp, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            kc.grid(row=0, column=i, sticky='nsew', padx=(0 if i == 0 else 8, 0))
            kp.grid_columnconfigure(i, weight=1, uniform='k')
            tk.Label(kc, text=title, bg=CARD, fg=MUTED, font=F(8, 'bold')).pack(anchor='w', padx=14, pady=(10, 0))
            big = tk.Label(kc, text='-', bg=CARD, fg=NAVY, font=F(19, 'bold'))
            big.pack(anchor='w', padx=14)
            sub = tk.Label(kc, text=' ', bg=CARD, fg=MUTED, font=F(9))
            sub.pack(anchor='w', padx=14, pady=(0, 10))
            self.kpis[key] = (big, sub)
        # toolbar
        tb = tk.Frame(p, bg=BG)
        tb.grid(row=1, column=0, sticky='ew', pady=(0, 6))
        tk.Label(tb, text='🔍', bg=BG, font=F(11)).pack(side='left')
        self.search = tk.StringVar()
        self.search.trace_add('write', lambda *a: self._apply_filter())
        self.search_entry = ttk.Entry(tb, textvariable=self.search, width=28)
        self.search_entry.pack(side='left', padx=(4, 14))
        self.btn_match = button(tb, '🔗  Match…', self.manual_dialog, 'ghost', pady=5)
        self.btn_accept = button(tb, '✔  Accept', self.accept_selected, 'ghost', pady=5)
        self.btn_unmatch = button(tb, '↶  Unmatch', self.unmatch_selected, 'ghost', pady=5)
        self.btn_note = button(tb, '📝  Note', self.add_note, 'ghost', pady=5)
        self.btn_review = button(tb, '✓  Reviewed', self.toggle_reviewed, 'ghost', pady=5)
        for b, tip in ((self.btn_match, 'Pair a bank item with Sage items yourself (Ctrl+M)'), (self.btn_accept, 'Accept the selected near-match suggestion(s)'),
                       (self.btn_unmatch, 'Break the selected match(es)'), (self.btn_note, 'Add a reviewer note shown in the Excel report'),
                       (self.btn_review, 'Tick / untick the selected item(s) as reviewed')):
            attach_tooltip(b, tip)
        for b in (self.btn_match, self.btn_accept, self.btn_unmatch, self.btn_note, self.btn_review):
            b.pack(side='left', padx=(0, 6))
        button(tb, '⬇  Excel report', self.export_excel, 'primary', pady=5).pack(side='right')
        button(tb, 'CSV', self.export_csv_file, 'ghost', pady=5).pack(side='right', padx=6)
        # notebook
        self.nb = ttk.Notebook(p)
        self.nb.grid(row=2, column=0, sticky='nsew')
        self.nb.bind('<<NotebookTabChanged>>', lambda e: self._tab_changed())
        self._tab_overview()
        gm = dict(on_select=self._on_select)
        self.g_match = Grid(self.nb, MATCH_COLS, tags=LVL_TAGS, **gm)
        self.g_match.sort_col = 'conf'   # lowest confidence first: that is where review time pays off
        self.g_bank = Grid(self.nb, EXC_COLS, tags=SEV_TAGS, **gm)
        self.g_sage = Grid(self.nb, EXC_COLS, tags=SEV_TAGS, **gm)
        self.g_sug = Grid(self.nb, SUG_COLS, **gm)
        for g, title in ((self.g_match, 'Matched'), (self.g_bank, 'Not in Sage'), (self.g_sage, 'Not on Bank'),
                         (self.g_sug, 'Hints')):
            self.nb.add(g, text=title)
        for g in (self.g_bank, self.g_sage):
            g.tree.bind('<Double-1>', lambda e: self.manual_dialog())
        self.g_sug.tree.bind('<Double-1>', lambda e: self.accept_selected())
        self._tab_journals()
        self._tab_ask()
        for g in (self.g_match, self.g_bank, self.g_sage, self.g_sug, self.g_ask, self.g_jr):
            g.tree.bind('<Button-3>', lambda e, g=g: self._ctx(e, g))
            g.tree.bind('<Button-2>', lambda e, g=g: self._ctx(e, g))
        data = tk.Frame(self.nb, bg=BG)
        self.nb.add(data, text='Data')
        data.grid_columnconfigure((0, 1), weight=1, uniform='d')
        data.grid_rowconfigure(1, weight=1)
        for i, t in enumerate(('Sage cashbook (parsed)', 'Bank statement (parsed)')):
            tk.Label(data, text=t, bg=BG, fg=NAVY, font=F(10, 'bold')).grid(row=0, column=i, sticky='w', padx=8, pady=6)
        self.g_dsage, self.g_dbank = Grid(data, DATA_COLS), Grid(data, DATA_COLS)
        self.g_dsage.grid(row=1, column=0, sticky='nsew', padx=(0, 4))
        self.g_dbank.grid(row=1, column=1, sticky='nsew', padx=(4, 0))
        # details
        dv = tk.Frame(p, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        dv.grid(row=3, column=0, sticky='ew', pady=(8, 0))
        self.details = tk.Text(dv, height=4, wrap='word', bg=CARD, fg=TEXT, font=F(10), relief='flat', padx=12, pady=8,
                               state='disabled', cursor='arrow')
        self.details.pack(fill='x')
        self.details.tag_configure('h', font=F(10, 'bold'), foreground=NAVY)
        self.details.tag_configure('k', foreground=MUTED)
        self.details.tag_configure('warn', foreground=RED, font=F(10, 'bold'))
        self._set_details([('Select a row to see the full explanation here.', 'k')])
        self._tab_changed()

    def _tab_overview(self):
        ov = tk.Frame(self.nb, bg=BG)
        self.nb.add(ov, text='Overview')
        self.ov = ov
        pw = ttk.PanedWindow(ov, orient='horizontal')
        pw.pack(fill='both', expand=True, pady=(8, 0))
        self.stmt_scroll = ScrollFrame(pw, bg=CARD)
        self.stmt_frame = self.stmt_scroll.inner
        pw.add(self.stmt_scroll, weight=3)
        right = tk.Frame(pw, bg=BG)
        pw.add(right, weight=2)
        tk.Label(right, text='  AI analyst notes & data-quality checks', bg=BG, fg=NAVY, font=F(11, 'bold')).pack(anchor='w', pady=(0, 4))
        self.insights = ScrollFrame(right)
        self.insights.pack(fill='both', expand=True, padx=(8, 0))
        # welcome overlay
        w = tk.Frame(ov, bg=CARD)
        self.welcome = w
        w.place(relx=0, rely=0, relwidth=1, relheight=1)
        inner = tk.Frame(w, bg=CARD)
        inner.place(relx=0.5, rely=0.46, anchor='center')
        tk.Label(inner, text='Reconcile your bank in three steps', bg=CARD, fg=NAVY, font=F(20, 'bold')).pack()
        steps = ('1   Choose your Sage cashbook export', '2   Choose the bank statement and confirm the column mapping',
                 '3   Pick the period and run - the engine matches, explains and proves the reconciliation')
        for s in steps:
            tk.Label(inner, text=s, bg=CARD, fg=MUTED, font=F(12)).pack(anchor='w', pady=5, padx=30)
        tk.Label(inner, text='Matching includes confidence scores, batch/split deposits, near-miss detection (transposed digits, '
                             'timing, fees), bank-charge recognition and a full bank reconciliation statement.',
                 bg=CARD, fg=MUTED, font=F(10), wraplength=620, justify='center').pack(pady=(14, 18))
        button(inner, 'Try it with demo data', self.load_demo, 'primary', padx=24, pady=11, font=F(11, 'bold')).pack()

    def _statusbar(self):
        sb = tk.Frame(self.root, bg=NAVY)
        sb.grid(row=3, column=0, sticky='ew')
        self.status = tk.StringVar(value='Ready. Load your Sage cashbook and bank statement - nothing is uploaded anywhere.')
        tk.Label(sb, textvariable=self.status, bg=NAVY, fg='white', anchor='w', padx=16, pady=7, font=F(9)).pack(side='left', fill='x', expand=True)
        self.progress = ttk.Progressbar(sb, mode='indeterminate', length=140, style='Teal.Horizontal.TProgressbar')
        tk.Label(sb, text=f'v{VERSION}', bg=NAVY, fg='#7f95ad', font=F(9)).pack(side='right', padx=14)

    def _bind_keys(self):
        r = self.root
        r.bind('<Control-r>', lambda e: self.run())
        r.bind('<Control-e>', lambda e: self.export_excel())
        r.bind('<Control-f>', lambda e: (self.search_entry.focus_set(), self.search_entry.select_range(0, 'end')))
        r.bind('<Control-m>', lambda e: self.manual_dialog())
        r.bind('<Control-g>', lambda e: self.start_review())
        r.bind('<Control-k>', lambda e: self.ask_preset(''))
        r.bind('<F1>', lambda e: self.about())

    # ------------------------------------------------------------------ small helpers
    def say(self, msg):
        self.status.set(msg)

    def busy(self, on, msg=None):
        if on:
            self.progress.pack(side='right', padx=8)
            self.progress.start(12)
            self.run_btn.config(state='disabled')
        else:
            self.progress.stop()
            self.progress.pack_forget()
            self.run_btn.config(state='normal')
        if msg:
            self.say(msg)

    def _set_details(self, parts):
        t = self.details
        t.config(state='normal')
        t.delete('1.0', 'end')
        for text, tag in parts:
            t.insert('end', text, tag)
        t.config(state='disabled')

    def _currency_changed(self):
        self.sym = CURRENCIES[self.cur.get()]
        if self.result:
            self.render()

    # ------------------------------------------------------------------ loading files
    def _dialog_dir(self):
        d = self.cfg.get('last_dir')
        return d if d and Path(d).exists() else None

    def pick_sage(self):
        path = filedialog.askopenfilename(title='Select Sage cashbook export', initialdir=self._dialog_dir(),
                                          filetypes=[('Spreadsheet / CSV', '*.xlsx *.xls *.csv'), ('All files', '*.*')])
        if path:
            self.cfg['last_dir'] = str(Path(path).parent)
            try:
                rows, _ = R.read_workbook(path)
                if self._wrong_kind(rows, Path(path).name, 'sage'):
                    return
                self.ingest_sage(rows, Path(path).name)
            except Exception as e:
                messagebox.showerror("We couldn't read that file", f'{e}\n\nTip: export the bank account transactions from Sage as Excel or CSV.')

    def pick_bank(self):
        path = filedialog.askopenfilename(title='Select bank statement', initialdir=self._dialog_dir(),
                                          filetypes=[('Spreadsheet / CSV', '*.xlsx *.xls *.csv'), ('All files', '*.*')])
        if path:
            self.cfg['last_dir'] = str(Path(path).parent)
            try:
                rows, _ = R.read_workbook(path)
                if self._wrong_kind(rows, Path(path).name, 'bank'):
                    return
                self.ingest_bank(rows, Path(path).name)
            except Exception as e:
                messagebox.showerror("We couldn't read that file", str(e))

    def ingest_sage(self, rows, name):
        self.sage = R.sage_parse(rows)
        self.sage_name = name
        s = self.sage
        lines = [(f'✓  {name}', GREEN), (f'{len(s["transactions"])} transactions read', TEXT)]
        if s['opening'] is not None:
            lines.append((f'Opening balance: {self.fmt(s["opening"])}', MUTED))
        if s['closing'] is not None:
            lines.append((f'Closing balance: {self.fmt(s["closing"])}' + (f'  as at {s["closing_date"]:%d/%m/%Y}' if s['closing_date'] else ''), MUTED))
        if s['skipped']:
            lines.append((f'⚠  {len(s["skipped"])} row(s) with amounts ignored - unreadable date', RED))
        for w in s['warnings'][:3]:
            lines.append(('⚠  ' + w, AMBER))
        self.sage_problems = ([f'{len(s["skipped"])} entr{"y" if len(s["skipped"]) == 1 else "ies"} in the Sage file could not be read (unclear date) and were left out.'] if s['skipped'] else [])
        self._set_lines(self.sage_state, lines)
        self._fill_data()
        self._maybe_period()
        self.say(f'Sage cashbook loaded: {len(s["transactions"])} transactions.')

    def ingest_bank(self, rows, name):
        cands = R.header_candidates(rows)
        if not cands:
            raise ValueError('No recognisable bank header row found.\nThe statement needs columns such as Date, '
                             'Withdrawal/Debit, Deposit/Credit (or Amount) and Balance.\nYou can also export a clean CSV from your bank.')
        self.bank_rows, self.bank_name = rows, name
        self.bank_header = cands[0][1]
        self.hdr.set(self.bank_header + 1)
        self._fill_mapping(cands[0][2])
        self.refresh_bank()

    def _fill_mapping(self, mapping):
        from openpyxl.utils import get_column_letter
        hdr = self.bank_rows[self.bank_header] if self.bank_header < len(self.bank_rows) else []
        names = [f'{get_column_letter(i + 1)}   {str(v)[:30] if v not in (None, "") else "(blank)"}' for i, v in enumerate(hdr)]
        for key, cb in self.map_boxes.items():
            cb['values'] = ['(not used)'] + names
            cb.current(mapping[key] + 1 if key in mapping and mapping[key] < len(names) else 0)

    def redetect(self):
        if not self.bank_rows:
            return
        try:
            self.bank_header = max(0, min(int(self.hdr.get()) - 1, len(self.bank_rows) - 1))
        except (tk.TclError, ValueError):
            return
        self._fill_mapping(R.detect_mapping(self.bank_rows, self.bank_header))
        self.refresh_bank()

    def mapping(self):
        return {k: (cb.current() - 1 if cb.current() > 0 else None) for k, cb in self.map_boxes.items()}

    def refresh_bank(self):
        if not self.bank_rows:
            return
        m = self.mapping()
        lines = [(f'✓  {self.bank_name}', GREEN)]
        health = R.mapping_health(self.bank_rows, self.bank_header, m)
        try:
            self.bank = R.bank_parse(self.bank_rows, self.bank_header, m,
                                     'positive_withdrawal' if self.sign.current() == 1 else 'negative_withdrawal')
        except ValueError as e:
            self.bank = None
            self.bank_problems = [str(e)]
            lines.append(('⚠  ' + str(e), RED))
            self._set_lines(self.bank_state, lines)
            self._fill_data()
            return
        b = self.bank
        lines.append((f'{len(b["transactions"])} transactions read  (header row {self.bank_header + 1})', TEXT))
        for msg in health['messages']:
            lines.append(('⚠  ' + msg, RED))
        if b['skipped']:
            lines.append((f'⚠  {len(b["skipped"])} row(s) with amounts ignored - unreadable date', RED))
        integ = b['integrity']
        probs = list(health['messages'])
        if b['skipped']:
            probs.append(f'{len(b["skipped"])} line(s) on the bank statement could not be read (unclear date) and were left out.')
        if integ['breaks']:
            probs.append('The running balance on the statement does not add up, so some columns may have been read wrongly.')
        self.bank_problems = probs
        if integ['order'] != 'unknown':
            if integ['breaks']:
                lines.append((f'⚠  Running balance fails on {len(integ["breaks"])} row(s) - check mapping', RED))
            else:
                lines.append((f'✓  Running balance ties out ({integ["order"]} order, {integ["checked"]} steps)', GREEN))
        elif m.get('balance') is None:
            lines.append(('ℹ  No balance column mapped - closing balance must be typed in manually', MUTED))
        if b['stated_close'] is not None:
            lines.append((f'Statement closing balance: {self.fmt(b["stated_close"])}', MUTED))
        self._set_lines(self.bank_state, lines)
        clean = (integ['order'] != 'unknown' and not integ['breaks'] and not health['messages'] and not b['skipped'])
        self.map_box.set_open(not clean)
        self._fill_data()
        self._maybe_period()
        self.say(f'Bank statement loaded: {len(b["transactions"])} transactions.')

    def _fill_data(self):
        def rows(src):
            out = []
            for x in (src['transactions'] if src else []):
                out.append(dict(iid=x['id'], values=[x['row'], f'{x["date"]:%d/%m/%Y}', self.num(x['amount']) if x['direction'] == 'in' else '',
                                                      self.num(x['amount']) if x['direction'] == 'out' else '', x['reference'], x['description']],
                                sort=[x['row'], x['date'], x['amount'] if x['direction'] == 'in' else 0,
                                      x['amount'] if x['direction'] == 'out' else 0, x['reference'], x['description']]))
            return out
        self.g_dsage.load(rows(self.sage), 'Load the Sage cashbook')
        self.g_dbank.load(rows(self.bank), 'Load the bank statement and check the mapping')
        self.update_coach()
        self._simple_refresh()

    def _maybe_period(self):
        if self.period_touched or not (self.sage or self.bank):
            return
        p = R.suggest_period(self.sage, self.bank)
        if p:
            self.start.set(f'{p[0]:%d/%m/%Y}')
            self.end.set(f'{p[1]:%d/%m/%Y}')

    def auto_period(self):
        self.period_touched = False
        self._maybe_period()

    def load_demo(self):
        from demo import build
        srows, brows = build()
        self.period_touched = False
        self.ingest_sage(srows, 'DEMO - Sage cashbook (fictional)')
        self.ingest_bank(brows, 'DEMO - Bank statement (fictional)')
        self.run()

    # ------------------------------------------------------------------ run
    def run(self):
        try:
            if not self.sage:
                raise ValueError('Load the Sage cashbook first (step 1).')
            if not self.bank:
                raise ValueError('Load the bank statement and fix its column mapping first (step 2).')
            try:
                s, e = parse_date(self.start.get()), parse_date(self.end.get())
            except ValueError:
                raise ValueError('Enter the period dates as DD/MM/YYYY, e.g. 01/10/2026.')
            if s > e:
                raise ValueError('Period start must not be after period end.')
        except ValueError as err:
            messagebox.showwarning('Cannot run yet', str(err))
            return
        args = dict(sage=self.sage, bank=self.bank, start=s, end=e, days=int(self.days.get()), lookback=int(self.lookback.get()), memory=self.memory)
        self.busy(True, 'Matching transactions…')

        def work():
            try:
                self.q.put(('ok', R.compare(**args)))
            except Exception as ex:  # noqa: BLE001
                self.q.put(('err', ex))
        threading.Thread(target=work, daemon=True).start()
        self.root.after(60, self._poll)

    def _poll(self):
        try:
            kind, payload = self.q.get_nowait()
        except queue.Empty:
            self.root.after(80, self._poll)
            return
        self.busy(False)
        if kind == 'err':
            messagebox.showerror('Reconciliation failed', str(payload))
            return
        self.result = payload
        self.simple.screen = 'results'
        self.simple.expanded.clear()
        self.simple.opened.clear()
        self.dirty = False
        self.welcome.place_forget()
        self.render()
        st = payload['statement']
        verdict = ('reconciled - difference 0.00' if st['reconciled'] else
                   'closing balance not verified' if st['difference'] is None else f'difference {self.fmt(st["difference"])}')
        self.say(f'Done: {len(payload["matches"])} matches, {len(payload["bank_only"]) + len(payload["sage_only"])} items to review; {verdict}.')
        self.nb.select(0)

    # ------------------------------------------------------------------ rendering
    def render(self):
        r = self.result
        if not r:
            return
        S, st = r['summary'], r['statement']
        big, sub = self.kpis['match']
        pct = (S['pct_bank_count'] + S['pct_sage_count']) / 2
        big.config(text=f'{pct:.0f}%', fg=GREEN if pct >= 90 else AMBER if pct >= 70 else RED)
        sub.config(text=f'{S["n_matches"]} matches  •  {S["n_high"]} high-confidence')
        big, sub = self.kpis['open']
        n = S['n_bank_only'] + S['n_sage_only']
        ids = {x['id'] for x in r['bank_only'] + r['sage_only']}
        left = len(ids - r['reviewed'])
        big.config(text=str(left), fg=GREEN if left == 0 else NAVY)
        sub.config(text=f'{len(ids & r["reviewed"])} of {n} reviewed  •  {len(r["suggestions"])} hints')
        big, sub = self.kpis['value']
        total = sum((x['amount'] for x in r['bank_only'] + r['sage_only']), Decimal(0))
        big.config(text=self.fmt(total), fg=NAVY)
        sub.config(text='gross value, unmatched items')
        big, sub = self.kpis['proof']
        if st['difference'] is None:
            big.config(text='Not verified', fg=AMBER, font=F(15, 'bold'))
            sub.config(text='closing balance missing')
        elif st['difference'] == 0:
            big.config(text='✓ Reconciled', fg=GREEN, font=F(15, 'bold'))
            sub.config(text='adjusted bank = adjusted book')
        else:
            big.config(text=self.fmt(st['difference']), fg=RED, font=F(15, 'bold'))
            sub.config(text='unexplained difference')
        self._render_statement()
        self._render_insights()
        self._render_grids()
        self.update_coach()
        self._simple_refresh()

    def _render_statement(self):
        f = self.stmt_frame
        for w in f.winfo_children():
            w.destroy()
        r, st, P = self.result, self.result['statement'], self.result['params']
        f.grid_columnconfigure(0, weight=1)
        tk.Label(f, text='Bank reconciliation statement', bg=CARD, fg=NAVY, font=F(14, 'bold')).grid(row=0, column=0, columnspan=3, sticky='w', padx=16, pady=(14, 0))
        tk.Label(f, text=f'{P["start"]:%d %b %Y}  -  {P["end"]:%d %b %Y}   •   tolerance {P["days"]} day(s)', bg=CARD, fg=MUTED, font=F(9)).grid(
            row=1, column=0, columnspan=3, sticky='w', padx=16, pady=(0, 8))
        row = [2]

        def band(text):
            tk.Label(f, text=text, bg='#e7edf4', fg=NAVY, font=F(9, 'bold'), anchor='w', padx=16, pady=6).grid(row=row[0], column=0, columnspan=3, sticky='ew', pady=(8, 2))
            row[0] += 1

        def line(label, value, bold=False, note='', setter=None, color=TEXT, bg=CARD):
            tk.Label(f, text=label, bg=bg, fg=color, font=F(10, 'bold' if bold else 'normal'), anchor='w', padx=16, pady=3).grid(row=row[0], column=0, sticky='ew')
            vtxt = self.fmt(value) if value is not None else 'NOT VERIFIED'
            tk.Label(f, text=vtxt, bg=bg, fg=(AMBER if value is None else color), font=F(10, 'bold' if bold else 'normal'), anchor='e', padx=8).grid(row=row[0], column=1, sticky='e')
            if setter:
                button(f, 'Set…', setter, 'ghost', padx=8, pady=1, font=F(8, 'bold')).grid(row=row[0], column=2, padx=(0, 14))
            else:
                tk.Label(f, text='', bg=bg, width=7).grid(row=row[0], column=2)
            row[0] += 1
            if note:
                tk.Label(f, text=note, bg=bg, fg=MUTED, font=F(8), anchor='w', padx=28).grid(row=row[0], column=0, columnspan=3, sticky='ew')
                row[0] += 1

        d = st['difference']
        ok = d == 0 if d is not None else None
        pill_bg, pill_fg = (GREEN_BG, GREEN) if ok else ('#fff5dc', AMBER) if d is None else (RED_BG, RED)
        txt = '✓  RECONCILED  -  difference 0.00' if ok else ('Cannot prove - a closing balance is missing' if d is None else f'Unexplained difference  {self.fmt(d)}')
        tk.Label(f, text=txt, bg=pill_bg, fg=pill_fg, font=F(12, 'bold'), pady=12).grid(row=row[0], column=0, columnspan=3, sticky='ew', padx=16, pady=(4, 2))
        row[0] += 1
        band('A.  PER BANK STATEMENT')
        line('Closing balance per bank', st['bank_close'], note=st['bank_close_src'] or 'Not found - click Set… to enter it',
             setter=lambda: self.set_balance('bank_close', 'bank statement'))
        line('Add: deposits in transit', st['deposits_in_transit'], note='Sage receipts not yet on the bank statement')
        line('Less: outstanding payments', st['outstanding_payments'], note='Sage payments not yet cleared by the bank')
        line('Adjusted bank balance', st['adjusted_bank'], bold=True, bg='#f1f5f9')
        band('B.  PER SAGE CASHBOOK')
        line('Closing balance per Sage', st['sage_close'], note=st['sage_close_src'] or 'Not found - click Set… to enter it',
             setter=lambda: self.set_balance('sage_close', 'Sage cashbook'))
        line('Add: bank deposits not in Sage', st['bank_deposits_not_in_sage'], note='Receipts to record in Sage')
        line('Less: bank withdrawals not in Sage', st['bank_withdrawals_not_in_sage'], note='Payments / charges to record in Sage')
        if st['amount_adjustments']:
            line('Add/(less): accepted amount differences', st['amount_adjustments'], note='Correct these amounts in Sage')
        line('Adjusted book balance', st['adjusted_book'], bold=True, bg='#f1f5f9')
        if st['raw_difference'] is not None:
            tk.Label(f, text=f'Raw closing difference (Sage - bank): {self.fmt(st["raw_difference"])}', bg=CARD, fg=MUTED, font=F(9)).grid(
                row=row[0], column=0, columnspan=3, sticky='w', padx=16, pady=(8, 12))

    def _render_insights(self):
        sf = self.insights
        sf.clear()
        items = [(i['level'], i['title'], i['detail']) for i in self.result['insights']]
        items += [({'High': 'Action', 'Medium': 'Review', 'Low': 'Info'}[x['level']], x['title'], x['detail']) for x in self.result['flags']]
        for level, title, detail in items:
            fg, bg = LEVEL_COLORS.get(level, (BLUE, '#e6eefa'))
            c = tk.Frame(sf.inner, bg=bg)
            c.pack(fill='x', pady=3, padx=(0, 4))
            tk.Frame(c, bg=fg, width=5).pack(side='left', fill='y')
            inner = tk.Frame(c, bg=bg)
            inner.pack(side='left', fill='both', expand=True, padx=10, pady=7)
            tk.Label(inner, text=level.upper(), bg=bg, fg=fg, font=F(8, 'bold'), anchor='w').pack(fill='x')
            WrapLabel(inner, pad=6, text=title, bg=bg, fg=TEXT, font=F(10, 'bold')).pack(fill='x')
            WrapLabel(inner, pad=6, text=detail, bg=bg, fg=MUTED, font=F(9)).pack(fill='x')

    def _exc_row(self, x):
        d = 'Deposit' if x['direction'] == 'in' else 'Withdrawal'
        if x['source'] == 'Sage':
            d = 'Debit (receipt)' if x['direction'] == 'in' else 'Credit (payment)'
        note = self.result['notes'].get(x['id'], '')
        done = x['id'] in self.result['reviewed']
        risk = '; '.join(x.get('risks', []))
        return dict(iid=x['id'], tag='done' if done else (x['severity'] if x['severity'] != 'Low' else None),
                    values=['✓' if done else '', x['severity'], x['row'], f'{x["date"]:%d/%m/%Y}', d, self.num(x['amount']), x['category'], risk,
                            x['reference'], x['description'], x['action'], x['suggestion'], note],
                    sort=[int(done), SEV_ORDER[x['severity']], x['row'], x['date'], d, x['amount'], x['category'], risk, x['reference'],
                          x['description'], x['action'], x['suggestion'], note])

    def _render_grids(self):
        r = self.result
        trunc = lambda items: ' + '.join(x['description'] or x['reference'] or f'row {x["row"]}' for x in items)[:120]
        rows = []
        for m in r['matches']:
            b0, s0 = m['bank'][0], m['sage'][0]
            amt = sum((x['amount'] for x in m['bank']), Decimal(0))
            rows.append(dict(iid=m['id'], tag=m['level'] if m['level'] != 'High' else None,
                             values=[m['confidence'], m['level'], m['kind'].title(), f'{b0["date"]:%d/%m/%Y}', self.num(amt),
                                     ', '.join(str(x['row']) for x in m['sage']), ', '.join(str(x['row']) for x in m['bank']),
                                     trunc(m['sage']), trunc(m['bank']), m['reason']],
                             sort=[m['confidence'], m['level'], m['kind'], b0['date'], amt, s0['row'], b0['row'], trunc(m['sage']), trunc(m['bank']), m['reason']]))
        self.g_match.load(rows, 'No matches found')
        self.g_bank.load([self._exc_row(x) for x in r['bank_only']], '🎉  Every bank line is accounted for in Sage')
        self.g_sage.load([self._exc_row(x) for x in r['sage_only']], '🎉  Every Sage line appears on the bank statement')
        sug = []
        for s in r['suggestions']:
            b, g = s['bank'], s['sage']
            sug.append(dict(iid=s['id'], values=[s['confidence'], s['kind'].replace('_', ' ').title(), b['row'], f'{b["date"]:%d/%m/%Y}', self.num(b['amount']),
                                                  g['row'], f'{g["date"]:%d/%m/%Y}', self.num(g['amount']), f'{s["diff"]:+,.2f}', s['detail']],
                           sort=[s['confidence'], s['kind'], b['row'], b['date'], b['amount'], g['row'], g['date'], g['amount'], s['diff'], s['detail']]))
        self.g_sug.load(sug, 'No near-match suggestions')
        for idx, (title, n) in enumerate((('Overview', None), ('Matched', len(rows)), ('Not in Sage', len(r['bank_only'])),
                                          ('Not on Bank', len(r['sage_only'])), ('Hints', len(sug)))):
            self.nb.tab(idx, text=title if n is None else f'{title}  ({n})')
        self.render_journals()
        self.nb.tab(5, text=f'Journals  ({len(self._entries)})')
        self._apply_filter()

    # ------------------------------------------------------------------ interaction
    def _grids(self):
        return [self.g_match, self.g_bank, self.g_sage, self.g_sug, self.g_jr, self.g_dsage, self.g_dbank]

    def _current_grid(self):
        return {1: self.g_match, 2: self.g_bank, 3: self.g_sage, 4: self.g_sug, 5: self.g_jr, 6: self.g_ask}.get(self._current_idx())

    def _apply_filter(self):
        for g in self._grids():
            g.set_filter(self.search.get())

    def _current_idx(self):
        return self.nb.index(self.nb.select())

    def _tab_changed(self):
        i = self._current_idx()
        states = {self.btn_match: i in (2, 3, 6), self.btn_accept: i == 4, self.btn_unmatch: i == 1,
                  self.btn_note: i in (2, 3, 6), self.btn_review: i in (2, 3, 6)}
        for b, on in states.items():
            b.config(state='normal' if on else 'disabled', fg=TEAL_D if on else '#9aa8b8')

    def _on_select(self, grid):
        r = self.result
        sel = grid.selected()
        if not r or not sel:
            return
        iid = sel[0]
        K = lambda t: (t, 'k')
        H = lambda t: (t, 'h')
        item = lambda x: f'{x["source"]} row {x["row"]}  •  {x["date"]:%d/%m/%Y}  •  {self.fmt(x["amount"])}  •  {x["reference"] or "no ref"}  •  {x["description"] or "no description"}\n'
        if grid is self.g_match:
            m = next((m for m in r['matches'] if m['id'] == iid), None)
            if m:
                parts = [H(f'{m["kind"].title()} match - confidence {m["confidence"]}% ({m["level"]})\n'), K('Why: '), (m['reason'] + '\n', '')]
                parts += [K('Sage:  '), (''.join(item(x) + '        ' for x in m['sage']).rstrip() + '\n', '')]
                parts += [K('Bank:  '), (''.join(item(x) + '        ' for x in m['bank']).rstrip(), '')]
                self._set_details(parts)
        elif grid in (self.g_bank, self.g_sage, self.g_ask):
            x = next((x for x in r['bank_only'] + r['sage_only'] if x['id'] == iid), None)
            if x:
                parts = [H(f'{x["category"]}  -  priority {x["severity"]}\n'), (item(x), ''), K('Suggested action: '), (x['action'] + '\n', '')]
                if x.get('risks'):
                    parts += [K('Risk flags: '), ('; '.join(x['risks']) + '\n', 'warn')]
                if x['suggestion']:
                    parts += [K('Near-match hint: '), (x['suggestion'] + '\n', '')]
                if r['notes'].get(x['id']):
                    parts += [K('Your note: '), (r['notes'][x['id']], '')]
                self._set_details(parts)
        elif grid is self.g_sug:
            s = next((s for s in r['suggestions'] if s['id'] == iid), None)
            if s:
                self._set_details([H(f'{s["kind"].replace("_", " ").title()}  -  confidence {s["confidence"]}%\n'), (s['detail'] + '\n', ''),
                                   K('Bank:  '), (item(s['bank']), ''), K('Sage:  '), (item(s['sage']), ''),
                                   K('Double-click or press "Accept suggestion" to treat them as the same transaction. Any amount difference '
                                     'becomes a reconciling line to correct in Sage.'), ('', '')])

    def _need_result(self):
        if not self.result:
            messagebox.showinfo('Run first', 'Run the reconciliation first.')
            return False
        return True

    def accept_selected(self):
        if not self._need_result():
            return
        sel = self.g_sug.selected()
        if not sel:
            messagebox.showinfo('Select a suggestion', 'Select one or more rows in the Suggestions tab.')
            return
        sug = {s['id']: s for s in self.result['suggestions']}
        diff = sum((abs(sug[i]['diff']) for i in sel if i in sug), Decimal(0))
        msg = f'Treat {len(sel)} suggested pair(s) as matched?'
        if diff:
            msg += f'\n\nTotal amount difference of {self.fmt(diff)} will be shown as a reconciling line - correct it in Sage.'
        if not messagebox.askyesno('Accept suggestion', msg):
            return
        for i in sel:
            try:
                R.accept_suggestion(self.result, i)
            except ValueError:
                pass
        self._after_change('Suggestion(s) accepted.')

    def unmatch_selected(self):
        if not self._need_result():
            return
        sel = self.g_match.selected()
        if not sel:
            messagebox.showinfo('Select a match', 'Select one or more rows in the Matched tab.')
            return
        if not messagebox.askyesno('Unmatch', f'Break {len(sel)} match(es) and return the items to the exception lists?'):
            return
        for i in sel:
            try:
                R.unmatch(self.result, i)
            except ValueError:
                pass
        self._after_change('Match(es) removed.')

    def add_note(self):
        if not self._need_result():
            return
        g = self._current_grid()
        sel = [i for i in (g.selected() if g else []) if i[0] in 'BS' and not i.startswith('SG:')]
        if not sel:
            messagebox.showinfo('Select an item', 'Select an exception row first.')
            return
        cur = self.result['notes'].get(sel[0], '')
        text = simpledialog.askstring('Reviewer note', 'Note for this item (shown in the Excel report):', initialvalue=cur, parent=self.root)
        if text is None:
            return
        for i in sel:
            R.set_note(self.result, i, text)
        self._after_change('Note saved.')

    def set_balance(self, key, label):
        cur = self.result['statement'][key]
        text = simpledialog.askstring('Closing balance', f'Closing balance per {label} as at {self.result["params"]["end"]:%d/%m/%Y}\n'
                                      f'(leave empty to go back to the automatic value):',
                                      initialvalue='' if key not in self.result['params']['manual_balances'] else f'{cur:,.2f}', parent=self.root)
        if text is None:
            return
        text = text.strip()
        if text:
            v = R.money(text)
            if v is None:
                messagebox.showerror('Invalid amount', 'Please enter a number such as 9,481,486.80')
                return
            R.set_manual_balance(self.result, key, v)
        else:
            R.set_manual_balance(self.result, key, None)
        self._after_change('Balance updated.')

    def _after_change(self, msg):
        self.dirty = True
        self.memory.save()
        self.render()
        st = self.result['statement']
        self.say(msg + ('  Reconciled.' if st['reconciled'] else '' if st['difference'] is None else f'  Difference now {self.fmt(st["difference"])}.'))

    # ------------------------------------------------------------------ simple / detailed view
    def set_view(self, mode):
        self.view = mode
        if mode == 'simple':
            self.body.grid_remove()
            self.coach_frame.grid_remove()
            self.simple.grid(row=1, column=0, rowspan=2, sticky='nsew')
            self.view_btn.config(text='Detailed view')
            self.simple.refresh()
        else:
            self.simple.grid_remove()
            self.coach_frame.grid()
            self.body.grid()
            self.view_btn.config(text='◀  Simple view')

    def _simple_refresh(self):
        if getattr(self, 'simple', None) is not None and self.view == 'simple':
            self.simple.refresh()

    def _wrong_kind(self, rows, name, expected):
        """If the chosen file looks like the other kind, offer to use it that way. True = handled."""
        kind, _ = R.classify_file(rows)
        if kind in ('unknown', expected):
            return False
        nice = {'sage': 'Sage file', 'bank': 'bank statement'}
        if messagebox.askyesno('This looks like a different file', f'"{name}" looks like a {nice[kind]}, not a {nice[expected]}.\n\nUse it as the {nice[kind]} instead?'):
            (self.ingest_sage if kind == 'sage' else self.ingest_bank)(rows, name)
            return True
        return False

    def reset_all(self):
        if self.dirty and not messagebox.askyesno('Start over?', 'Your notes and ticks have not been saved to a report. Start over anyway?'):
            return
        self.sage = self.bank = self.result = None
        self.bank_rows, self.sage_name, self.bank_name = [], '', ''
        self.bank_problems, self.sage_problems = [], []
        self.dirty = self.period_touched = False
        for frame in (self.sage_state, self.bank_state):
            self._set_lines(frame, [('No file selected  (.xlsx, .xls, .csv)', MUTED)])
        for cb in self.map_boxes.values():
            cb['values'] = []
            cb.set('')
        for g in (self.g_match, self.g_bank, self.g_sage, self.g_sug, self.g_ask):
            g.load([], '')
        self.render_journals()
        self.welcome.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.simple.screen = 'start'
        self._fill_data()
        self.say('Ready. Choose your two files to begin.')

    # ------------------------------------------------------------------ coach banner
    def _coach(self):
        c = self.coach_frame = tk.Frame(self.root, bg=TEAL_L, highlightbackground='#b9dfe2', highlightthickness=1)
        c.grid(row=1, column=0, sticky='ew', padx=10, pady=(8, 0))
        tk.Label(c, text='💡', bg=TEAL_L, font=F(13)).pack(side='left', padx=(12, 4), pady=8)
        self.coach_text = tk.Label(c, text='', bg=TEAL_L, fg=TEAL_D, font=F(10, 'bold'), anchor='w', justify='left', wraplength=1000)
        self.coach_text.pack(side='left', fill='x', expand=True, pady=8)
        self.coach_btn = button(c, '', lambda: None, 'primary', pady=5)
        self.coach_btn.pack(side='right', padx=10, pady=5)
        self._entries = []

    def update_coach(self):
        r = self.result
        if not self.sage and not self.bank:
            msg, label, cmd = 'Welcome! Start by choosing your Sage cashbook and bank statement - you can pick both files at once.', 'Choose both files…', self.pick_both
        elif self.sage and not self.bank:
            msg, label, cmd = 'Sage cashbook loaded ✓   Next: choose the bank statement.', 'Choose bank statement…', self.pick_bank
        elif self.bank and not self.sage:
            msg, label, cmd = 'Bank statement loaded ✓   Next: choose the Sage cashbook export.', 'Choose Sage file…', self.pick_sage
        elif not r:
            msg, label, cmd = 'Both files are loaded ✓   Check the period on the left, then run the reconciliation.', '▶  Run now', self.run
        else:
            exc = {x['id'] for x in r['bank_only'] + r['sage_only']}
            left = len(exc - r['reviewed'])
            st = r['statement']
            if left or r['suggestions']:
                msg = (f'{left} item(s) need your decision. Guided review shows each one with a recommended action '
                       f'- accept or dismiss near-matches, add notes, tick them off.')
                label, cmd = '🧭  Start guided review', self.start_review
            elif st['reconciled']:
                msg, label, cmd = 'Everything is reviewed and the reconciliation proves ✓   Export your report and the proposed journals.', '⬇  Excel report', self.export_excel
            else:
                msg = 'Everything is reviewed, but the proof still shows a difference - the assistant can suggest why.'
                label, cmd = '💬  Ask why', lambda: self.ask_preset('why is there a difference')
        self.coach_text.config(text=msg)
        self.coach_btn.config(text=label, command=cmd)

    # ------------------------------------------------------------------ choose both files
    def pick_both(self):
        paths = filedialog.askopenfilenames(title='Select the Sage cashbook AND the bank statement (Ctrl+click for two files)',
                                            initialdir=self._dialog_dir(), filetypes=[('Spreadsheet / CSV', '*.xlsx *.xls *.csv'), ('All files', '*.*')])
        if not paths:
            return
        if len(paths) > 2:
            messagebox.showinfo('Two files please', 'Select exactly two files: the Sage cashbook and the bank statement.')
            return
        self.cfg['last_dir'] = str(Path(paths[0]).parent)
        files = []
        for p in paths:
            try:
                rows, _ = R.read_workbook(p)
            except Exception as e:  # noqa: BLE001
                messagebox.showerror('Could not read file', f'{Path(p).name}\n\n{e}')
                return
            files.append((Path(p).name, rows, R.classify_file(rows)[0]))
        sage = [f for f in files if f[2] == 'sage']
        bank = [f for f in files if f[2] == 'bank']
        unk = [f for f in files if f[2] == 'unknown']
        if len(files) == 1:
            f = files[0]
            if f[2] == 'unknown':
                is_sage = messagebox.askyesno('Which file is this?', f'Is "{f[0]}" the Sage cashbook?\n\nYes = Sage cashbook, No = bank statement.')
                sage, bank = ([f], []) if is_sage else ([], [f])
        elif not (len(sage) == 1 and len(bank) == 1):
            if len(sage) == 1 and len(unk) == 1:
                bank = unk
            elif len(bank) == 1 and len(unk) == 1:
                sage = unk
            else:
                a, b = files
                if not messagebox.askyesno('Which is which?', f'I could not tell the files apart.\n\nUse "{a[0]}" as the Sage cashbook and "{b[0]}" as the bank statement?\n\n(Choose No to swap them.)'):
                    a, b = b, a
                sage, bank = [a], [b]
        try:
            if sage:
                self.ingest_sage(sage[0][1], sage[0][0])
            if bank:
                self.ingest_bank(bank[0][1], bank[0][0])
        except ValueError as e:
            messagebox.showerror('Import failed', str(e))
            return
        self.say('Loaded ' + ' and '.join(f'{n} as {k}' for n, k in ((sage[0][0], 'Sage cashbook') if sage else (None, None), (bank[0][0], 'bank statement') if bank else (None, None)) if n) + '.')

    # ------------------------------------------------------------------ journals tab
    def _tab_journals(self):
        f = tk.Frame(self.nb, bg=BG)
        self.nb.add(f, text='Journals')
        top = tk.Frame(f, bg=BG)
        top.pack(fill='x', padx=2, pady=(10, 6))
        button(top, '⬇  Export journals CSV', self.export_journals, 'primary', pady=5).pack(side='right', padx=(8, 0))
        WrapLabel(top, pad=220, text='Proposed adjusting entries for items missing from Sage (bank charges, interest, unrecorded items, amount corrections). '
                                     'Nothing is posted. Rows marked "Needs review" go to Suspense until you confirm the right account.',
                  bg=BG, fg=MUTED, font=F(9)).pack(side='left', fill='x', expand=True)
        self.g_jr = Grid(f, JR_COLS, tags={'Medium': (TEXT, '#fff5dc')})
        self.g_jr.pack(fill='both', expand=True)
        self.jr_total = tk.Label(f, text='', bg=BG, fg=MUTED, font=F(10), anchor='w')
        self.jr_total.pack(fill='x', padx=4, pady=(6, 0))

    def accounts(self):
        return {k: v.get().strip() for k, v in self.acc.items()}

    def render_journals(self):
        if not self.result:
            self._entries = []
            self.g_jr.load([], 'Run the reconciliation to see proposed journals')
            return
        self._entries = journals.propose(self.result, self.accounts())
        rows = []
        for e in self._entries:
            for k, l in enumerate(e['lines']):
                rows.append(dict(iid=f'J{e["no"]}-{k}', tag='Medium' if e['needs_review'] else None,
                                 values=[e['no'], f'{e["date"]:%d/%m/%Y}', e['reference'], l['account'], l.get('note') or e['details'],
                                         self.num(l['debit']) if l['debit'] else '', self.num(l['credit']) if l['credit'] else '',
                                         'Yes' if e['needs_review'] else 'No'],
                                 sort=[e['no'] + k / 1000, e['date'], e['reference'], l['account'], l.get('note') or e['details'], l['debit'], l['credit'], e['needs_review']]))
        self.g_jr.load(rows, '🎉  No journals needed - nothing is missing from Sage')
        dr = sum((l['debit'] for e in self._entries for l in e['lines']), Decimal(0))
        cr = sum((l['credit'] for e in self._entries for l in e['lines']), Decimal(0))
        n_rev = sum(e['needs_review'] for e in self._entries)
        self.jr_total.config(text=f'{len(self._entries)} entr{"y" if len(self._entries) == 1 else "ies"}   •   debits {self.fmt(dr)}   •   credits {self.fmt(cr)}'
                                  f'   {"✓ balanced" if dr == cr else "⚠ NOT balanced"}   •   {n_rev} need review',
                             fg=GREEN if dr == cr else RED)

    def export_journals(self):
        if not self._need_result():
            return
        if not self._entries:
            messagebox.showinfo('No journals', 'Nothing is missing from Sage, so no journals are proposed.')
            return
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')], initialfile='Proposed_journals.csv',
                                            initialdir=self._dialog_dir())
        if not path:
            return
        try:
            journals.export_csv(self._entries, path)
            self.say(f'Saved {path} - review before importing into Sage.')
        except Exception as e:  # noqa: BLE001
            messagebox.showerror('Export failed', str(e))

    # ------------------------------------------------------------------ ask tab
    def _tab_ask(self):
        f = tk.Frame(self.nb, bg=BG)
        self.nb.add(f, text='Ask AI')
        tk.Label(f, text='Ask about your results in plain English', bg=BG, fg=NAVY, font=F(12, 'bold')).pack(anchor='w', padx=4, pady=(10, 2))
        row = tk.Frame(f, bg=BG)
        row.pack(fill='x', padx=2, pady=4)
        self.ask_var = tk.StringVar()
        self.ask_entry = ttk.Entry(row, textvariable=self.ask_var, font=F(11))
        self.ask_entry.pack(side='left', fill='x', expand=True, ipady=4)
        self.ask_entry.bind('<Return>', lambda e: self.do_ask())
        button(row, 'Ask', self.do_ask, 'primary', pady=6).pack(side='left', padx=(8, 0))
        chips = tk.Frame(f, bg=BG)
        chips.pack(fill='x', padx=2, pady=(2, 6))
        for q in assistant.HELP[:6]:
            button(chips, q, lambda q=q: self.ask_preset(q), 'ghost', padx=8, pady=3, font=F(9)).pack(side='left', padx=(0, 6))
        self.ask_answer = WrapLabel(f, pad=16, text='Try "payments over 500k not on the bank", "bank charges", "unusual items" or "why is there a difference". '
                                                    'Everything is answered on this PC - no data is sent anywhere.',
                                    bg=BG, fg=NAVY, font=F(11, 'bold'))
        self.ask_answer.pack(fill='x', padx=4, pady=(4, 8))
        self.g_ask = Grid(f, EXC_COLS, tags=SEV_TAGS, on_select=self._on_select)
        self.g_ask.pack(fill='both', expand=True)

    def ask_preset(self, q):
        self.nb.select(6)
        self.ask_var.set(q)
        if q:
            self.do_ask()
        else:
            self.ask_entry.focus_set()

    def do_ask(self):
        if not self._need_result():
            return
        res = assistant.ask(self.result, self.ask_var.get(), self.sym)
        self.ask_answer.config(text=res['answer'])
        self.g_ask.load([self._exc_row(x) for x in res['items']], 'No matching items')
        self.say('Assistant: ' + res['answer'][:140])

    # ------------------------------------------------------------------ review helpers
    def toggle_reviewed(self):
        if not self._need_result():
            return
        g = self._current_grid()
        ids = [i for i in (g.selected() if g else []) if i[0] in 'BS' and not i.startswith('SG:')]
        if not ids:
            messagebox.showinfo('Select items', 'Select one or more exception rows first.')
            return
        flag = not all(i in self.result['reviewed'] for i in ids)
        R.set_reviewed(self.result, ids, flag)
        self._after_change('Marked as reviewed.' if flag else 'Review mark removed.')

    def start_review(self):
        if not self._need_result():
            return
        r = self.result
        if not r['suggestions'] and all(x['id'] in r['reviewed'] for x in r['bank_only'] + r['sage_only']):
            messagebox.showinfo('All reviewed', 'Every exception is already reviewed.')
            return
        ReviewDialog(self)

    def open_match(self, pre_b, pre_s):
        return MatchDialog(self, pre_b, pre_s)

    def _ctx(self, event, grid):
        iid = grid.tree.identify_row(event.y)
        if iid and iid not in grid.tree.selection():
            grid.tree.selection_set(iid)
        if not self.result:
            return
        m = tk.Menu(self.root, tearoff=0)
        if grid in (self.g_bank, self.g_sage, self.g_ask):
            m.add_command(label='🔗  Match manually…', command=self.manual_dialog)
            m.add_command(label='✓  Mark reviewed / not reviewed', command=self.toggle_reviewed)
            m.add_command(label='📝  Add note…', command=self.add_note)
        elif grid is self.g_sug:
            m.add_command(label='✔  Accept suggestion', command=self.accept_selected)
            m.add_command(label='✖  Not a match (dismiss)', command=self.reject_selected)
        elif grid is self.g_match:
            m.add_command(label='↶  Unmatch', command=self.unmatch_selected)
        m.add_separator()
        m.add_command(label='Copy selected row(s)', command=lambda: self._copy(grid))
        m.tk_popup(event.x_root, event.y_root)

    def _copy(self, grid):
        lines = ['\t'.join(str(v) for v in grid.tree.item(i, 'values')) for i in grid.selected()]
        if lines:
            self.root.clipboard_clear()
            self.root.clipboard_append('\n'.join(lines))
            self.say(f'Copied {len(lines)} row(s) to the clipboard.')

    def reject_selected(self):
        if not self._need_result():
            return
        sel = self.g_sug.selected()
        for i in sel:
            R.reject_suggestion(self.result, i)
        if sel:
            self._after_change(f'{len(sel)} suggestion(s) dismissed.')

    # ------------------------------------------------------------------ sessions & learning
    def save_session(self):
        if not self._need_result():
            return
        path = filedialog.asksaveasfilename(defaultextension='.srec', filetypes=[('SageRecon review session', '*.srec')],
                                            initialfile=f'Review_{self.result["params"]["end"]:%Y-%m}.srec', initialdir=self._dialog_dir())
        if not path:
            return
        state = R.export_state(self.result)
        state['files'] = dict(sage=self.sage_name, bank=self.bank_name)
        Path(path).write_text(json.dumps(state, indent=1), encoding='utf-8')
        self.dirty = False
        self.say(f'Review session saved: {path}')

    def open_session(self):
        if not self._need_result():
            return
        path = filedialog.askopenfilename(title='Open review session', filetypes=[('SageRecon review session', '*.srec')], initialdir=self._dialog_dir())
        if not path:
            return
        try:
            state = json.loads(Path(path).read_text(encoding='utf-8'))
        except Exception as e:  # noqa: BLE001
            messagebox.showerror('Cannot open session', str(e))
            return
        f = state.get('files', {})
        if f and (f.get('sage') != self.sage_name or f.get('bank') != self.bank_name):
            if not messagebox.askyesno('Different files?', f'This session was saved with:\n  Sage: {f.get("sage")}\n  Bank: {f.get("bank")}\n\n'
                                                           'The currently loaded files have different names. Row numbers must be identical for the session to apply. Continue?'):
                return
        out = R.apply_state(self.result, state)
        self._after_change(f'Session restored: {out["applied"]} manual match(es) re-applied' + (f', {out["skipped"]} skipped (rows not found).' if out['skipped'] else '.'))

    def forget_memory(self):
        n = len(self.memory)
        if not n:
            messagebox.showinfo('Nothing learned yet', 'The app learns when you accept suggestions or match items manually.')
            return
        if messagebox.askyesno('Forget learned patterns', f'The app has learned {n} naming pattern(s) from your decisions.\nForget them all?'):
            self.memory.forget()
            self.say('Learned patterns cleared.')

    # ------------------------------------------------------------------ manual match dialog
    def manual_dialog(self):
        if not self._need_result():
            return
        r = self.result
        if not (r['bank_only'] and r['sage_only']):
            messagebox.showinfo('Nothing to match', 'Both lists need at least one unmatched item to pair manually.')
            return
        g = self._current_grid()
        sel = g.selected() if g else []
        self.open_match([i for i in sel if i.startswith('B')], [i for i in sel if i.startswith('S') and not i.startswith('SG:')])

    # ------------------------------------------------------------------ export
    def _export_args(self):
        return dict(company=self.company.get().strip(), account=self.account.get().strip(),
                    currency=self.cur.get().split()[-1] if self.cur.get() != 'No symbol' else '', prepared_by=self.prepared.get().strip(), accounts=self.accounts())

    def export_excel(self):
        if not self._need_result():
            return
        stamp = f'{dt.datetime.now():%Y%m%d}'
        path = filedialog.asksaveasfilename(defaultextension='.xlsx', filetypes=[('Excel workbook', '*.xlsx')],
                                            initialfile=f'Bank_Reconciliation_{self.result["params"]["end"]:%Y-%m}_{stamp}.xlsx',
                                            initialdir=self._dialog_dir())
        if not path:
            return
        try:
            export_xlsx(self.result, path, **self._export_args())
        except PermissionError:
            messagebox.showerror('Export failed', 'The file is open in Excel or the folder is read-only. Close it and try again.')
            return
        except Exception as e:  # noqa: BLE001
            messagebox.showerror('Export failed', str(e))
            return
        self.dirty = False
        self.say(f'Saved {path}')
        if messagebox.askyesno('Report saved', f'{Path(path).name} was saved.\n\nOpen it now?'):
            self._open(path)

    def export_csv_file(self):
        if not self._need_result():
            return
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')],
                                            initialfile='SageRecon_Reconciliation.csv', initialdir=self._dialog_dir())
        if not path:
            return
        try:
            export_csv(self.result, path)
            self.dirty = False
            self.say(f'Saved {path}')
        except Exception as e:  # noqa: BLE001
            messagebox.showerror('Export failed', str(e))

    @staticmethod
    def _open(path):
        try:
            if sys.platform.startswith('win'):
                os.startfile(path)  # noqa: S606
            elif sys.platform == 'darwin':
                os.system(f'open "{path}"')
            else:
                os.system(f'xdg-open "{path}" >/dev/null 2>&1 &')
        except Exception:
            pass

    # ------------------------------------------------------------------ misc
    def about(self):
        messagebox.showinfo(
            'How matching works',
            f'{APP_NAME} {VERSION}\n\n'
            'The "AI" is an offline, explainable matching engine - not a generative model. Nothing leaves your PC.\n\n'
            '1. Exact pass - same direction and amount within the date tolerance, ranked by date proximity, '
            'reference/ID overlap and description similarity. Each match gets a confidence score and a reason.\n'
            '2. Batch/split pass - one item equal to the sum of 2-4 items on the other side (e.g. a cash deposit of several receipts).\n'
            '3. Near-miss suggestions - same reference but different amount, transposed digits, keying errors, small fee differences, '
            'and identical amounts with dates outside the tolerance. These are never auto-accepted.\n'
            '4. Classification - bank charges, interest, reversals, outstanding payments, deposits in transit, stale cheques, duplicates.\n'
            '5. Learning - when you accept a suggestion or match items yourself, the app remembers the naming pattern (stored locally) and uses it next time.\n'
            '6. Assistant, risk flags, proposed journals and guided review sit on top of these results.\n'
            '7. Proof - adjusted bank balance vs adjusted book balance. A closing balance that cannot be verified is shown as '
            'NOT VERIFIED, never as zero.\n\n'
            'Unmatched items are items to investigate, not confirmed errors. No Sage records are changed.')

    def on_close(self):
        if self.dirty and not messagebox.askyesno('Unsaved review work', 'You have manual matches/notes that have not been exported. Exit anyway?'):
            return
        self._save_settings()
        self.memory.save()
        self.root.destroy()


class MatchDialog(tk.Toplevel):
    COLS = [('row', 'Row', 60, 'e', False), ('date', 'Date', 92, 'w', False), ('dir', 'Dir', 50, 'w', False),
            ('amt', 'Amount', 108, 'e', False), ('desc', 'Description', 260, 'w', True)]

    def __init__(self, app, pre_bank, pre_sage):
        super().__init__(app.root)
        self.app, self.r = app, app.result
        self.title('Match manually')
        self.geometry('1180x620')
        self.minsize(900, 480)
        self.configure(bg=BG)
        self.transient(app.root)
        self.grab_set()
        tk.Label(self, text='Pick one or more items on each side. All items must move money in the same direction.', bg=BG, fg=MUTED,
                 font=F(10)).pack(anchor='w', padx=14, pady=(12, 4))
        top = tk.Frame(self, bg=BG)
        top.pack(fill='x', padx=14)
        self.dirf = tk.StringVar(value='all')
        for text, v in (('All', 'all'), ('Money in', 'in'), ('Money out', 'out')):
            tk.Radiobutton(top, text=text, value=v, variable=self.dirf, command=self.fill, bg=BG, activebackground=BG,
                           font=F(10)).pack(side='left', padx=(0, 10))
        self.q = tk.StringVar()
        self.q.trace_add('write', lambda *a: self.fill())
        ttk.Entry(top, textvariable=self.q, width=26).pack(side='right')
        tk.Label(top, text='Search 🔍 ', bg=BG, font=F(10)).pack(side='right')
        mid = tk.Frame(self, bg=BG)
        mid.pack(fill='both', expand=True, padx=14, pady=8)
        mid.grid_columnconfigure((0, 1), weight=1, uniform='m')
        mid.grid_rowconfigure(1, weight=1)
        tk.Label(mid, text='Bank - not in Sage', bg=BG, fg=NAVY, font=F(10, 'bold')).grid(row=0, column=0, sticky='w')
        tk.Label(mid, text='Sage - not on bank', bg=BG, fg=NAVY, font=F(10, 'bold')).grid(row=0, column=1, sticky='w', padx=(8, 0))
        self.gb, self.gs = Grid(mid, self.COLS, on_select=lambda g: self.summary()), Grid(mid, self.COLS, on_select=lambda g: self.summary())
        self.gb.grid(row=1, column=0, sticky='nsew', padx=(0, 4))
        self.gs.grid(row=1, column=1, sticky='nsew', padx=(4, 0))
        self.fill()
        self.gb.select(pre_bank)
        self.gs.select(pre_sage)
        bot = tk.Frame(self, bg=BG)
        bot.pack(fill='x', padx=14, pady=(0, 12))
        self.sumlab = tk.Label(bot, text='', bg=BG, fg=TEXT, font=F(10, 'bold'), anchor='w', justify='left')
        self.sumlab.pack(side='top', fill='x', pady=(0, 6))
        nr = tk.Frame(bot, bg=BG)
        nr.pack(fill='x')
        tk.Label(nr, text='Reason / note', bg=BG, fg=MUTED, font=F(9)).pack(side='left')
        self.note = tk.StringVar()
        ttk.Entry(nr, textvariable=self.note).pack(side='left', fill='x', expand=True, padx=8)
        button(nr, 'Cancel', self.destroy, 'ghost').pack(side='right', padx=(8, 0))
        self.go = button(nr, '🔗  Match selected', self.commit)
        self.go.pack(side='right')
        self.summary()
        self.bind('<Escape>', lambda e: self.destroy())

    def fill(self):
        d, q = self.dirf.get(), self.q.get().strip().lower()

        def rows(items):
            out = []
            for x in items:
                if d != 'all' and x['direction'] != d:
                    continue
                hay = f'{x["description"]} {x["reference"]} {x["amount"]} {x["row"]}'.lower()
                if q and q not in hay:
                    continue
                out.append(dict(iid=x['id'], values=[x['row'], f'{x["date"]:%d/%m/%Y}', 'IN' if x['direction'] == 'in' else 'OUT',
                                                      self.app.num(x['amount']), (x['reference'] + ' ' + x['description']).strip()],
                                sort=[x['row'], x['date'], x['direction'], x['amount'], x['description']]))
            return out
        self.gb.load(rows(self.r['bank_only']), 'No bank items')
        self.gs.load(rows(self.r['sage_only']), 'No Sage items')

    def _items(self, grid, pool):
        ids = set(grid.selected())
        return [x for x in pool if x['id'] in ids]

    def summary(self):
        b, s = self._items(self.gb, self.r['bank_only']), self._items(self.gs, self.r['sage_only'])
        tb, ts = sum((x['amount'] for x in b), Decimal(0)), sum((x['amount'] for x in s), Decimal(0))
        mixed = len({x['direction'] for x in b + s}) > 1
        ok = bool(b and s) and not mixed
        diff = tb - ts
        msg = f'Bank: {len(b)} item(s) = {self.app.fmt(tb)}      Sage: {len(s)} item(s) = {self.app.fmt(ts)}      '
        msg += 'Mixed directions - not allowed' if mixed else ('Amounts agree ✓' if ok and diff == 0 else f'Difference {self.app.fmt(diff)} (will become a reconciling line)' if ok else '')
        self.sumlab.config(text=msg, fg=RED if mixed else (GREEN if ok and diff == 0 else AMBER if ok else MUTED))
        self.go.config(state='normal' if ok else 'disabled')

    def commit(self):
        b, s = self.gb.selected(), self.gs.selected()
        try:
            R.manual_match(self.r, s, b, self.note.get().strip())
        except ValueError as e:
            messagebox.showerror('Cannot match', str(e), parent=self)
            return
        self.destroy()
        self.app._after_change('Manual match recorded.')


def main():
    if sys.platform.startswith('win'):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    try:
        root.tk.call('tk', 'scaling', root.winfo_fpixels('1i') / 72.0)
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
