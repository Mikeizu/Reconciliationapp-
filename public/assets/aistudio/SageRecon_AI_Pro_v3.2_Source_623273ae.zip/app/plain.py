"""Turns reconciliation results into a short, jargon-free to-do list for non-accountants."""
from __future__ import annotations

TIMING = {'Outstanding payment', 'Deposit in transit'}
BULK = {'Bank charge': 'Bank charges', 'Bank interest': 'Bank interest'}


def day(d):
    return f'{d.day} {d:%b %Y}'


def _what(x):
    return (x['description'] or x['reference'] or 'no description').strip()


def build_plan(r, fmt):
    """Return dict(groups=[...], total, done, left). Group: key,title,intro,tasks,collapsed. Task: kind,ids,headline,detail,advice,tone,done."""
    reviewed = r['reviewed']
    sug_ids = {x['id'] for s in r['suggestions'] for x in (s['bank'], s['sage'])}
    groups = []

    def add(key, title, intro, tasks, collapsed=False):
        if tasks:
            groups.append(dict(key=key, title=title, intro=intro, tasks=tasks, collapsed=collapsed))

    # ---- 1. things that look like the same transaction
    pairs = []
    for s in sorted(r['suggestions'], key=lambda s: -s['confidence']):
        b, g, diff = s['bank'], s['sage'], s['diff']
        why = {'timing': f'The amounts are identical but the dates are far apart ({abs((b["date"] - g["date"]).days)} days).',
               'transposition': 'The amounts look the same except two digits are swapped - a typing slip is likely.',
               'keying': 'The amounts differ by a single digit - a typing slip is likely.',
               'ref_mismatch': 'They share the same reference number, but the amounts are different.',
               'close_amount': 'The amounts are very close - the bank may have taken a small fee.'}[s['kind']]
        if diff:
            why += f' They differ by {fmt(abs(diff))}; if you say yes, that difference is listed as a correction to make in Sage.'
        pairs.append(dict(kind='pair', ids=[s['id']], headline='These two entries look like the same transaction',
                          detail=f'Bank statement: {fmt(b["amount"])} on {day(b["date"])} - {_what(b)}\n'
                                 f'Your Sage records: {fmt(g["amount"])} on {day(g["date"])} - {_what(g)}\n\n{why}',
                          advice='Are they the same transaction?', tone='info', done=False))
    add('pairs', 'Do these go together?', 'We found entries that are almost - but not exactly - a match. You decide.', pairs)

    def item_tasks(items, mk):
        return [dict(kind='item', ids=[x['id']], done=x['id'] in reviewed, **mk(x)) for x in items]

    items = [x for x in r['bank_only'] + r['sage_only'] if x['id'] not in sug_ids]
    items.sort(key=lambda x: (x['date'], x['row']))

    # ---- 2/3. money on the bank statement that Sage does not know about
    def bank_out(x):
        if x['category'] == 'Reversal / return':
            return dict(headline=f'{fmt(x["amount"])} was reversed or returned by the bank on {day(x["date"])}',
                        detail=f'Bank narration: {_what(x)}', advice='Check the original transaction and record the reversal in Sage.', tone='warn')
        return dict(headline=f'{fmt(x["amount"])} left your bank on {day(x["date"])} - not in Sage',
                    detail=f'Bank narration: {_what(x)}',
                    advice="Find out what this payment was for and record it in Sage. If you don't recognise it, contact your bank.", tone='bad')

    def bank_in(x):
        if x['category'] == 'Reversal / return':
            return bank_out(x)
        return dict(headline=f'{fmt(x["amount"])} arrived in your bank on {day(x["date"])} - not in Sage',
                    detail=f'Bank narration: {_what(x)}', advice='Find out who paid you and record the receipt in Sage.', tone='warn')

    b_out = [x for x in items if x['source'] == 'Bank' and x['direction'] == 'out' and x['category'] not in BULK]
    b_in = [x for x in items if x['source'] == 'Bank' and x['direction'] == 'in' and x['category'] not in BULK]
    add('bank_out', 'Money that left your bank but is not in Sage', 'Your bank statement shows these payments, but your Sage records do not.', item_tasks(b_out, bank_out))
    add('bank_in', 'Money that arrived in your bank but is not in Sage', 'Your bank statement shows these receipts, but your Sage records do not.', item_tasks(b_in, bank_in))

    # ---- 4. bank charges / interest: one card per kind, one click
    bulk = []
    for cat, label in BULK.items():
        xs = [x for x in items if x['source'] == 'Bank' and x['category'] == cat]
        if xs:
            total = sum((x['amount'] for x in xs), xs[0]['amount'] * 0)
            lines = '\n'.join(f'  - {fmt(x["amount"])}   {_what(x)}' for x in xs)
            word = 'charge' if cat == 'Bank charge' else 'interest payment'
            bulk.append(dict(kind='bulk', ids=[x['id'] for x in xs], done=all(x['id'] in reviewed for x in xs),
                             headline=f'{len(xs)} bank {word}{"s" if len(xs) != 1 else ""} totalling {fmt(total)}',
                             detail=lines, tone='warn',
                             advice='The bank took these automatically. Record them in Sage - a ready-made journal entry is in your download.'
                             if cat == 'Bank charge' else 'The bank paid you this. Record it in Sage as interest received - a ready-made entry is in your download.'))
    add('bulk', 'Bank fees and interest', 'These come straight from the bank and are normally just recorded in Sage.', bulk)

    # ---- 5. Sage entries that never reached the bank
    def sage_item(x):
        cat = x['category']
        if cat == 'Possible duplicate':
            return dict(headline=f'{fmt(x["amount"])} on {day(x["date"])} appears twice in Sage', detail=f'Sage entry: {_what(x)}',
                        advice='If it was entered twice by mistake, delete one in Sage.', tone='warn')
        if cat == 'Stale payment':
            return dict(headline=f'{fmt(x["amount"])} payment from {day(x["date"])} has still not cleared', detail=f'Sage entry: {_what(x)}',
                        advice='This is over six months old - a cheque may have expired. Check whether it was ever cashed.', tone='bad')
        if x['direction'] == 'out':
            return dict(headline=f'{fmt(x["amount"])} payment in Sage on {day(x["date"])} never left the bank', detail=f'Sage entry: {_what(x)}',
                        advice='It has been a while. Check it was really paid - or whether it went through on another date or account.', tone='bad')
        return dict(headline=f'{fmt(x["amount"])} receipt in Sage on {day(x["date"])} never reached the bank', detail=f'Sage entry: {_what(x)}',
                    advice='Check it was actually banked - or whether it is waiting to be paid in.', tone='bad')

    s_items = [x for x in items if x['source'] == 'Sage' and x['category'] not in TIMING]
    add('sage', 'Entries in Sage that have not appeared at the bank', 'These are recorded in your Sage books, but your bank statement does not show them.', item_tasks(s_items, sage_item))

    # ---- 6. normal timing differences (no action)
    def timing(x):
        out = x['direction'] == 'out'
        return dict(headline=f'{fmt(x["amount"])} {"payment" if out else "deposit"} from {day(x["date"])} has not cleared yet', detail=f'Sage entry: {_what(x)}',
                    advice='Normal - it should show on next month\'s statement. Nothing to do.', tone='ok')
    t_items = [x for x in items if x['source'] == 'Sage' and x['category'] in TIMING]
    add('timing', 'Normal timing differences - nothing to do', 'Recent entries that have not reached the bank yet.', item_tasks(t_items, timing), collapsed=True)

    todo = [t for g in groups if g['key'] != 'timing' for t in g['tasks']]
    done = sum(len(t['ids']) for t in todo if t['kind'] != 'pair' and t['done'])
    left = sum(1 if t['kind'] == 'pair' else (0 if t['done'] else len(t['ids'])) for t in todo)
    return dict(groups=groups, done=done, left=left, total=done + left)


def status(r, plan, fmt):
    """Headline for the results screen -> dict(tone, title, sub)."""
    st = r['statement']
    d = st['difference']
    if d is None:
        return dict(tone='warn', title="We need one more number", sub="We couldn't find a closing balance in one of your files. Type it in below and we can finish the check.")
    if d != 0:
        extra = ' '.join(st['explainers'][:2])
        return dict(tone='bad', title=f'Your bank and your books are {fmt(abs(d))} apart',
                    sub=('The items below do not fully explain the gap. ' + extra).strip())
    if plan['left']:
        n = plan['left']
        return dict(tone='info', title=f'Almost there - {n} thing{"s" if n != 1 else ""} to look at',
                    sub='Everything is accounted for. Go through the list below so your Sage records can be brought up to date.')
    return dict(tone='good', title='All done - your bank and your books agree', sub='Download your report below and keep it with your month-end records.')
